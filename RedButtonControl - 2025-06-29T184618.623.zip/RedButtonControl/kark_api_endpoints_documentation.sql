-- KARK Website API Endpoints and Database Documentation
-- Version: 1.0
-- Date: 2025-01-24
-- Description: Complete API endpoints mapping with database tables

-- =====================================================
-- API ENDPOINTS TO DATABASE TABLE MAPPING
-- =====================================================

/*
API ENDPOINT                          METHOD    TABLE                   DESCRIPTION
================================================================================
/api/visitor-count                    GET       settings               Get visitor count
/api/visitor-count/increment          POST      settings               Increment visitor count
/api/user                            GET       users                  Get current user
/api/users                           GET       users                  List all users
/api/users/:id                       GET       users                  Get user by ID
/api/users/:id                       PUT       users                  Update user
/api/users/:id                       DELETE    users                  Delete user
/api/auth/login                      POST      users                  User login
/api/auth/logout                     POST      sessions               User logout
/api/auth/register                   POST      users                  User registration

/api/events                          GET       events                 List events
/api/events/:id                      GET       events                 Get event by ID
/api/events                          POST      events                 Create event
/api/events/:id                      PUT       events                 Update event
/api/events/:id                      DELETE    events                 Delete event

/api/activities                      GET       activities             List activities
/api/activities/:id                  GET       activities             Get activity by ID
/api/activities                      POST      activities             Create activity
/api/activities/:id                  PUT       activities             Update activity
/api/activities/:id                  DELETE    activities             Delete activity

/api/media                           GET       media_items            List media items
/api/media/:id                       GET       media_items            Get media item
/api/media                           POST      media_items            Upload media
/api/media/:id                       PUT       media_items            Update media
/api/media/:id                       DELETE    media_items            Delete media

/api/albums                          GET       albums                 List albums
/api/albums/:id                      GET       albums                 Get album
/api/albums                          POST      albums                 Create album
/api/albums/:id                      PUT       albums                 Update album
/api/albums/:id                      DELETE    albums                 Delete album

/api/team                            GET       team_members           List team members
/api/team/:id                        GET       team_members           Get team member
/api/team                            POST      team_members           Add team member
/api/team/:id                        PUT       team_members           Update team member
/api/team/:id                        DELETE    team_members           Remove team member

/api/contact                         GET       contact_messages       List messages
/api/contact/:id                     GET       contact_messages       Get message
/api/contact                         POST      contact_messages       Send message
/api/contact/:id/read                PUT       contact_messages       Mark as read
/api/contact/:id                     DELETE    contact_messages       Delete message

/api/settings                        GET       settings               List settings
/api/settings/:key                   GET       settings               Get setting by key
/api/settings                        POST      settings               Create setting
/api/settings/:key                   PUT       settings               Update setting

/api/donation-methods                GET       donation_methods       List donation methods
/api/donation-methods/:id            GET       donation_methods       Get donation method
/api/donation-methods                POST      donation_methods       Create method
/api/donation-methods/:id            PUT       donation_methods       Update method
/api/donation-methods/:id            DELETE    donation_methods       Delete method

/api/donation-campaigns              GET       donation_campaigns     List campaigns
/api/donation-campaigns/:id          GET       donation_campaigns     Get campaign
/api/donation-campaigns              POST      donation_campaigns     Create campaign
/api/donation-campaigns/:id          PUT       donation_campaigns     Update campaign
/api/donation-campaigns/:id          DELETE    donation_campaigns     Delete campaign

/api/archive                         GET       archive_items          List archive items
/api/archive/:id                     GET       archive_items          Get archive item
/api/archive                         POST      archive_items          Create archive item
/api/archive/:id                     PUT       archive_items          Update archive item
/api/archive/:id                     DELETE    archive_items          Delete archive item
/api/archive/:id/view                POST      archive_items          Increment view count

/api/archive/:id/media               GET       archive_media          List archive media
/api/archive/:id/media               POST      archive_media          Add media to archive
/api/archive/media/:id               PUT       archive_media          Update archive media
/api/archive/media/:id               DELETE    archive_media          Delete archive media

/api/hero-sliders                    GET       hero_sliders           List hero sliders
/api/hero-sliders/:id                GET       hero_sliders           Get hero slider
/api/hero-sliders                    POST      hero_sliders           Create hero slider
/api/hero-sliders/:id                PUT       hero_sliders           Update hero slider
/api/hero-sliders/:id                DELETE    hero_sliders           Delete hero slider

/api/admin/logs                      GET       admin_logs             List admin logs
/api/admin/logs                      POST      admin_logs             Create log entry
/api/admin/stats                     GET       multiple tables        Get statistics
*/

-- =====================================================
-- DATA VERIFICATION QUERIES
-- =====================================================

-- Check all tables exist
SELECT 
    TABLE_NAME,
    TABLE_ROWS,
    AUTO_INCREMENT,
    CREATE_TIME
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = DATABASE()
ORDER BY TABLE_NAME;

-- Check foreign key relationships
SELECT 
    CONSTRAINT_NAME,
    TABLE_NAME,
    COLUMN_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM information_schema.KEY_COLUMN_USAGE
WHERE TABLE_SCHEMA = DATABASE()
    AND REFERENCED_TABLE_NAME IS NOT NULL
ORDER BY TABLE_NAME, CONSTRAINT_NAME;

-- Check indexes
SELECT 
    TABLE_NAME,
    INDEX_NAME,
    GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) AS COLUMNS,
    INDEX_TYPE,
    NON_UNIQUE
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = DATABASE()
GROUP BY TABLE_NAME, INDEX_NAME
ORDER BY TABLE_NAME, INDEX_NAME;

-- Verify data in each table
SELECT 'users' as table_name, COUNT(*) as record_count FROM users
UNION ALL
SELECT 'events', COUNT(*) FROM events
UNION ALL
SELECT 'activities', COUNT(*) FROM activities
UNION ALL
SELECT 'media_items', COUNT(*) FROM media_items
UNION ALL
SELECT 'albums', COUNT(*) FROM albums
UNION ALL
SELECT 'team_members', COUNT(*) FROM team_members
UNION ALL
SELECT 'contact_messages', COUNT(*) FROM contact_messages
UNION ALL
SELECT 'settings', COUNT(*) FROM settings
UNION ALL
SELECT 'donation_methods', COUNT(*) FROM donation_methods
UNION ALL
SELECT 'donation_campaigns', COUNT(*) FROM donation_campaigns
UNION ALL
SELECT 'archive_items', COUNT(*) FROM archive_items
UNION ALL
SELECT 'archive_media', COUNT(*) FROM archive_media
UNION ALL
SELECT 'hero_sliders', COUNT(*) FROM hero_sliders
UNION ALL
SELECT 'admin_logs', COUNT(*) FROM admin_logs
UNION ALL
SELECT 'sessions', COUNT(*) FROM sessions;

-- =====================================================
-- API TESTING QUERIES
-- =====================================================

-- Test visitor count API
SELECT `value` as visitor_count 
FROM settings 
WHERE `key` = 'stats.visitor_count';

-- Test user listing API (with role filtering)
SELECT 
    id,
    username,
    first_name,
    last_name,
    email,
    role,
    is_admin,
    created_at
FROM users
WHERE role != 'banned'
ORDER BY created_at DESC;

-- Test events API (upcoming events)
SELECT 
    e.*,
    u.username as creator_name
FROM events e
LEFT JOIN users u ON e.created_by = u.id
WHERE e.date >= CURRENT_DATE
ORDER BY e.date ASC;

-- Test activities API (active only)
SELECT 
    a.*,
    u.username as creator_name
FROM activities a
LEFT JOIN users u ON a.created_by = u.id
WHERE a.is_active = true
ORDER BY a.display_order ASC;

-- Test archive search API
SELECT 
    ai.*,
    u.username as creator_name,
    COUNT(am.id) as media_count
FROM archive_items ai
LEFT JOIN users u ON ai.created_by = u.id
LEFT JOIN archive_media am ON ai.id = am.archive_item_id
WHERE ai.is_published = true
GROUP BY ai.id
ORDER BY ai.date DESC;

-- Test media gallery API
SELECT 
    m.*,
    e.title as event_title,
    a.title as album_title
FROM media_items m
LEFT JOIN events e ON m.event_id = e.id
LEFT JOIN albums a ON m.album_id = a.id
ORDER BY m.created_at DESC;

-- Test hero sliders API
SELECT * FROM hero_sliders
WHERE is_active = true
ORDER BY display_order ASC;

-- Test donation methods API
SELECT 
    dm.*,
    u.username as created_by_name
FROM donation_methods dm
LEFT JOIN users u ON dm.created_by = u.id
ORDER BY dm.created_at DESC;

-- Test contact messages API (unread)
SELECT * FROM contact_messages
WHERE is_read = false
ORDER BY created_at DESC;

-- Test admin logs API
SELECT 
    al.*,
    u.username,
    u.first_name,
    u.last_name
FROM admin_logs al
JOIN users u ON al.user_id = u.id
ORDER BY al.timestamp DESC
LIMIT 100;

-- =====================================================
-- MISSING DATA CHECK
-- =====================================================

-- Check for orphaned records
SELECT 'Orphaned media items (no event/album)' as check_type, COUNT(*) as count
FROM media_items 
WHERE event_id IS NULL AND album_id IS NULL

UNION ALL

SELECT 'Orphaned archive media (no archive item)', COUNT(*)
FROM archive_media am
LEFT JOIN archive_items ai ON am.archive_item_id = ai.id
WHERE ai.id IS NULL

UNION ALL

SELECT 'Events without creator', COUNT(*)
FROM events
WHERE created_by IS NULL

UNION ALL

SELECT 'Settings without updater', COUNT(*)
FROM settings
WHERE updated_by IS NULL;

-- =====================================================
-- PERFORMANCE CHECK
-- =====================================================

-- Check table sizes
SELECT 
    TABLE_NAME,
    ROUND(((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024), 2) AS 'Size (MB)',
    TABLE_ROWS AS 'Estimated Rows'
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
ORDER BY DATA_LENGTH + INDEX_LENGTH DESC;

-- Check slow queries (if slow query log is enabled)
-- SHOW VARIABLES LIKE 'slow_query_log';
-- SHOW VARIABLES LIKE 'long_query_time';

-- =====================================================
-- SECURITY CHECK
-- =====================================================

-- Check user permissions
SELECT 
    username,
    role,
    is_admin,
    CASE 
        WHEN permissions IS NULL THEN 'No special permissions'
        ELSE permissions
    END as permissions
FROM users
ORDER BY 
    CASE role 
        WHEN 'major_admin' THEN 1
        WHEN 'admin' THEN 2
        WHEN 'user' THEN 3
        WHEN 'banned' THEN 4
    END;

-- Check for weak passwords (length check only)
SELECT 
    'Users with potentially weak passwords' as check_type,
    COUNT(*) as count
FROM users
WHERE LENGTH(password) < 60; -- bcrypt hashes are typically 60 chars

-- =====================================================
-- DATA INTEGRITY CHECK
-- =====================================================

-- Check for duplicate emails
SELECT email, COUNT(*) as count
FROM users
GROUP BY email
HAVING COUNT(*) > 1;

-- Check for duplicate usernames
SELECT username, COUNT(*) as count
FROM users
GROUP BY username
HAVING COUNT(*) > 1;

-- Check for duplicate IBAN numbers
SELECT iban, COUNT(*) as count
FROM donation_methods
GROUP BY iban
HAVING COUNT(*) > 1;

-- Check date consistency
SELECT 
    'Future events' as check_type,
    COUNT(*) as count
FROM events
WHERE date > NOW()

UNION ALL

SELECT 'Past events', COUNT(*)
FROM events
WHERE date < NOW()

UNION ALL

SELECT 'Archive items with future dates', COUNT(*)
FROM archive_items
WHERE date > NOW();

-- =====================================================
-- FINAL SUMMARY
-- =====================================================

SELECT 
    'Database Health Check Complete' as Status,
    DATABASE() as Database_Name,
    (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()) as Total_Tables,
    (SELECT COUNT(*) FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA = DATABASE() AND REFERENCED_TABLE_NAME IS NOT NULL) as Total_Foreign_Keys,
    (SELECT COUNT(DISTINCT INDEX_NAME) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE()) as Total_Indexes,
    (SELECT SUM(TABLE_ROWS) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()) as Total_Estimated_Rows;