# replit.md

## Overview

This is a React-based archive management system with an admin panel. The application provides functionality for managing and displaying archived content including videos, reports, events, and other media items. It features a public-facing archive interface and an administrative dashboard for content management and user administration.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: wouter (lightweight React router)
- **State Management**: TanStack Query (React Query) for server state management
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite (inferred from modern React setup)

### Backend Architecture
- **API Structure**: RESTful API endpoints
- **Authentication**: Role-based access control (major_admin, admin, user, banned)
- **Data Validation**: Zod schemas for type safety

### Component Structure
- **Layout Components**: Navbar, Footer, AdminLayout
- **UI Components**: shadcn/ui library (Button, Card, Dialog, Table, etc.)
- **Page Components**: Archive pages, Admin pages
- **Specialized Components**: EventCard for content display

## Key Components

### Public Interface
1. **Archive Detail Page** (`/archive/:id`)
   - Displays individual archive items with full details
   - Supports different content types (operation, training, event, report, news)
   - Type-based color coding and labeling system

2. **Archive List Page** (`/archive`)
   - Filterable archive listing with search functionality
   - Multiple content tabs (archive, events, media, reports)
   - Year and category filtering

### Admin Interface
1. **User Management** (`/admin/users`)
   - User listing with role management
   - Ban/unban functionality
   - Role-based permissions display

2. **Video Management** (`/admin/videos`)
   - CRUD operations for video content
   - YouTube integration for video embedding
   - Thumbnail extraction and preview

## Data Flow

### Content Management Flow
1. Admin creates/edits content through admin panels
2. Content is validated using Zod schemas
3. TanStack Query manages API calls and caching
4. Public pages display filtered and formatted content

### User Authentication Flow
1. Role-based access control system
2. Admin permissions for content management
3. User status tracking (active/banned)

### Archive Item Processing
1. Content categorization by type (operation, training, event, report, news)
2. Date-based filtering and organization
3. Search functionality across titles and descriptions

## External Dependencies

### Frontend Libraries
- **React Ecosystem**: React, React DOM, React Router (wouter)
- **State Management**: @tanstack/react-query
- **UI Framework**: Tailwind CSS, shadcn/ui components
- **Form Management**: react-hook-form, @hookform/resolvers
- **Validation**: Zod
- **Icons**: Lucide React
- **SEO**: React Helmet (Async)

### Media Integration
- **YouTube**: Video embedding and thumbnail extraction
- **File Handling**: Support for various media types (images, videos, documents)

## Deployment Strategy

The application appears to be structured for modern web deployment with:
- Client-side routing handled by wouter
- API endpoints suggesting a separate backend service
- Static asset optimization through modern build tools
- SEO optimization through React Helmet

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Image Display Fix

### Problem
Images were not displaying when users added image URLs because:
1. Users were adding image hosting page URLs instead of direct image URLs (e.g., `https://ibb.co/7xCYFyGG` instead of `https://i.ibb.co/7xCYFyGG/image.jpg`)
2. No automatic conversion of common image hosting service URLs to direct image URLs
3. No visual feedback or guidance for users on correct URL formats

### Solution Implemented
1. Created `ImageWithFallback` component that:
   - Automatically converts image hosting page URLs to direct image URLs for services like ImgBB, Imgur, Google Drive, and Dropbox
   - Provides graceful fallback with error icon when images fail to load
   - Tries different file extensions if initial URL fails

2. Created `ImageUrlHelper` component that:
   - Shows users examples of correct vs incorrect URL formats
   - Provides guidance for popular image hosting services
   - Accessible via help button next to image URL inputs

3. Updated all image display components to use `ImageWithFallback`:
   - Archive detail pages
   - Archive list pages
   - Photo galleries
   - Admin panels

4. Added image preview functionality in admin forms:
   - Shows real-time preview of images as users type URLs
   - Helps users verify their image URLs are working before saving

## Dual Storage System

### Overview
The KARK website now supports both JSON file storage and MySQL database storage, allowing flexible deployment options:

**JSON Storage (Current Default):**
- File-based storage in `/data/` folder
- Perfect for development and small deployments
- No database server required
- Easy to backup and migrate

**MySQL Storage (Production Ready):**
- Full MySQL database support
- Optimized for cPanel hosting environments
- Includes data validation, constraints, and stored procedures
- Ready for production deployment

### Configuration
Switch storage systems by changing `DB_TYPE` in `.env`:
- `DB_TYPE=json` - Use JSON file storage (current)
- `DB_TYPE=mysql` - Use MySQL database

### MySQL Files for cPanel
1. **kark_complete_database_cpanel.sql** - Complete database structure with sample data
2. **kark_api_endpoints_cpanel.sql** - Stored procedures and optimization queries
3. **kark_data_validation_cpanel.sql** - Data validation rules and integrity checks
4. **CPANEL_MYSQL_SETUP.md** - Complete setup instructions for cPanel hosting

### Admin Credentials
- **Username:** supermanager, **Password:** admin123
- **Username:** admin, **Password:** Admin123!

## Changelog

Changelog:
- June 27, 2025. Initial setup
- January 24, 2025. Fixed image display issue by implementing automatic URL conversion and user guidance
- January 27, 2025. Implemented dual storage system (JSON/MySQL) with complete cPanel MySQL setup files
- June 27, 2025. Fixed cPanel deployment issues: created corrected SQL import file without CREATE DATABASE commands, simplified Node.js server file, and provided step-by-step cPanel deployment guides
- June 27, 2025. Fixed MySQL syntax error in CREATE INDEX statement - removed WHERE clause that's not supported in MySQL (kark_complete_database_cpanel_fixed.sql)
- June 27, 2025. Resolved missing cross-env dependency and got the KARK website running successfully on port 5000
- June 29, 2025. Restored complete KARK website project from backup, installed all dependencies (564 packages), configured JSON storage mode, verified server startup on port 5000. Ready for workflow configuration.
- June 29, 2025. Fixed white page issue by configuring Vite development server with proper host allowances for Replit environment. KARK website now loading successfully with full functionality on port 5000.