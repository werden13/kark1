import express from 'express';
import path from 'path';
import session from 'express-session';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import MongoSanitize from 'express-mongo-sanitize';
import hpp from 'hpp';
import xss from 'xss';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:", "http:"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
      connectSrc: ["'self'", "https:", "http:", "ws:", "wss:"]
    }
  }
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.'
});
app.use('/api/', limiter);

// CORS configuration
app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? ['https://yourdomain.com'] 
    : ['http://localhost:5000', 'http://127.0.0.1:5000'],
  credentials: true
}));

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Security sanitization
app.use(MongoSanitize());
app.use(hpp());

// Session configuration
app.use(session({
  secret: process.env.SESSION_SECRET || 'your-secure-random-string-change-this',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

// Static file serving - temporarily serve from client for immediate functionality
app.use(express.static(path.join(__dirname, 'client')));
app.use('/public', express.static(path.join(__dirname, 'public')));

// Database connection
let db;
async function initDatabase() {
  if (process.env.DB_TYPE === 'mysql') {
    try {
      const mysql = await import('mysql2/promise');
      
      const dbConfig = {
        host: process.env.DB_HOST || 'localhost',
        user: process.env.DB_USER || 'root',
        password: process.env.DB_PASSWORD || '',
        database: process.env.DB_NAME || 'kark_website',
        port: process.env.DB_PORT || 3306,
        charset: 'utf8mb4',
        timezone: '+00:00'
      };
      
      db = await mysql.default.createConnection(dbConfig);
      console.log('Connected to MySQL database');
    } catch (error) {
      console.error('MySQL connection failed:', error);
      console.log('Falling back to JSON storage...');
      process.env.DB_TYPE = 'json';
    }
  } else {
    console.log('Using JSON file storage');
  }
}

// Initialize database connection
initDatabase();

// Helper functions for data storage
import { promises as fs } from 'fs';

async function readJsonFile(filename) {
  try {
    const data = await fs.readFile(path.join(__dirname, 'data', filename), 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.log(`Creating new ${filename}...`);
    return [];
  }
}

async function writeJsonFile(filename, data) {
  try {
    await fs.mkdir(path.join(__dirname, 'data'), { recursive: true });
    await fs.writeFile(path.join(__dirname, 'data', filename), JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error(`Error writing ${filename}:`, error);
    return false;
  }
}

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    storage: process.env.DB_TYPE || 'json'
  });
});

// Archive items
app.get('/api/archive', async (req, res) => {
  try {
    let items;
    if (process.env.DB_TYPE === 'mysql' && db) {
      const [rows] = await db.execute('SELECT * FROM kark_archive_items WHERE is_published = TRUE ORDER BY date DESC');
      items = rows;
    } else {
      items = await readJsonFile('archive_items.json');
    }
    res.json(items);
  } catch (error) {
    console.error('Error fetching archive:', error);
    res.status(500).json({ error: 'Failed to fetch archive items' });
  }
});

app.get('/api/archive/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    let item;
    
    if (process.env.DB_TYPE === 'mysql' && db) {
      const [rows] = await db.execute('SELECT * FROM kark_archive_items WHERE id = ? AND is_published = TRUE', [id]);
      item = rows[0];
    } else {
      const items = await readJsonFile('archive_items.json');
      item = items.find(i => i.id === id);
    }
    
    if (!item) {
      return res.status(404).json({ error: 'Archive item not found' });
    }
    
    res.json(item);
  } catch (error) {
    console.error('Error fetching archive item:', error);
    res.status(500).json({ error: 'Failed to fetch archive item' });
  }
});

// Events
app.get('/api/events', async (req, res) => {
  try {
    let events;
    if (process.env.DB_TYPE === 'mysql' && db) {
      const [rows] = await db.execute('SELECT * FROM kark_events WHERE is_published = TRUE ORDER BY date DESC');
      events = rows;
    } else {
      events = await readJsonFile('events.json');
    }
    res.json(events);
  } catch (error) {
    console.error('Error fetching events:', error);
    res.status(500).json({ error: 'Failed to fetch events' });
  }
});

// Media
app.get('/api/media', async (req, res) => {
  try {
    let media;
    if (process.env.DB_TYPE === 'mysql' && db) {
      const [rows] = await db.execute('SELECT * FROM kark_media WHERE is_public = TRUE ORDER BY created_at DESC');
      media = rows;
    } else {
      media = await readJsonFile('media.json');
    }
    res.json(media);
  } catch (error) {
    console.error('Error fetching media:', error);
    res.status(500).json({ error: 'Failed to fetch media' });
  }
});

// Albums
app.get('/api/albums', async (req, res) => {
  try {
    let albums;
    if (process.env.DB_TYPE === 'mysql' && db) {
      const [rows] = await db.execute('SELECT * FROM kark_albums WHERE is_active = TRUE ORDER BY date_created DESC');
      albums = rows;
    } else {
      albums = await readJsonFile('albums.json');
    }
    res.json(albums);
  } catch (error) {
    console.error('Error fetching albums:', error);
    res.status(500).json({ error: 'Failed to fetch albums' });
  }
});

// Team
app.get('/api/team', async (req, res) => {
  try {
    let team;
    if (process.env.DB_TYPE === 'mysql' && db) {
      const [rows] = await db.execute('SELECT * FROM kark_team WHERE is_active = TRUE ORDER BY display_order ASC');
      team = rows;
    } else {
      team = await readJsonFile('team.json');
    }
    res.json(team);
  } catch (error) {
    console.error('Error fetching team:', error);
    res.status(500).json({ error: 'Failed to fetch team' });
  }
});

// Settings
app.get('/api/settings', async (req, res) => {
  try {
    let settings;
    if (process.env.DB_TYPE === 'mysql' && db) {
      const [rows] = await db.execute('SELECT * FROM kark_settings LIMIT 1');
      settings = rows[0] || {};
    } else {
      const settingsArray = await readJsonFile('settings.json');
      settings = settingsArray[0] || {};
    }
    res.json(settings);
  } catch (error) {
    console.error('Error fetching settings:', error);
    res.status(500).json({ error: 'Failed to fetch settings' });
  }
});

// Contact
app.get('/api/contact', async (req, res) => {
  try {
    let contact;
    if (process.env.DB_TYPE === 'mysql' && db) {
      const [rows] = await db.execute('SELECT * FROM kark_contact LIMIT 1');
      contact = rows[0] || {};
    } else {
      const contactArray = await readJsonFile('contact.json');
      contact = contactArray[0] || {};
    }
    res.json(contact);
  } catch (error) {
    console.error('Error fetching contact:', error);
    res.status(500).json({ error: 'Failed to fetch contact' });
  }
});

// Hero sliders
app.get('/api/hero-sliders', async (req, res) => {
  try {
    let sliders;
    if (process.env.DB_TYPE === 'mysql' && db) {
      const [rows] = await db.execute('SELECT * FROM kark_hero_sliders WHERE is_active = TRUE ORDER BY display_order ASC');
      sliders = rows;
    } else {
      sliders = await readJsonFile('hero_sliders.json');
    }
    res.json(sliders);
  } catch (error) {
    console.error('Error fetching hero sliders:', error);
    res.status(500).json({ error: 'Failed to fetch hero sliders' });
  }
});

// Donation methods
app.get('/api/donation-methods', async (req, res) => {
  try {
    let methods;
    if (process.env.DB_TYPE === 'mysql' && db) {
      const [rows] = await db.execute('SELECT * FROM kark_donation_methods WHERE is_active = TRUE ORDER BY display_order ASC');
      methods = rows;
    } else {
      methods = await readJsonFile('donation_methods.json');
    }
    res.json(methods);
  } catch (error) {
    console.error('Error fetching donation methods:', error);
    res.status(500).json({ error: 'Failed to fetch donation methods' });
  }
});

// Donation campaigns
app.get('/api/donation-campaigns', async (req, res) => {
  try {
    let campaigns;
    if (process.env.DB_TYPE === 'mysql' && db) {
      const [rows] = await db.execute('SELECT * FROM kark_donation_campaigns WHERE is_active = TRUE ORDER BY created_at DESC');
      campaigns = rows;
    } else {
      campaigns = await readJsonFile('donation_campaigns.json');
    }
    res.json(campaigns);
  } catch (error) {
    console.error('Error fetching donation campaigns:', error);
    res.status(500).json({ error: 'Failed to fetch donation campaigns' });
  }
});

// Activities
app.get('/api/activities', async (req, res) => {
  try {
    let activities;
    if (process.env.DB_TYPE === 'mysql' && db) {
      const [rows] = await db.execute('SELECT * FROM kark_activities WHERE is_published = TRUE ORDER BY start_date DESC');
      activities = rows;
    } else {
      activities = await readJsonFile('activities.json');
    }
    res.json(activities);
  } catch (error) {
    console.error('Error fetching activities:', error);
    res.status(500).json({ error: 'Failed to fetch activities' });
  }
});

// Serve React app for all other routes - temporarily serve from client
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'client', 'index.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('Shutting down gracefully...');
  if (db && process.env.DB_TYPE === 'mysql') {
    await db.end();
  }
  process.exit(0);
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`KARK Website server running on port ${PORT}`);
  console.log(`Storage type: ${process.env.DB_TYPE || 'json'}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
});

export default app;