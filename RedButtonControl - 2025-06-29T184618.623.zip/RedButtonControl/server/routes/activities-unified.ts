import { Router } from "express";
import { db } from "../db";
import { activities } from "../../shared/schema";
import { eq, desc } from "drizzle-orm";
import { z } from "zod";
import { logAdminAction } from "../admin-logger";
import { requireAdmin } from "../middleware/auth";
import { storage } from "../storage";

const router = Router();

// Check if we're using database or JSON storage
const isUsingDatabase = !!process.env.DATABASE_URL;

// Get all activities (public)
router.get("/", async (req, res) => {
  try {
    if (isUsingDatabase) {
      // MySQL/PostgreSQL implementation
      const allActivities = await db
        .select()
        .from(activities)
        .where(eq(activities.isActive, true))
        .orderBy(activities.displayOrder, desc(activities.createdAt));
      
      res.json(allActivities);
    } else {
      // JSON storage implementation
      const allActivities = await (storage as any).getActivities();
      const activeActivities = allActivities
        .filter((a: any) => a.isActive)
        .sort((a: any, b: any) => a.displayOrder - b.displayOrder);
      
      res.json(activeActivities);
    }
  } catch (error) {
    console.error("Error fetching activities:", error);
    res.status(500).json({ message: "Failed to fetch activities" });
  }
});

// Get all activities including inactive (admin)
router.get("/all", requireAdmin, async (req, res) => {
  try {
    if (isUsingDatabase) {
      const allActivities = await db
        .select()
        .from(activities)
        .orderBy(activities.displayOrder, desc(activities.createdAt));
      
      res.json(allActivities);
    } else {
      const allActivities = await (storage as any).getActivities();
      const sortedActivities = allActivities.sort((a: any, b: any) => a.displayOrder - b.displayOrder);
      
      res.json(sortedActivities);
    }
  } catch (error) {
    console.error("Error fetching all activities:", error);
    res.status(500).json({ message: "Failed to fetch activities" });
  }
});

// Get single activity
router.get("/:id", async (req, res) => {
  try {
    const activityId = parseInt(req.params.id);
    
    if (isUsingDatabase) {
      const [activity] = await db
        .select()
        .from(activities)
        .where(eq(activities.id, activityId));
      
      if (!activity) {
        return res.status(404).json({ message: "Activity not found" });
      }
      
      res.json(activity);
    } else {
      const allActivities = await (storage as any).getActivities();
      const activity = allActivities.find((a: any) => a.id === activityId);
      
      if (!activity) {
        return res.status(404).json({ message: "Activity not found" });
      }
      
      res.json(activity);
    }
  } catch (error) {
    console.error("Error fetching activity:", error);
    res.status(500).json({ message: "Failed to fetch activity" });
  }
});

// Create activity schema
const createActivitySchema = z.object({
  title: z.string().min(1).max(255),
  description: z.string().min(1),
  category: z.string().min(1).max(100),
  imageUrl: z.string().url().optional().nullable(),
  date: z.string().optional().nullable(),
  link: z.string().optional().nullable(),
  displayOrder: z.number().optional().default(0),
  isActive: z.boolean().optional().default(true),
});

// Create activity (admin)
router.post("/", requireAdmin, async (req, res) => {
  try {
    const validatedData = createActivitySchema.parse(req.body);
    
    if (isUsingDatabase) {
      // MySQL/PostgreSQL implementation
      const [newActivity] = await db.insert(activities).values({
        ...validatedData,
        createdAt: new Date(),
        updatedAt: new Date(),
        createdBy: req.user?.id,
        updatedBy: req.user?.id,
      }).returning();
      
      await logAdminAction(
        req.user!.id,
        "CREATE",
        `Created activity: ${newActivity.title}`,
        "activities",
        String(newActivity.id),
        req
      );
      
      res.json(newActivity);
    } else {
      // JSON storage implementation
      const allActivities = await (storage as any).getActivities();
      const newId = allActivities.length > 0 ? Math.max(...allActivities.map((a: any) => a.id)) + 1 : 1;
      
      const newActivity = {
        id: newId,
        ...validatedData,
        imageUrl: validatedData.imageUrl || null,
        date: validatedData.date || null,
        link: validatedData.link || null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        createdBy: req.user?.id,
        updatedBy: req.user?.id,
      };
      
      allActivities.push(newActivity);
      await (storage as any).saveActivities(allActivities);
      
      await logAdminAction(
        req.user!.id,
        "CREATE",
        `Created activity: ${newActivity.title}`,
        "activities",
        String(newActivity.id),
        req
      );
      
      res.json(newActivity);
    }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Invalid data", errors: error.errors });
    }
    console.error("Error creating activity:", error);
    res.status(500).json({ message: "Failed to create activity" });
  }
});

// Update activity schema
const updateActivitySchema = createActivitySchema.partial();

// Update activity (admin)
router.put("/:id", requireAdmin, async (req, res) => {
  try {
    const validatedData = updateActivitySchema.parse(req.body);
    const activityId = parseInt(req.params.id);
    
    if (isUsingDatabase) {
      // MySQL/PostgreSQL implementation
      const [updatedActivity] = await db
        .update(activities)
        .set({
          ...validatedData,
          updatedAt: new Date(),
          updatedBy: req.user?.id,
        })
        .where(eq(activities.id, activityId))
        .returning();
      
      if (!updatedActivity) {
        return res.status(404).json({ message: "Activity not found" });
      }
      
      await logAdminAction(
        req.user!.id,
        "UPDATE",
        `Updated activity: ${updatedActivity.title}`,
        "activities",
        String(activityId),
        req
      );
      
      res.json(updatedActivity);
    } else {
      // JSON storage implementation
      const allActivities = await (storage as any).getActivities();
      const activityIndex = allActivities.findIndex((a: any) => a.id === activityId);
      
      if (activityIndex === -1) {
        return res.status(404).json({ message: "Activity not found" });
      }
      
      const oldActivity = allActivities[activityIndex];
      const updatedActivity = {
        ...oldActivity,
        ...validatedData,
        imageUrl: validatedData.imageUrl !== undefined ? validatedData.imageUrl || null : oldActivity.imageUrl,
        date: validatedData.date !== undefined ? validatedData.date || null : oldActivity.date,
        link: validatedData.link !== undefined ? validatedData.link || null : oldActivity.link,
        updatedAt: new Date().toISOString(),
        updatedBy: req.user?.id,
      };
      
      allActivities[activityIndex] = updatedActivity;
      await (storage as any).saveActivities(allActivities);
      
      await logAdminAction(
        req.user!.id,
        "UPDATE",
        `Updated activity: ${updatedActivity.title}`,
        "activities",
        String(activityId),
        req
      );
      
      res.json(updatedActivity);
    }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Invalid data", errors: error.errors });
    }
    console.error("Error updating activity:", error);
    res.status(500).json({ message: "Failed to update activity" });
  }
});

// Delete activity (admin)
router.delete("/:id", requireAdmin, async (req, res) => {
  try {
    const activityId = parseInt(req.params.id);
    
    if (isUsingDatabase) {
      // MySQL/PostgreSQL implementation
      const [activity] = await db
        .select()
        .from(activities)
        .where(eq(activities.id, activityId));
      
      if (!activity) {
        return res.status(404).json({ message: "Activity not found" });
      }
      
      await db.delete(activities).where(eq(activities.id, activityId));
      
      await logAdminAction(
        req.user!.id,
        "DELETE",
        `Deleted activity: ${activity.title}`,
        "activities",
        String(activityId),
        req
      );
      
      res.json({ message: "Activity deleted successfully" });
    } else {
      // JSON storage implementation
      const allActivities = await (storage as any).getActivities();
      const activityIndex = allActivities.findIndex((a: any) => a.id === activityId);
      
      if (activityIndex === -1) {
        return res.status(404).json({ message: "Activity not found" });
      }
      
      const deletedActivity = allActivities[activityIndex];
      allActivities.splice(activityIndex, 1);
      await (storage as any).saveActivities(allActivities);
      
      await logAdminAction(
        req.user!.id,
        "DELETE",
        `Deleted activity: ${deletedActivity.title}`,
        "activities",
        String(activityId),
        req
      );
      
      res.json({ message: "Activity deleted successfully" });
    }
  } catch (error) {
    console.error("Error deleting activity:", error);
    res.status(500).json({ message: "Failed to delete activity" });
  }
});

export default router;