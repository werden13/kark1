import fs from 'fs/promises';
import path from 'path';
import session from 'express-session';
import createMemoryStore from 'memorystore';
import { 
  type User, 
  type InsertUser, 
  type Event, 
  type InsertEvent, 
  type MediaItem, 
  type InsertMediaItem, 
  type Album, 
  type InsertAlbum, 
  type TeamMember, 
  type InsertTeamMember,
  type HeroSlider,
  type InsertHeroSlider, 
  type ContactMessage, 
  type InsertContactMessage, 
  type Setting, 
  type InsertSetting,
  type DonationMethod,
  type InsertDonationMethod,
  type DonationCampaign,
  type InsertDonationCampaign,
  type ArchiveItem,
  type InsertArchiveItem
} from "@shared/schema";
import { IStorage } from "./storage";

const MemoryStore = createMemoryStore(session);

// Make sure data directory exists
const DATA_DIR = path.join(process.cwd(), 'data');

// Helper function to ensure data directory exists
async function ensureDataDir() {
  try {
    await fs.mkdir(DATA_DIR, { recursive: true });
  } catch (err) {
    console.error('Error creating data directory:', err);
  }
}

// Helper function to read a JSON file
async function readJsonFile<T>(filename: string, defaultValue: T): Promise<T> {
  try {
    await ensureDataDir();
    const filePath = path.join(DATA_DIR, filename);
    const fileExists = await fs.stat(filePath).catch(() => false);
    
    if (!fileExists) {
      await fs.writeFile(filePath, JSON.stringify(defaultValue, null, 2));
      return defaultValue;
    }
    
    const data = await fs.readFile(filePath, 'utf-8');
    return JSON.parse(data) as T;
  } catch (err) {
    console.error(`Error reading file ${filename}:`, err);
    return defaultValue;
  }
}

// Helper function to write to a JSON file
async function writeJsonFile<T>(filename: string, data: T): Promise<void> {
  try {
    await ensureDataDir();
    const filePath = path.join(DATA_DIR, filename);
    await fs.writeFile(filePath, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error(`Error writing file ${filename}:`, err);
    throw err;
  }
}

export class JsonStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24 hours
    });
    // Ensure data directory exists
    ensureDataDir();
  }

  // Auth
  async getUser(id: number): Promise<User | undefined> {
    const users = await readJsonFile<User[]>('users.json', []);
    return users.find(user => user.id === id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const users = await readJsonFile<User[]>('users.json', []);
    return users.find(user => user.username === username);
  }

  async createUser(user: InsertUser): Promise<User> {
    const users = await readJsonFile<User[]>('users.json', []);
    const newId = users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1;
    
    const newUser: User = {
      id: newId,
      ...user,
      createdAt: new Date(),
      isAdmin: user.isAdmin || false,
      role: user.role || "user",
      permissions: user.permissions || []
    };
    
    users.push(newUser);
    await writeJsonFile('users.json', users);
    
    return newUser;
  }
  
  async getAllUsers(): Promise<User[]> {
    return await readJsonFile<User[]>('users.json', []);
  }
  
  async getAllAdmins(): Promise<User[]> {
    const users = await readJsonFile<User[]>('users.json', []);
    return users.filter(user => user.isAdmin);
  }
  
  async banUser(id: string): Promise<void> {
    const users = await readJsonFile<User[]>('users.json', []);
    const numericId = parseInt(id);
    const userIndex = users.findIndex(user => user.id === numericId);
    
    if (userIndex === -1) {
      throw new Error("Kullanıcı bulunamadı");
    }
    
    const user = users[userIndex];
    
    // Major admin kullanıcıları banlanamaz
    if (user.role === 'major_admin') {
      throw new Error("Major admin kullanıcılar banlanamaz");
    }
    
    // Kullanıcıyı 'banned' rolüne güncelle
    users[userIndex] = {
      ...user,
      role: 'banned',
      isAdmin: false
    };
    
    await writeJsonFile('users.json', users);
  }
  
  async unbanUser(id: string): Promise<void> {
    const users = await readJsonFile<User[]>('users.json', []);
    const numericId = parseInt(id);
    const userIndex = users.findIndex(user => user.id === numericId);
    
    if (userIndex === -1) {
      throw new Error("Kullanıcı bulunamadı");
    }
    
    const user = users[userIndex];
    
    // Eğer zaten banlanmamışsa hata fırlatma
    if (user.role !== 'banned') {
      throw new Error("Bu kullanıcı zaten banlanmamış");
    }
    
    // Kullanıcının yasağını kaldır ve 'user' rolüne geri döndür
    users[userIndex] = {
      ...user,
      role: 'user',
      isAdmin: false // Yasağı kaldırınca normal kullanıcı olarak kalsın
    };
    
    await writeJsonFile('users.json', users);
    
    // Sessions klasöründeki oturumları da silelim (JSON implementation için basit bir dokunuş)
    try {
      const sessions = await readJsonFile('sessions.json', []);
      const filteredSessions = sessions.filter(session => 
        !session.passport || session.passport.user !== numericId
      );
      await writeJsonFile('sessions.json', filteredSessions);
    } catch (error) {
      console.error("JSON Storage ile oturumları silerken hata:", error);
      // Hata fırlatmıyoruz, çünkü ana işlevi etkilememeli
    }
  }
  
  async updateAdmin(id: number, data: Partial<InsertUser>): Promise<User | undefined> {
    const users = await readJsonFile<User[]>('users.json', []);
    const index = users.findIndex(user => user.id === id);
    
    if (index === -1) return undefined;
    
    // Update the user, but preserve the ID and createdAt
    users[index] = {
      ...users[index],
      ...data,
      id: users[index].id,
      createdAt: users[index].createdAt
    };
    
    await writeJsonFile('users.json', users);
    return users[index];
  }
  
  async deleteUser(id: number): Promise<void> {
    const users = await readJsonFile<User[]>('users.json', []);
    const filteredUsers = users.filter(user => user.id !== id);
    await writeJsonFile('users.json', filteredUsers);
  }

  // Events
  async getAllEvents(): Promise<Event[]> {
    const events = await readJsonFile<Event[]>('events.json', []);
    return events.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  async getEvent(id: number): Promise<Event | undefined> {
    const events = await readJsonFile<Event[]>('events.json', []);
    return events.find(event => event.id === id);
  }

  async getEventsByCategory(category: string): Promise<Event[]> {
    const events = await readJsonFile<Event[]>('events.json', []);
    return events
      .filter(event => event.category === category)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  async createEvent(event: InsertEvent & { createdBy: number }): Promise<Event> {
    const events = await readJsonFile<Event[]>('events.json', []);
    const newId = events.length > 0 ? Math.max(...events.map(e => e.id)) + 1 : 1;
    
    const newEvent: Event = {
      id: newId,
      ...event,
      imagePath: event.imagePath || null,
      createdBy: event.createdBy || null,
      createdAt: new Date()
    };
    
    events.push(newEvent);
    await writeJsonFile('events.json', events);
    
    return newEvent;
  }

  async updateEvent(id: number, event: InsertEvent): Promise<Event | undefined> {
    const events = await readJsonFile<Event[]>('events.json', []);
    const index = events.findIndex(e => e.id === id);
    
    if (index === -1) return undefined;
    
    const updatedEvent: Event = {
      ...events[index],
      ...event
    };
    
    events[index] = updatedEvent;
    await writeJsonFile('events.json', events);
    
    return updatedEvent;
  }

  async deleteEvent(id: number): Promise<void> {
    const events = await readJsonFile<Event[]>('events.json', []);
    const filteredEvents = events.filter(e => e.id !== id);
    await writeJsonFile('events.json', filteredEvents);
  }

  // Media
  async getAllMedia(): Promise<MediaItem[]> {
    const mediaItems = await readJsonFile<MediaItem[]>('media.json', []);
    return mediaItems.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getMediaByType(type: string): Promise<MediaItem[]> {
    const mediaItems = await readJsonFile<MediaItem[]>('media.json', []);
    return mediaItems
      .filter(item => item.mediaType === type)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getMediaByEvent(eventId: number): Promise<MediaItem[]> {
    const mediaItems = await readJsonFile<MediaItem[]>('media.json', []);
    return mediaItems
      .filter(item => item.eventId === eventId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getAllVideos(): Promise<MediaItem[]> {
    return this.getMediaByType('video');
  }

  async getPhotosByAlbum(albumId: number): Promise<MediaItem[]> {
    const mediaItems = await readJsonFile<MediaItem[]>('media.json', []);
    return mediaItems
      .filter(item => item.albumId === albumId && item.mediaType === 'photo')
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createMediaItem(item: InsertMediaItem & { createdBy: number }): Promise<MediaItem> {
    const mediaItems = await readJsonFile<MediaItem[]>('media.json', []);
    const newId = mediaItems.length > 0 ? Math.max(...mediaItems.map(m => m.id)) + 1 : 1;
    
    const newItem: MediaItem = {
      id: newId,
      ...item,
      description: item.description || null,
      thumbnailPath: item.thumbnailPath || null,
      eventId: item.eventId || null,
      albumId: item.albumId || null,
      createdBy: item.createdBy || null,
      createdAt: new Date()
    };
    
    mediaItems.push(newItem);
    await writeJsonFile('media.json', mediaItems);
    
    return newItem;
  }

  async deleteMediaItem(id: number): Promise<void> {
    const mediaItems = await readJsonFile<MediaItem[]>('media.json', []);
    const filteredItems = mediaItems.filter(m => m.id !== id);
    await writeJsonFile('media.json', filteredItems);
  }

  // Albums
  async getAllAlbums(): Promise<Album[]> {
    const albums = await readJsonFile<Album[]>('albums.json', []);
    return albums.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getAlbum(id: number): Promise<Album | undefined> {
    const albums = await readJsonFile<Album[]>('albums.json', []);
    return albums.find(album => album.id === id);
  }

  async createAlbum(album: InsertAlbum & { createdBy: number }): Promise<Album> {
    const albums = await readJsonFile<Album[]>('albums.json', []);
    const newId = albums.length > 0 ? Math.max(...albums.map(a => a.id)) + 1 : 1;
    
    const newAlbum: Album = {
      id: newId,
      ...album,
      description: album.description || null,
      coverImageId: album.coverImageId || null,
      eventId: album.eventId || null,
      createdBy: album.createdBy || null,
      createdAt: new Date()
    };
    
    albums.push(newAlbum);
    await writeJsonFile('albums.json', albums);
    
    return newAlbum;
  }

  async updateAlbum(id: number, album: InsertAlbum): Promise<Album | undefined> {
    const albums = await readJsonFile<Album[]>('albums.json', []);
    const index = albums.findIndex(a => a.id === id);
    
    if (index === -1) return undefined;
    
    const updatedAlbum: Album = {
      ...albums[index],
      ...album
    };
    
    albums[index] = updatedAlbum;
    await writeJsonFile('albums.json', albums);
    
    return updatedAlbum;
  }

  async deleteAlbum(id: number): Promise<void> {
    const albums = await readJsonFile<Album[]>('albums.json', []);
    const filteredAlbums = albums.filter(a => a.id !== id);
    await writeJsonFile('albums.json', filteredAlbums);
  }

  // Team
  async getAllTeamMembers(): Promise<TeamMember[]> {
    return readJsonFile<TeamMember[]>('team.json', []);
  }

  async createTeamMember(member: InsertTeamMember & { createdBy: number }): Promise<TeamMember> {
    const teamMembers = await readJsonFile<TeamMember[]>('team.json', []);
    const newId = teamMembers.length > 0 ? Math.max(...teamMembers.map(m => m.id)) + 1 : 1;
    
    const newMember: TeamMember = {
      id: newId,
      ...member,
      email: member.email || null,
      imagePath: member.imagePath || null,
      skills: member.skills || null,
      createdBy: member.createdBy || null,
      createdAt: new Date()
    };
    
    teamMembers.push(newMember);
    await writeJsonFile('team.json', teamMembers);
    
    return newMember;
  }

  async updateTeamMember(id: number, member: InsertTeamMember): Promise<TeamMember | undefined> {
    const teamMembers = await readJsonFile<TeamMember[]>('team.json', []);
    const index = teamMembers.findIndex(m => m.id === id);
    
    if (index === -1) return undefined;
    
    const updatedMember: TeamMember = {
      ...teamMembers[index],
      ...member
    };
    
    teamMembers[index] = updatedMember;
    await writeJsonFile('team.json', teamMembers);
    
    return updatedMember;
  }

  async deleteTeamMember(id: number): Promise<void> {
    const teamMembers = await readJsonFile<TeamMember[]>('team.json', []);
    const filteredMembers = teamMembers.filter(m => m.id !== id);
    await writeJsonFile('team.json', filteredMembers);
  }

  // Contact
  async getAllContactMessages(): Promise<ContactMessage[]> {
    const messages = await readJsonFile<ContactMessage[]>('contact.json', []);
    return messages.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createContactMessage(message: InsertContactMessage): Promise<ContactMessage> {
    const messages = await readJsonFile<ContactMessage[]>('contact.json', []);
    const newId = messages.length > 0 ? Math.max(...messages.map(m => m.id)) + 1 : 1;
    
    const newMessage: ContactMessage = {
      id: newId,
      ...message,
      isRead: false,
      createdAt: new Date()
    };
    
    messages.push(newMessage);
    await writeJsonFile('contact.json', messages);
    
    return newMessage;
  }

  async markContactMessageAsRead(id: number): Promise<ContactMessage | undefined> {
    const messages = await readJsonFile<ContactMessage[]>('contact.json', []);
    const index = messages.findIndex(m => m.id === id);
    
    if (index === -1) return undefined;
    
    messages[index].isRead = true;
    await writeJsonFile('contact.json', messages);
    
    return messages[index];
  }

  // Settings
  async getAllSettings(): Promise<Setting[]> {
    return readJsonFile<Setting[]>('settings.json', []);
  }

  async getSetting(key: string): Promise<Setting | undefined> {
    const settings = await readJsonFile<Setting[]>('settings.json', []);
    return settings.find(s => s.key === key);
  }

  async updateSetting(key: string, value: string, userId: number): Promise<Setting> {
    const settings = await readJsonFile<Setting[]>('settings.json', []);
    const index = settings.findIndex(s => s.key === key);
    
    if (index === -1) {
      // Create new setting
      const newId = settings.length > 0 ? Math.max(...settings.map(s => s.id)) + 1 : 1;
      const newSetting: Setting = {
        id: newId,
        key,
        value,
        updatedAt: new Date(),
        updatedBy: userId
      };
      
      settings.push(newSetting);
      await writeJsonFile('settings.json', settings);
      
      return newSetting;
    } else {
      // Update existing setting
      settings[index].value = value;
      settings[index].updatedAt = new Date();
      settings[index].updatedBy = userId;
      
      await writeJsonFile('settings.json', settings);
      
      return settings[index];
    }
  }

  // Donation Methods
  async getAllDonationMethods(): Promise<DonationMethod[]> {
    return readJsonFile<DonationMethod[]>('donation_methods.json', []);
  }

  async getDonationMethod(id: number): Promise<DonationMethod | undefined> {
    const methods = await readJsonFile<DonationMethod[]>('donation_methods.json', []);
    return methods.find(m => m.id === id);
  }

  async createDonationMethod(method: InsertDonationMethod & { createdBy: number; updatedBy: number }): Promise<DonationMethod> {
    const methods = await readJsonFile<DonationMethod[]>('donation_methods.json', []);
    const newId = methods.length > 0 ? Math.max(...methods.map(m => m.id)) + 1 : 1;
    
    const newMethod: DonationMethod = {
      id: newId,
      ...method,
      description: method.description || null,
      branchCode: method.branchCode || null,
      accountNumber: method.accountNumber || null,
      currency: method.currency || null,
      createdBy: method.createdBy || null,
      updatedBy: method.updatedBy || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    methods.push(newMethod);
    await writeJsonFile('donation_methods.json', methods);
    
    return newMethod;
  }

  async updateDonationMethod(id: number, method: InsertDonationMethod & { updatedBy: number }): Promise<DonationMethod | undefined> {
    const methods = await readJsonFile<DonationMethod[]>('donation_methods.json', []);
    const index = methods.findIndex(m => m.id === id);
    
    if (index === -1) return undefined;
    
    const updatedMethod: DonationMethod = {
      ...methods[index],
      ...method,
      updatedAt: new Date()
    };
    
    methods[index] = updatedMethod;
    await writeJsonFile('donation_methods.json', methods);
    
    return updatedMethod;
  }

  async deleteDonationMethod(id: number): Promise<void> {
    const methods = await readJsonFile<DonationMethod[]>('donation_methods.json', []);
    const filteredMethods = methods.filter(m => m.id !== id);
    await writeJsonFile('donation_methods.json', filteredMethods);
  }

  // Donation Campaigns
  async getAllDonationCampaigns(): Promise<DonationCampaign[]> {
    const campaigns = await readJsonFile<DonationCampaign[]>('donation_campaigns.json', []);
    return campaigns.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getDonationCampaign(id: number): Promise<DonationCampaign | undefined> {
    const campaigns = await readJsonFile<DonationCampaign[]>('donation_campaigns.json', []);
    return campaigns.find(c => c.id === id);
  }

  async createDonationCampaign(campaign: InsertDonationCampaign & { createdBy: number; updatedBy: number }): Promise<DonationCampaign> {
    const campaigns = await readJsonFile<DonationCampaign[]>('donation_campaigns.json', []);
    const newId = campaigns.length > 0 ? Math.max(...campaigns.map(c => c.id)) + 1 : 1;
    
    const newCampaign: DonationCampaign = {
      id: newId,
      ...campaign,
      targetAmount: campaign.targetAmount || null,
      currentAmount: campaign.currentAmount || null,
      endDate: campaign.endDate || null,
      imageUrl: campaign.imageUrl || null,
      isActive: campaign.isActive ?? true,
      createdBy: campaign.createdBy || null,
      updatedBy: campaign.updatedBy || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    campaigns.push(newCampaign);
    await writeJsonFile('donation_campaigns.json', campaigns);
    
    return newCampaign;
  }

  async updateDonationCampaign(id: number, campaign: InsertDonationCampaign & { updatedBy: number }): Promise<DonationCampaign | undefined> {
    const campaigns = await readJsonFile<DonationCampaign[]>('donation_campaigns.json', []);
    const index = campaigns.findIndex(c => c.id === id);
    
    if (index === -1) return undefined;
    
    const updatedCampaign: DonationCampaign = {
      ...campaigns[index],
      ...campaign,
      updatedAt: new Date()
    };
    
    campaigns[index] = updatedCampaign;
    await writeJsonFile('donation_campaigns.json', campaigns);
    
    return updatedCampaign;
  }

  async deleteDonationCampaign(id: number): Promise<void> {
    const campaigns = await readJsonFile<DonationCampaign[]>('donation_campaigns.json', []);
    const filteredCampaigns = campaigns.filter(c => c.id !== id);
    await writeJsonFile('donation_campaigns.json', filteredCampaigns);
  }

  // Hero Sliders
  async getAllHeroSliders(): Promise<HeroSlider[]> {
    const sliders = await readJsonFile<HeroSlider[]>('hero_sliders.json', []);
    return sliders.sort((a, b) => a.order - b.order);
  }
  
  async getActiveHeroSliders(): Promise<HeroSlider[]> {
    const sliders = await readJsonFile<HeroSlider[]>('hero_sliders.json', []);
    return sliders
      .filter(s => s.isActive)
      .sort((a, b) => a.order - b.order);
  }
  
  async getHeroSlider(id: number): Promise<HeroSlider | undefined> {
    const sliders = await readJsonFile<HeroSlider[]>('hero_sliders.json', []);
    return sliders.find(s => s.id === id);
  }
  
  async createHeroSlider(slider: InsertHeroSlider & { createdBy: number; updatedBy: number }): Promise<HeroSlider> {
    const sliders = await readJsonFile<HeroSlider[]>('hero_sliders.json', []);
    const newId = sliders.length > 0 ? Math.max(...sliders.map(s => s.id)) + 1 : 1;
    
    // If order is not specified, place at the end
    if (slider.order === undefined || slider.order === 0) {
      slider.order = sliders.length > 0 ? Math.max(...sliders.map(s => s.order)) + 1 : 1;
    }
    
    const newSlider: HeroSlider = {
      id: newId,
      ...slider,
      description: slider.description || null,
      buttonText: slider.buttonText || null,
      buttonLink: slider.buttonLink || null,
      isActive: slider.isActive ?? true,
      order: slider.order,
      createdBy: slider.createdBy || null,
      updatedBy: slider.updatedBy || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    sliders.push(newSlider);
    await writeJsonFile('hero_sliders.json', sliders);
    
    return newSlider;
  }
  
  async updateHeroSlider(id: number, slider: InsertHeroSlider & { updatedBy: number }): Promise<HeroSlider | undefined> {
    const sliders = await readJsonFile<HeroSlider[]>('hero_sliders.json', []);
    const index = sliders.findIndex(s => s.id === id);
    
    if (index === -1) return undefined;
    
    const updatedSlider: HeroSlider = {
      ...sliders[index],
      ...slider,
      updatedAt: new Date()
    };
    
    sliders[index] = updatedSlider;
    await writeJsonFile('hero_sliders.json', sliders);
    
    return updatedSlider;
  }
  
  async deleteHeroSlider(id: number): Promise<void> {
    const sliders = await readJsonFile<HeroSlider[]>('hero_sliders.json', []);
    const filteredSliders = sliders.filter(s => s.id !== id);
    
    // Fix order after deletion
    for (let i = 0; i < filteredSliders.length; i++) {
      filteredSliders[i].order = i + 1;
    }
    
    await writeJsonFile('hero_sliders.json', filteredSliders);
  }
  
  async updateHeroSliderOrder(sliderId: number, newOrder: number): Promise<void> {
    const sliders = await readJsonFile<HeroSlider[]>('hero_sliders.json', []);
    const sliderIndex = sliders.findIndex(s => s.id === sliderId);
    
    if (sliderIndex === -1) return;
    
    const slider = sliders[sliderIndex];
    const currentOrder = slider.order;
    
    // Ensure new order is within bounds
    const maxOrder = sliders.length;
    if (newOrder < 1) newOrder = 1;
    if (newOrder > maxOrder) newOrder = maxOrder;
    
    // Skip if order doesn't change
    if (currentOrder === newOrder) return;
    
    // Update orders
    if (currentOrder < newOrder) {
      // Moving down
      for (const s of sliders) {
        if (s.order > currentOrder && s.order <= newOrder) {
          s.order--;
        }
      }
    } else {
      // Moving up
      for (const s of sliders) {
        if (s.order >= newOrder && s.order < currentOrder) {
          s.order++;
        }
      }
    }
    
    slider.order = newOrder;
    
    await writeJsonFile('hero_sliders.json', sliders);
  }

  // Archive Items Methods
  async getAllArchiveItems(): Promise<ArchiveItem[]> {
    const items = await readJsonFile<ArchiveItem[]>('archive_items.json', []);
    return items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getPublishedArchiveItems(): Promise<ArchiveItem[]> {
    const items = await readJsonFile<ArchiveItem[]>('archive_items.json', []);
    return items
      .filter(item => item.isPublished)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getArchiveItem(id: number): Promise<ArchiveItem | undefined> {
    const items = await readJsonFile<ArchiveItem[]>('archive_items.json', []);
    return items.find(item => item.id === id);
  }

  async createArchiveItem(item: InsertArchiveItem & { createdBy: number; updatedBy: number }): Promise<ArchiveItem> {
    const items = await readJsonFile<ArchiveItem[]>('archive_items.json', []);
    const newId = items.length > 0 ? Math.max(...items.map(i => i.id)) + 1 : 1;
    
    const newItem: ArchiveItem = {
      ...item,
      id: newId,
      viewCount: 0,
      location: item.location || null,
      participants: item.participants || null,
      outcome: item.outcome || null,
      content: item.content || null,
      imageUrl: item.imageUrl || null,
      videoUrl: item.videoUrl || null,
      documentUrl: item.documentUrl || null,
      tags: item.tags || null,
      isPublished: item.isPublished ?? false,
      isFeatured: item.isFeatured ?? false,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    items.push(newItem);
    await writeJsonFile('archive_items.json', items);
    return newItem;
  }

  async updateArchiveItem(id: number, item: InsertArchiveItem & { updatedBy: number }): Promise<ArchiveItem | undefined> {
    const items = await readJsonFile<ArchiveItem[]>('archive_items.json', []);
    const itemIndex = items.findIndex(i => i.id === id);
    
    if (itemIndex === -1) return undefined;
    
    const updatedItem: ArchiveItem = {
      ...items[itemIndex],
      ...item,
      updatedAt: new Date(),
    };
    
    items[itemIndex] = updatedItem;
    await writeJsonFile('archive_items.json', items);
    return updatedItem;
  }

  async deleteArchiveItem(id: number): Promise<void> {
    const items = await readJsonFile<ArchiveItem[]>('archive_items.json', []);
    const filteredItems = items.filter(item => item.id !== id);
    await writeJsonFile('archive_items.json', filteredItems);
  }

  async toggleArchiveItemPublish(id: number, isPublished: boolean): Promise<ArchiveItem | undefined> {
    const items = await readJsonFile<ArchiveItem[]>('archive_items.json', []);
    const itemIndex = items.findIndex(i => i.id === id);
    
    if (itemIndex === -1) return undefined;
    
    items[itemIndex].isPublished = isPublished;
    items[itemIndex].updatedAt = new Date();
    
    await writeJsonFile('archive_items.json', items);
    return items[itemIndex];
  }

  async toggleArchiveItemFeatured(id: number, isFeatured: boolean): Promise<ArchiveItem | undefined> {
    const items = await readJsonFile<ArchiveItem[]>('archive_items.json', []);
    const itemIndex = items.findIndex(i => i.id === id);
    
    if (itemIndex === -1) return undefined;
    
    items[itemIndex].isFeatured = isFeatured;
    items[itemIndex].updatedAt = new Date();
    
    await writeJsonFile('archive_items.json', items);
    return items[itemIndex];
  }

  async incrementArchiveItemViews(id: number): Promise<void> {
    const items = await readJsonFile<ArchiveItem[]>('archive_items.json', []);
    const itemIndex = items.findIndex(i => i.id === id);
    
    if (itemIndex !== -1) {
      items[itemIndex].viewCount = (items[itemIndex].viewCount || 0) + 1;
      await writeJsonFile('archive_items.json', items);
    }
  }

  // Activities
  async getActivities(): Promise<any[]> {
    try {
      return await readJsonFile<any[]>('activities.json', []);
    } catch (error) {
      // If file doesn't exist, return empty array
      return [];
    }
  }

  async saveActivities(activities: any[]): Promise<void> {
    await writeJsonFile('activities.json', activities);
  }
}

// Helper function to hash password like in auth.ts
async function hashPassword(password: string) {
  const crypto = await import('crypto');
  const salt = crypto.randomBytes(16).toString('hex');
  const buf = await new Promise<Buffer>((resolve, reject) => {
    crypto.scrypt(password, salt, 64, (err, derivedKey) => {
      if (err) reject(err);
      resolve(derivedKey);
    });
  });
  return `${buf.toString('hex')}.${salt}`;
}

// Create a sample admin user if none exists
async function initializeAdmin() {
  const users = await readJsonFile<User[]>('users.json', []);
  if (users.length === 0) {
    const adminUser: User = {
      id: 1,
      username: 'admin',
      // Use the same hash algorithm as in auth.ts
      password: await hashPassword('Admin123!'),
      firstName: 'Admin',
      lastName: 'User',
      email: 'admin@example.com',
      isAdmin: true,
      role: 'major_admin',
      permissions: null,
      createdAt: new Date()
    };
    
    users.push(adminUser);
    await writeJsonFile('users.json', users);
    console.log('Created initial admin user');
  }
}

// Initialize the storage
export const jsonStorage = new JsonStorage();
initializeAdmin();