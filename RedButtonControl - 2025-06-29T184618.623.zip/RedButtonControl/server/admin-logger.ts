import { Request, Response, NextFunction } from "express";
import fs from 'fs/promises';
import path from 'path';

interface AdminLog {
  id: number;
  userId: number;
  action: string;
  details?: string;
  ipAddress?: string;
  userAgent?: string;
  resourceType?: string;
  resourceId?: string;
  timestamp: string;
}

const ADMIN_LOGS_FILE = path.join(process.cwd(), 'data', 'admin_logs.json');

// Helper function to read admin logs
async function readAdminLogs(): Promise<AdminLog[]> {
  try {
    const data = await fs.readFile(ADMIN_LOGS_FILE, 'utf-8');
    return JSON.parse(data) || [];
  } catch (error) {
    console.error('Error reading admin logs:', error);
    return [];
  }
}

// Helper function to write admin logs
async function writeAdminLogs(logs: AdminLog[]): Promise<void> {
  try {
    await fs.writeFile(ADMIN_LOGS_FILE, JSON.stringify(logs, null, 2));
  } catch (error) {
    console.error('Error writing admin logs:', error);
  }
}

// Function to log admin actions
export async function logAdminAction(
  userId: number,
  action: string,
  details?: string,
  resourceType?: string,
  resourceId?: string,
  req?: Request
): Promise<void>;
export async function logAdminAction(
  userId: number,
  action: string,
  details: string,
  ipAddress: string,
  userAgent: string,
  resourceType: string,
  resourceId: string
): Promise<void>;
export async function logAdminAction(
  userId: number,
  action: string,
  details?: string,
  resourceTypeOrIpAddress?: string | Request,
  resourceIdOrUserAgent?: string,
  reqOrResourceType?: Request | string,
  resourceId?: string
) {
  try {
    let ipAddress: string;
    let userAgent: string;
    let resourceType: string | undefined;
    let finalResourceId: string | undefined;
    
    // Handle overloaded function signatures
    if (typeof resourceTypeOrIpAddress === 'string' && typeof resourceIdOrUserAgent === 'string' && typeof reqOrResourceType === 'string') {
      // Called with direct IP and user agent
      ipAddress = resourceTypeOrIpAddress;
      userAgent = resourceIdOrUserAgent;
      resourceType = reqOrResourceType;
      finalResourceId = resourceId;
    } else {
      // Called with Request object
      const req = reqOrResourceType as Request | undefined;
      ipAddress = req?.ip || "";
      userAgent = req?.headers["user-agent"] || "";
      resourceType = resourceTypeOrIpAddress as string | undefined;
      finalResourceId = resourceIdOrUserAgent as string | undefined;
    }
    
    // Read existing logs
    const logs = await readAdminLogs();
    
    // Create new log entry
    const newLog: AdminLog = {
      id: logs.length > 0 ? Math.max(...logs.map(l => l.id)) + 1 : 1,
      userId,
      action,
      details,
      ipAddress,
      userAgent,
      resourceType,
      resourceId: finalResourceId,
      timestamp: new Date().toISOString()
    };
    
    // Add new log to the beginning (most recent first)
    logs.unshift(newLog);
    
    // Keep only the last 1000 logs to prevent the file from growing too large
    if (logs.length > 1000) {
      logs.splice(1000);
    }
    
    // Write back to file
    await writeAdminLogs(logs);
    
    // Log the action for debugging
    console.log(`Admin action logged: ${action} by user ${userId} with details: ${details || 'No details'} (${resourceType || 'no resource type'})`);
  } catch (error) {
    console.error("Error logging admin action:", error);
  }
}

// Middleware to log all API requests by admins
export function adminActionLogger(req: Request, res: Response, next: NextFunction) {
  // Track actions for both admin and supermanager (major_admin) users
  const user = req.user as any;
  if (user && (user.role === 'admin' || user.role === 'major_admin')) {
    // We'll log the action once the response is completed
    res.on('finish', () => {
      // Log all successful API actions except for GET requests since those are just data retrieval
      if (res.statusCode >= 200 && res.statusCode < 300 && req.path.startsWith('/api/') && 
          (req.method !== 'GET' || req.path.includes('mark-read'))) {
        const userId = user.id;
        const method = req.method;
        const path = req.path;
        const username = user.username || 'Bilinmeyen kullanıcı';
        
        console.log(`Admin action captured: ${method} ${path} by ${username}`);
        
        // Create an action name based on the HTTP method and path
        let action = `${method} ${path}`;
        
        // Parse resource type from path (e.g., /api/events => events)
        const pathParts = path.split('/');
        let resourceType: string | undefined = pathParts.length > 2 ? pathParts[2] : undefined;
        
        // Handle special cases for different resource types
        if (path.includes('/donation/methods') || path.includes('/donation-methods')) {
          resourceType = 'donation-methods';
        } else if (path.includes('/donation/campaigns') || path.includes('/donation-campaigns')) {
          resourceType = 'donation-campaigns';
        } else if (pathParts.length > 3 && pathParts[2] === 'donation') {
          resourceType = 'donations';
        } else if (pathParts.length > 3 && pathParts[2] === 'contact') {
          resourceType = 'contact';
        } else if (path.includes('/media')) {
          resourceType = 'media';
        } else if (path.includes('/hero-sliders')) {
          resourceType = 'sliders';
        } else if (pathParts.length > 3 && pathParts[2] === 'admin-logs') {
          resourceType = 'security';
        } else if (resourceType === 'hero-sliders') {
          resourceType = 'sliders';
        } 
        
        // Log for debugging
        console.log(`Logging admin action: ${method} ${path} => resourceType: ${resourceType}`);
        
        
        // Extract resource ID if present in the URL
        let resourceId = req.params.id;
        
        // If the ID is in the path but not in params, extract it
        if (!resourceId && pathParts.length > 3) {
          const potentialId = pathParts[3];
          if (/^\d+$/.test(potentialId)) {
            resourceId = potentialId;
          }
        }
        
        // For requests with bodies (POST, PUT, PATCH), include a sanitized version of the body
        let details = "";
        if (["POST", "PUT", "PATCH"].includes(method) && req.body) {
          // Create a sanitized copy of req.body to remove sensitive information
          const sanitizedBody = { ...req.body };
          
          // Remove sensitive fields like passwords
          if (sanitizedBody.password) sanitizedBody.password = "<redacted>";
          if (sanitizedBody.confirmPassword) sanitizedBody.confirmPassword = "<redacted>";
          
          // Debug log to see what's in the request body for troubleshooting
          console.log(`Admin action request body: ${method} ${path} => ${JSON.stringify(sanitizedBody).substring(0, 100)}`);
          
          // Add more context for specific actions based on resource type
          if (method === "POST" && resourceType === "events") {
            details = `Yeni etkinlik oluşturuldu: ${sanitizedBody.title}`;
            action = "Etkinlik Ekleme";
          } else if (method === "PUT" && resourceType === "events") {
            details = `Etkinlik güncellendi: ${sanitizedBody.title}`;
            action = "Etkinlik Güncelleme";
          } else if (method === "DELETE" && resourceType === "events") {
            details = `Etkinlik silindi, ID: ${resourceId}`;
            action = "Etkinlik Silme";
          } else if (method === "POST" && (resourceType === "media" || path.includes('/media'))) {
            details = `Yeni medya eklendi: ${sanitizedBody.title || sanitizedBody.name || 'Başlıksız'}`;
            action = "Medya Ekleme";
            resourceType = "media";
          } else if (method === "PUT" && (resourceType === "media" || path.includes('/media'))) {
            details = `Medya güncellendi: ${sanitizedBody.title || sanitizedBody.name || 'Başlıksız'}`;
            action = "Medya Güncelleme";
            resourceType = "media";
          } else if (method === "DELETE" && (resourceType === "media" || path.includes('/media'))) {
            details = `Medya silindi, ID: ${resourceId}`;
            action = "Medya Silme";
            resourceType = "media";
          } else if (method === "POST" && resourceType === "contact") {
            details = `İletişim mesajı işlendi: ${sanitizedBody.subject || 'Belirtilmemiş'}`;
          } else if (method === "PUT" && resourceType === "settings") {
            // For settings, create a more detailed description
            if (Array.isArray(sanitizedBody)) {
              details = `Ayarlar güncellendi: ${sanitizedBody.map(s => s.key || 'bilinmeyen').join(', ')}`;
              action = "Ayarlar kaydedildi"; // Overwrite action for better clarity
            } else if (sanitizedBody.key) {
              details = `Ayar güncellendi: ${sanitizedBody.key}`;
              action = "Ayar kaydedildi";  // Overwrite action for better clarity
            } else {
              details = `Ayarlar güncellendi`;
              action = "Ayarlar kaydedildi"; // Overwrite action for better clarity
            }
          } else if (method === "POST" && resourceType === "albums") {
            details = `Yeni albüm oluşturuldu: ${sanitizedBody.title || 'Başlıksız'}`;
          } else if (method === "PUT" && resourceType === "albums") {
            details = `Albüm güncellendi: ${sanitizedBody.title || 'Başlıksız'}`;
          } else if (method === "DELETE" && resourceType === "albums") {
            details = `Albüm silindi, ID: ${resourceId}`;
          } else if (method === "POST" && resourceType === "team") {
            details = `Yeni ekip üyesi eklendi: ${sanitizedBody.name || 'İsimsiz'}`;
          } else if (method === "PUT" && resourceType === "team") {
            details = `Ekip üyesi güncellendi: ${sanitizedBody.name || 'İsimsiz'}`;
          } else if (method === "DELETE" && resourceType === "team") {
            details = `Ekip üyesi silindi, ID: ${resourceId}`;
          } else if (method === "POST" && (resourceType === "donation-methods" || path.includes('/donation') || path.includes('/donation-methods'))) {
            details = `Yeni bağış yöntemi eklendi: ${sanitizedBody.bankName || sanitizedBody.title || sanitizedBody.name || 'Başlıksız'}`;
            action = "Bağış Yöntemi Eklendi";
            resourceType = "donation-methods";
          } else if (method === "PUT" && (resourceType === "donation-methods" || path.includes('/donation') || path.includes('/donation-methods'))) {
            details = `Bağış yöntemi güncellendi: ${sanitizedBody.bankName || sanitizedBody.title || sanitizedBody.name || 'Başlıksız'}`;
            action = "Bağış Yöntemi Güncellendi";
            resourceType = "donation-methods";
          } else if (method === "DELETE" && (resourceType === "donation-methods" || path.includes('/donation') || path.includes('/donation-methods'))) {
            details = `Bağış yöntemi silindi, ID: ${resourceId}`;
            action = "Bağış Yöntemi Silindi";
            resourceType = "donation-methods";
          } else if (method === "POST" && resourceType === "donation-campaigns") {
            details = `Yeni bağış kampanyası oluşturuldu: ${sanitizedBody.title || 'Başlıksız'}`;
            action = "Bağış kampanyası eklendi";
          } else if (method === "PUT" && resourceType === "donation-campaigns") {
            details = `Bağış kampanyası güncellendi: ${sanitizedBody.title || 'Başlıksız'}`;
            action = "Bağış kampanyası güncellendi";
          } else if (method === "DELETE" && resourceType === "donation-campaigns") {
            details = `Bağış kampanyası silindi, ID: ${resourceId}`;
            action = "Bağış kampanyası silindi";
          } else {
            // For other actions, use a more generic approach
            details = `${username} tarafından işlem yapıldı: ${JSON.stringify(sanitizedBody).substring(0, 200)}`;
            if (JSON.stringify(sanitizedBody).length > 200) {
              details += '...';
            }
          }
        } else if (method === "DELETE") {
          // Handle DELETE requests without body
          details = `${resourceType ? resourceType.charAt(0).toUpperCase() + resourceType.slice(1) : 'Öğe'} silindi, ID: ${resourceId}`;
        } else if (method === "GET" && path.includes("/mark-read")) {
          // Handle marking messages as read
          details = `İletişim mesajı okundu olarak işaretlendi, ID: ${resourceId}`;
        }
        
        // Log all successful admin actions
        logAdminAction(userId, action, details, resourceType, resourceId, req);
      }
    });
  }
  
  next();
}