const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('Starting KARK Website Server...');

// Create a detached process
const serverProcess = exec('node_modules/.bin/tsx server/index.ts', {
  detached: true,
  stdio: 'ignore',
  cwd: process.cwd()
});

// Save the PID
fs.writeFileSync('server.pid', serverProcess.pid.toString());

// Detach from the parent process
serverProcess.unref();

console.log(`KARK Website server started with PID: ${serverProcess.pid}`);
console.log('Server running on http://localhost:5000');
process.exit(0);