# cPanel Komple Deployment Rehberi

## Problem: İki Farklı package.json
- **Replit package.json**: TypeScript, Vite, Drizzle gibi geliştirme araçları içeriyor
- **cPanel package.json**: Sadece Express ve temel bağımlılıklar içermeli

## Çözüm: Dosya Organizasyonu

### 1. İndirmeniz Gereken Dosyalar:
```
kark-cpanel/
├── server.js (ana sunucu dosyası)
├── package.json (package-cpanel.json'dan kopyalanmış içerik)
├── .env (veritabanı bilgilerinizle)
├── client/ (tüm frontend dosyaları)
│   ├── index.html
│   └── src/
├── public/ (statik dosyalar)
├── data/ (JSON yedekleri)
└── kark_complete_database_cpanel_fixed.sql
```

### 2. Package.json Hazırlama:
**Bilgisayarınızda:**
1. `package-cpanel.json` dosyasını açın
2. İçeriğini kopyalayın
3. Yeni bir `package.json` dosyası oluşturup içeriği yapıştırın
4. Kaydedin

### 3. Veritabanı Komutları:
cPanel'de veritabanı oluşturmak için komut gerekmez, grafiksel arayüz kullanılır:

**cPanel MySQL Databases Sayfasında:**
- Veritabanı oluştur: Kutuya `kark` yazıp butona tıklayın
- Kullanıcı oluştur: `karkuser` ve şifre girip butona tıklayın  
- Kullanıcıyı veritabanına ekle: Açılır menülerden seçip ekleyin
- ALL PRIVILEGES verin

### 4. SQL Dosyasını İçe Aktarma:
**phpMyAdmin'de:**
1. Sol taraftan veritabanınızı seçin
2. Import/İçe Aktar sekmesine tıklayın
3. `kark_complete_database_cpanel_fixed.sql` dosyasını seçin
4. Go/Git butonuna tıklayın

### 5. Node.js Uygulaması Kurulumu:
**cPanel Node.js Selector'da:**
1. Create Application tıklayın
2. Node.js version: 16 veya üstü
3. Application mode: Production
4. Application root: dosyalarınızın olduğu klasör
5. Application startup file: `server.js`
6. Run NPM Install butonuna tıklayın

## Önemli Notlar:
- Frontend dosyaları (`client/`) olduğu gibi kopyalanır
- Sadece `package.json` içeriği değişir
- Veritabanı işlemleri cPanel arayüzünden yapılır, komut gerekmez
- `.env` dosyasında `DB_TYPE=mysql` olmalı

## Sorun Giderme:
**"Module not found" hatası alırsanız:**
- cPanel'de NPM Install butonuna tekrar tıklayın
- Bağımlılıklar `package.json`'dan otomatik yüklenir

**Veritabanı bağlantı hatası:**
- `.env` dosyasındaki bilgileri kontrol edin
- cPanel prefix'ini doğru yazdığınızdan emin olun