# cPanel için Dosya Organizasyonu

## Gerekli Dosyalar ve Klasörler

### 1. Frontend Dosyaları (client klasörü)
`client/` klasörü içindeki TÜM dosyalar gerekli:
- `index.html`
- `src/` klasörü ve içindeki tüm React/TypeScript dosyaları
- Bu dosyalar tarayıcıda çalışacak, cPanel'de derlenmeyecek

### 2. Backend için Package.json
**DİKKAT:** cPanel'de TypeScript çalışmaz, bu yüzden:
- `server.js` kullanıyoruz (TypeScript değil)
- `package-cpanel.json` içeriğini `package.json` olarak kullanıyoruz

### 3. Dosya Düzeni
```
cPanel'e yüklenecek klasör:
├── server.js (Express sunucu)
├── package.json (package-cpanel.json'dan)
├── .env (MySQL bilgileri)
├── client/
│   ├── index.html
│   ├── src/
│   │   ├── App.tsx
│   │   ├── components/
│   │   └── (diğer tüm React dosyaları)
├── public/
│   └── (resimler, logolar)
└── data/
    └── (JSON yedek dosyaları)
```

## Neden Frontend Dosyaları Gerekli?
- `client/` klasöründeki dosyalar sitenizin görünümü
- Bu dosyalar olmadan site boş görünür
- Tarayıcı bu dosyaları `server.js` üzerinden yükler

## Veritabanı Kurulumu
cPanel'de komut satırı yerine:
1. **MySQL Databases** sayfasından veritabanı oluşturun
2. **phpMyAdmin**'den SQL dosyasını import edin
3. Komut yazmaya gerek yok, tıklayarak yapılır

## Özet
- Frontend dosyaları (`client/`) → Olduğu gibi kopyala
- Backend package.json → `package-cpanel.json` içeriğini kullan
- Veritabanı → cPanel arayüzünden oluştur