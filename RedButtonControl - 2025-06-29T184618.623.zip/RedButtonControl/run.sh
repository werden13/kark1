#!/bin/bash
cd /home/runner/workspace
export NODE_ENV=development
export DB_TYPE=json
exec node_modules/.bin/tsx server/index.ts