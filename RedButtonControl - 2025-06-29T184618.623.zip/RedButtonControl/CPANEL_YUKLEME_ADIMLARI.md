# cPanel'e Yükleme - Çakışmasız Yöntem

## Yöntem 1: Bilgisayarınızda Düzenleme
1. **Yeni bir klasör oluşturun** (örn: `kark-cpanel`)
2. **İçine kopyalayın:**
   - `server.js`
   - `.env.example`
   - `client/` klasörü
   - `public/` klasörü
   - `data/` klasörü
3. **package-cpanel.json dosyasını açın**, içeriğini kopyalayın
4. **Yeni bir dosya oluşturun**, adını `package.json` yapın ve içeriği yapıştırın
5. Bu klasörü zip'leyip cPanel'e yükleyin

## Yöntem 2: cPanel'de Düzenleme
1. **cPanel File Manager'da:**
   - Tüm dosyaları yükleyin (package.json hariç)
   - `package-cpanel.json` dosyasını yükleyin
2. **File Manager'da:**
   - `package-cpanel.json` dosyasını kopyalayın (Copy)
   - Kopyayı `package.json` olarak yeniden adlandırın
   - Orijinal `package-cpanel.json` dosyasını silin

## En Kolay Yöntem:
**Sadece ihtiyacınız olan dosyaları indirin:**
- ❌ Replit'teki `package.json` - İNDİRMEYİN
- ✅ `package-cpanel.json` - İndirip `package.json` olarak kaydedin
- ✅ Diğer tüm dosyalar

Bu şekilde çakışma olmaz!