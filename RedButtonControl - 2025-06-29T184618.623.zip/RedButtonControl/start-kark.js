const { spawn } = require('child_process');
const path = require('path');

console.log('Starting KARK website server...');

const serverProcess = spawn('node_modules/.bin/tsx', ['server/index.ts'], {
  cwd: process.cwd(),
  stdio: 'inherit',
  env: {
    ...process.env,
    NODE_ENV: 'development',
    DB_TYPE: 'json'
  }
});

serverProcess.on('error', (err) => {
  console.error('Failed to start server:', err);
});

serverProcess.on('close', (code) => {
  console.log(`Server process exited with code ${code}`);
});

// Keep the process alive
process.on('SIGINT', () => {
  console.log('Stopping KARK website server...');
  serverProcess.kill();
  process.exit();
});