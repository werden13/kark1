import { db } from "../server/db";
import { users } from "../shared/schema";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function fixSupermanager() {
  try {
    // Hash the password properly
    const hashedPassword = await hashPassword("supermanager123");
    console.log("New hashed password:", hashedPassword);
    
    // Delete any existing supermanager (start fresh)
    await db.delete(users).where(users.username.eq("supermanager")).execute();
    
    // Create a new supermanager with properly hashed password
    const insertedUser = await db.insert(users).values({
      username: "supermanager",
      password: hashedPassword,
      firstName: "Super",
      lastName: "Manager",
      email: "super@example.com",
      isAdmin: true,
      role: "major_admin",
      permissions: ["manage_users", "manage_events", "manage_media", "manage_team", "manage_donations", "manage_settings", "manage_sliders", "manage_admins"],
    }).returning();
    
    console.log("Supermanager account fixed:", insertedUser[0]);
    
    // Also create a simple test user
    const testPassword = await hashPassword("test123");
    await db.delete(users).where(users.username.eq("test")).execute();
    const testUser = await db.insert(users).values({
      username: "test",
      password: testPassword,
      firstName: "Test",
      lastName: "User",
      email: "test@example.com",
      isAdmin: false,
      role: "user",
      permissions: null,
    }).returning();
    
    console.log("Test user created:", testUser[0]);
    console.log("\nLogin credentials:");
    console.log("Supermanager: username=supermanager, password=supermanager123");
    console.log("Test User: username=test, password=test123");
    
  } catch (error) {
    console.error("Error fixing supermanager account:", error);
  }
}

fixSupermanager();