# How to Update Your .env File

## Getting Your Database Credentials from cPanel:

1. **Log into your cPanel**

2. **Find MySQL Database Section**
   - Look for "MySQL Databases" or "Databases" section

3. **Your Database Credentials:**
   - **DB_HOST**: Usually "localhost" (keep as is)
   - **DB_USER**: Your cPanel username or a database user you create
   - **DB_NAME**: The database name you created in phpMyAdmin
   - **DB_PASSWORD**: The password for your database user

## Example with actual values:

If your cPanel username is "mysite" and you created a database called "mysite_archive":

```
DB_HOST=localhost
DB_USER=mysite_dbuser
DB_PASSWORD=YourActualPassword123!
DB_NAME=mysite_archive
DB_PORT=3306
```

## Important Security Notes:

1. **Never commit the .env file to git**
2. **Use a strong password**
3. **Change the SESSION_SECRET to a random string**

## After Updating:

Once you update the .env file with real values, your application will automatically connect to MySQL instead of using JSON files.