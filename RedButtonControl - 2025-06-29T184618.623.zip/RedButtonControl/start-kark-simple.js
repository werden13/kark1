import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { promises as fs } from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'client')));
app.use('/public', express.static(path.join(__dirname, 'public')));

// Simple data storage functions
async function readJsonFile(filename) {
  try {
    const data = await fs.readFile(path.join(__dirname, 'data', filename), 'utf8');
    return JSON.parse(data);
  } catch (error) {
    return [];
  }
}

// API Routes for KARK website
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', storage: 'json' });
});

app.get('/api/archive', async (req, res) => {
  try {
    const items = await readJsonFile('archive_items.json');
    res.json(items);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch archive items' });
  }
});

app.get('/api/events', async (req, res) => {
  try {
    const events = await readJsonFile('events.json');
    res.json(events);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch events' });
  }
});

app.get('/api/media', async (req, res) => {
  try {
    const media = await readJsonFile('media.json');
    res.json(media);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch media' });
  }
});

app.get('/api/settings', async (req, res) => {
  try {
    const settingsArray = await readJsonFile('settings.json');
    const settings = settingsArray[0] || {};
    res.json(settings);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch settings' });
  }
});

// Serve React app
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'client', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`KARK Website running on port ${PORT}`);
  console.log('Access your website at http://localhost:5000');
});