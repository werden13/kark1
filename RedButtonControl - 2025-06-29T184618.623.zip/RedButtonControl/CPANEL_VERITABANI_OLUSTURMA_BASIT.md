# cPanel'de Yeni Veritabanı Oluşturma - Basit Anlatım

## 1. cPanel'e Giriş
- Hosting firmanızın verdiği cPanel linkine gidin
- Kullanıcı adı ve şifrenizi girin

## 2. MySQL Databases'i Bulun
- cPanel ana sayfasında aşağı kaydırın
- "Databases" veya "Veritabanları" bölümünü bulun
- "MySQL Databases" yazısına tıklayın

## 3. Yeni Veritabanı Oluştur
**"Create New Database" veya "Yeni Veritabanı Oluştur" bölümünde:**

- Kutuya sadece `kark` yazın
- "Create Database" veya "Veritabanı Oluştur" butonuna tıklayın
- Sistem otomatik olarak başına bir şeyler ekleyecek (örn: `siteniz_kark`)

## 4. Kullanıcı Oluştur
**Aynı sayfada biraz aşağıda "MySQL Users" veya "MySQL Kullanıcıları" bölümü:**

- Username kutusuna: `karkuser` yazın
- Password kutusuna: Güçlü bir şifre yazın (veya Generate Password'e tıklayın)
- **ŞİFREYİ BİR YERE YAZIN!**
- "Create User" veya "Kullanıcı Oluştur" butonuna tıklayın

## 5. Kullanıcıyı Veritabanına Bağla
**"Add User To Database" veya "Kullanıcıyı Veritabanına Ekle" bölümünde:**

- İlk kutuda: Oluşturduğunuz kullanıcıyı seçin
- İkinci kutuda: Oluşturduğunuz veritabanını seçin
- "Add" veya "Ekle" butonuna tıklayın

## 6. Yetki Ver
**Yeni açılan sayfada:**

- En üstteki "ALL PRIVILEGES" kutusunu işaretleyin
- "Make Changes" veya "Değişiklikleri Kaydet" butonuna tıklayın

## İşlem Tamamlandı! 

**Not Etmeniz Gerekenler:**
- Veritabanı adı: `siteniz_kark` (tam adı cPanel'de gösterir)
- Kullanıcı adı: `siteniz_karkuser` (tam adı cPanel'de gösterir)
- Şifre: Oluşturduğunuz şifre

## Örnek:
Eğer hosting firmanız size `mysite` prefix'i verdiyse:
- Veritabanı: `mysite_kark`
- Kullanıcı: `mysite_karkuser`
- Şifre: sizin belirlediğiniz

Bu bilgileri daha sonra site ayarlarında kullanacaksınız.