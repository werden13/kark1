const express = require('express');
const path = require('path');
const cors = require('cors');
const fs = require('fs');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'dist/public')));

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'KARK website is running' });
});

// Serve client app for all other routes
app.get('*', (req, res) => {
  const indexPath = path.join(__dirname, 'client', 'index.html');
  if (fs.existsSync(indexPath)) {
    res.sendFile(indexPath);
  } else {
    res.status(200).send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>KARK Website</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 40px; }
          h1 { color: #333; }
          p { color: #666; }
          .status { background: #4CAF50; color: white; padding: 10px; border-radius: 5px; display: inline-block; }
        </style>
      </head>
      <body>
        <h1>KARK Website</h1>
        <p class="status">✓ Server is running successfully on port ${PORT}</p>
        <p>Your Node.js application is configured for Ubuntu 22.04 LTS</p>
        <p>API endpoint: <a href="/api/health">/api/health</a></p>
      </body>
      </html>
    `);
  }
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`KARK website server running on http://0.0.0.0:${PORT}`);
});