import pg from 'pg';
const { Client } = pg;

const client = new Client({
  connectionString: process.env.DATABASE_URL || 'postgresql://user:password@localhost:5432/kark_db',
});

async function testAdminLogs() {
  try {
    await client.connect();
    console.log('Connected to database successfully.\n');
    console.log('Testing admin logs functionality...\n');

    // First, check if the admin_logs table exists
    const tableCheck = await client.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'admin_logs'
      );
    `);

    if (!tableCheck.rows[0].exists) {
      console.error('ERROR: admin_logs table does not exist!');
      console.log('Creating admin_logs table...');
      
      // Create the table if it doesn't exist
      await client.query(`
        CREATE TABLE IF NOT EXISTS admin_logs (
          id SERIAL PRIMARY KEY,
          user_id INTEGER NOT NULL,
          action VARCHAR(255) NOT NULL,
          details TEXT,
          ip_address VARCHAR(45),
          user_agent TEXT,
          resource_type VARCHAR(50),
          resource_id VARCHAR(100),
          timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
      `);
      
      console.log('Table created successfully!\n');
    }

    // Check current logs
    const logsResult = await client.query('SELECT COUNT(*) as count FROM admin_logs');
    console.log(`Current number of logs: ${logsResult.rows[0].count}\n`);

    // Insert a test log
    console.log('Inserting test log entry...');
    await client.query(`
      INSERT INTO admin_logs (
        user_id, 
        action, 
        details, 
        resource_type,
        resource_id,
        ip_address
      ) VALUES (
        1, 
        'Test Action', 
        'This is a test log entry to verify the system is working', 
        'test',
        '1',
        '127.0.0.1'
      )
    `);

    console.log('Test log inserted successfully!\n');

    // Query recent logs
    const recentLogs = await client.query(`
      SELECT * FROM admin_logs 
      ORDER BY timestamp DESC 
      LIMIT 5
    `);

    console.log('Recent admin logs:');
    recentLogs.rows.forEach(log => {
      console.log(`- [${log.timestamp}] ${log.action} by user ${log.user_id}`);
    });

    console.log('\nAdmin logs system is working correctly!');
    
  } catch (error) {
    console.error('Error testing admin logs:', error);
  } finally {
    await client.end();
  }
}

testAdminLogs();