# cPanel MySQL Setup Instructions for KARK Website

## Overview
This guide helps you set up the KARK website with MySQL database on cPanel hosting.

## Step 1: Create MySQL Database in cPanel

1. **Log into your cPanel**
2. **Go to MySQL Databases**
3. **Create a new database:**
   - Database Name: `kark_database` (or your preferred name)
   - Note: cPanel will automatically prefix it (e.g., `youruser_kark_database`)

4. **Create a MySQL user:**
   - Username: `kark_user` (or your preferred name)
   - Password: Generate a strong password
   - Note: cPanel will automatically prefix it (e.g., `youruser_kark_user`)

5. **Add user to database:**
   - Select your database and user
   - Grant **ALL PRIVILEGES**

## Step 2: Import Database Structure

1. **Go to phpMyAdmin in cPanel**
2. **Select your database**
3. **Click Import tab**
4. **Upload the SQL file:**
   - Use `kark_complete_database_cpanel.sql`
   - Before importing, edit the file and replace:
     - `kark_` with your database prefix (e.g., `youruser_kark_`)
     - Or use find/replace in your text editor

## Step 3: Update Environment Variables

Create or update your `.env` file with your cPanel MySQL credentials:

```env
# Database configuration
DB_TYPE=mysql

# MySQL configuration for cPanel
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_USER=youruser_kark_user
MYSQL_PASSWORD=your_generated_password
MYSQL_DATABASE=youruser_kark_database

# Session secret
SESSION_SECRET=your-secret-key-here-change-in-production

# Server configuration
PORT=5000
NODE_ENV=production
```

## Step 4: Admin Login Credentials

After importing the database, you can log in with:

**Supermanager Account:**
- Username: `supermanager`
- Password: `admin123`

**Admin Account:**
- Username: `admin`
- Password: `Admin123!`

**Important:** Change these passwords immediately after first login!

## Step 5: Verify Database Connection

1. **Check your Node.js application logs**
2. **Test the admin login**
3. **Verify data is being stored in MySQL**

## Troubleshooting

### Common Issues:

1. **Connection refused:**
   - Check MYSQL_HOST (usually `localhost`)
   - Verify MYSQL_PORT (usually `3306`)

2. **Access denied:**
   - Double-check username and password
   - Ensure user has ALL PRIVILEGES on the database

3. **Database not found:**
   - Verify database name includes the cPanel prefix
   - Check if database was created successfully

4. **Table doesn't exist:**
   - Make sure you imported the SQL file
   - Check if table names have the correct prefix

### Switching Between JSON and MySQL:

To switch storage systems, change the `DB_TYPE` in your `.env` file:
- `DB_TYPE=json` - Use JSON file storage
- `DB_TYPE=mysql` - Use MySQL database

## Table Structure

The database includes these main tables:
- `kark_users` - User accounts and permissions
- `kark_events` - Events and activities
- `kark_media_items` - Media files and galleries
- `kark_settings` - Site configuration
- `kark_hero_sliders` - Homepage sliders
- `kark_activities` - Activity logs
- `kark_contact_messages` - Contact form submissions
- `kark_admin_logs` - Admin action logs

## Security Notes

1. **Change default passwords immediately**
2. **Use strong, unique passwords**
3. **Keep your .env file secure and never commit it to version control**
4. **Consider using SSL for database connections in production**
5. **Regularly backup your database**

## Support

If you encounter issues:
1. Check the application logs
2. Verify your cPanel MySQL setup
3. Test the database connection manually
4. Contact your hosting provider for cPanel-specific issues