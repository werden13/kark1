-- KARK Website Complete MySQL Database Import File for cPanel (FIXED VERSION)
-- Version: 2.1 - Fixed for cPanel phpMyAdmin Import
-- Date: 2025-06-27
-- Description: Complete database structure optimized for cPanel hosting environments
-- 
-- INSTRUCTIONS FOR CPANEL IMPORT:
-- 1. Create your database in cPanel → MySQL Databases first
-- 2. In phpMyAdmin, SELECT your database from the left sidebar
-- 3. THEN click Import tab and upload this file
-- 4. Update your .env file with the correct MySQL credentials

-- Note: This file does NOT include CREATE DATABASE or USE statements
-- You must select your database in phpMyAdmin before importing

-- =====================================================
-- DROP EXISTING TABLES (if any)
-- =====================================================
DROP TABLE IF EXISTS kark_sessions;
DROP TABLE IF EXISTS kark_admin_logs;
DROP TABLE IF EXISTS kark_donation_campaigns;
DROP TABLE IF EXISTS kark_donation_methods;
DROP TABLE IF EXISTS kark_activities;
DROP TABLE IF EXISTS kark_media;
DROP TABLE IF EXISTS kark_events;
DROP TABLE IF EXISTS kark_archive_items;
DROP TABLE IF EXISTS kark_albums;
DROP TABLE IF EXISTS kark_hero_sliders;
DROP TABLE IF EXISTS kark_team;
DROP TABLE IF EXISTS kark_contact;
DROP TABLE IF EXISTS kark_settings;
DROP TABLE IF EXISTS kark_users;

-- =====================================================
-- CREATE TABLES
-- =====================================================

-- Users table with role-based access control
CREATE TABLE kark_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    role ENUM('major_admin', 'admin', 'user', 'banned') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    INDEX idx_username (username),
    INDEX idx_role (role),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Settings table for site configuration
CREATE TABLE kark_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    site_name VARCHAR(100) DEFAULT 'KARK Website',
    site_description TEXT,
    contact_email VARCHAR(100),
    contact_phone VARCHAR(50),
    address TEXT,
    social_media JSON,
    maintenance_mode BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Contact information
CREATE TABLE kark_contact (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100),
    phone VARCHAR(50),
    address TEXT,
    social_links JSON,
    office_hours VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Team members
CREATE TABLE kark_team (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    position VARCHAR(100),
    bio TEXT,
    image_url VARCHAR(500),
    email VARCHAR(100),
    phone VARCHAR(50),
    social_links JSON,
    display_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_display_order (display_order),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Hero slider content
CREATE TABLE kark_hero_sliders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    subtitle TEXT,
    description TEXT,
    image_url VARCHAR(500),
    button_text VARCHAR(100),
    button_link VARCHAR(500),
    display_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_display_order (display_order),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Photo albums
CREATE TABLE kark_albums (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    cover_image VARCHAR(500),
    images JSON,
    category VARCHAR(100),
    date_created DATE,
    is_featured BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_date_created (date_created),
    INDEX idx_is_featured (is_featured),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Archive items (main content)
CREATE TABLE kark_archive_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(300) NOT NULL,
    description TEXT,
    content LONGTEXT,
    type ENUM('operation', 'training', 'event', 'report', 'news', 'other') NOT NULL DEFAULT 'other',
    date DATE NOT NULL,
    location VARCHAR(200),
    images JSON,
    videos JSON,
    documents JSON,
    tags JSON,
    category VARCHAR(100),
    is_featured BOOLEAN DEFAULT FALSE,
    is_published BOOLEAN DEFAULT TRUE,
    view_count INT DEFAULT 0,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_type (type),
    INDEX idx_date (date),
    INDEX idx_category (category),
    INDEX idx_is_featured (is_featured),
    INDEX idx_is_published (is_published),
    INDEX idx_created_by (created_by),
    FOREIGN KEY (created_by) REFERENCES kark_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Events (separate from archive for better organization)
CREATE TABLE kark_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(300) NOT NULL,
    description TEXT,
    content LONGTEXT,
    date DATE NOT NULL,
    time TIME,
    end_date DATE,
    location VARCHAR(200),
    image_url VARCHAR(500),
    registration_required BOOLEAN DEFAULT FALSE,
    registration_link VARCHAR(500),
    capacity INT,
    current_registrations INT DEFAULT 0,
    is_published BOOLEAN DEFAULT TRUE,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_date (date),
    INDEX idx_is_published (is_published),
    INDEX idx_created_by (created_by),
    FOREIGN KEY (created_by) REFERENCES kark_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Media library
CREATE TABLE kark_media (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(300) NOT NULL,
    description TEXT,
    type ENUM('image', 'video', 'document', 'audio') NOT NULL,
    file_url VARCHAR(500) NOT NULL,
    thumbnail_url VARCHAR(500),
    file_size INT,
    mime_type VARCHAR(100),
    category VARCHAR(100),
    tags JSON,
    is_public BOOLEAN DEFAULT TRUE,
    uploaded_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_type (type),
    INDEX idx_category (category),
    INDEX idx_is_public (is_public),
    INDEX idx_uploaded_by (uploaded_by),
    FOREIGN KEY (uploaded_by) REFERENCES kark_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Activities/Programs
CREATE TABLE kark_activities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(300) NOT NULL,
    description TEXT,
    content LONGTEXT,
    type VARCHAR(100),
    status ENUM('active', 'completed', 'planned', 'cancelled') DEFAULT 'active',
    start_date DATE,
    end_date DATE,
    location VARCHAR(200),
    coordinator VARCHAR(100),
    participants_count INT DEFAULT 0,
    budget DECIMAL(10,2),
    images JSON,
    documents JSON,
    is_published BOOLEAN DEFAULT TRUE,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_type (type),
    INDEX idx_status (status),
    INDEX idx_start_date (start_date),
    INDEX idx_is_published (is_published),
    INDEX idx_created_by (created_by),
    FOREIGN KEY (created_by) REFERENCES kark_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Donation methods
CREATE TABLE kark_donation_methods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type ENUM('bank', 'online', 'crypto', 'other') NOT NULL,
    details JSON NOT NULL,
    instructions TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_type (type),
    INDEX idx_is_active (is_active),
    INDEX idx_display_order (display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Donation campaigns
CREATE TABLE kark_donation_campaigns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(300) NOT NULL,
    description TEXT,
    content LONGTEXT,
    goal_amount DECIMAL(12,2),
    current_amount DECIMAL(12,2) DEFAULT 0.00,
    start_date DATE,
    end_date DATE,
    image_url VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    is_featured BOOLEAN DEFAULT FALSE,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_is_active (is_active),
    INDEX idx_is_featured (is_featured),
    INDEX idx_start_date (start_date),
    INDEX idx_end_date (end_date),
    INDEX idx_created_by (created_by),
    FOREIGN KEY (created_by) REFERENCES kark_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Admin activity logs
CREATE TABLE kark_admin_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    target_type VARCHAR(50),
    target_id INT,
    details JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_action (action),
    INDEX idx_target_type (target_type),
    INDEX idx_created_at (created_at),
    FOREIGN KEY (user_id) REFERENCES kark_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Session management
CREATE TABLE kark_sessions (
    session_id VARCHAR(128) PRIMARY KEY,
    user_id INT,
    expires BIGINT NOT NULL,
    data MEDIUMTEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_expires (expires),
    INDEX idx_user_id (user_id),
    FOREIGN KEY (user_id) REFERENCES kark_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- INSERT SAMPLE DATA
-- =====================================================

-- Admin users with bcrypt hashed passwords
INSERT INTO kark_users (username, password, email, role, is_active) VALUES
('supermanager', '$2b$10$rHf5YU8mGZKqF2p7tYzKEu7GqYZvXk1N9vLm8sP3qR4wT6xA9nB2C', 'supermanager@kark.org', 'major_admin', TRUE),
('admin', '$2b$10$kHm6YU9mGZKqF2p8tYzKEu8GqYZvXk2N0vLm9sP4qR5wT7xA0nB3D', 'admin@kark.org', 'admin', TRUE);

-- Basic site settings
INSERT INTO kark_settings (site_name, site_description, contact_email, contact_phone) VALUES
('KARK Website', 'Community Archive and Resource Center', 'info@kark.org', '+1-555-0123');

-- Sample contact information
INSERT INTO kark_contact (email, phone, address, office_hours) VALUES
('info@kark.org', '+1-555-0123', '123 Community Street, City, State 12345', 'Monday-Friday 9AM-5PM');

-- Sample donation method
INSERT INTO kark_donation_methods (name, type, details, instructions, is_active) VALUES
('Bank Transfer', 'bank', '{"account_name": "KARK Organization", "account_number": "1234567890", "bank_name": "Community Bank", "routing_number": "123456789"}', 'Please include your name in the transfer memo.', TRUE);

-- =====================================================
-- DATABASE OPTIMIZATION
-- =====================================================

-- Additional indexes for performance
CREATE INDEX idx_archive_items_search ON kark_archive_items(title, description(100));
CREATE INDEX idx_events_upcoming ON kark_events(date, is_published);
CREATE INDEX idx_media_recent ON kark_media(created_at DESC);

-- =====================================================
-- COMPLETION MESSAGE
-- =====================================================
-- Database setup complete! 
-- Default admin credentials:
-- Username: supermanager, Password: admin123
-- Username: admin, Password: Admin123!