import { db } from "./server/db";
import { users } from "./shared/schema";
import { eq } from "drizzle-orm";

async function fixAdminPermissions() {
  try {
    console.log("Checking admin permissions in the database...");
    
    // Get all admin users to check their permissions
    const adminUsers = await db.select().from(users).where(eq(users.isAdmin, true));
    
    console.log(`Found ${adminUsers.length} admin users in the database.`);
    
    // Log each admin's current permissions
    for (const admin of adminUsers) {
      console.log(`Admin: ${admin.username}, Role: ${admin.role}, Permissions: ${JSON.stringify(admin.permissions)}`);
    }
    
    // Make sure supermanager has all permissions
    const supermanager = adminUsers.find(user => user.username === "supermanager");
    
    if (supermanager) {
      console.log("Found supermanager account, ensuring it has full permissions...");
      
      const allPermissions = [
        "manage_users", 
        "manage_events", 
        "manage_media", 
        "manage_team", 
        "manage_donations", 
        "manage_settings", 
        "manage_sliders", 
        "manage_admins",
        "all"
      ];
      
      // Update supermanager to ensure it has all permissions
      await db.update(users)
        .set({
          role: "major_admin",
          permissions: allPermissions
        })
        .where(eq(users.username, "supermanager"));
      
      console.log("Supermanager permissions updated successfully!");
    } else {
      console.log("Supermanager account not found.");
    }
    
    // Check if our database permissions were saved correctly
    const updatedSupermanager = await db.query.users.findFirst({
      where: (users, { eq }) => eq(users.username, "supermanager")
    });
    
    console.log("Updated supermanager permissions:", JSON.stringify(updatedSupermanager?.permissions));
    
    console.log("Admin permissions check and fix completed!");
    
  } catch (error) {
    console.error("Error fixing admin permissions:", error);
  }
}

fixAdminPermissions();