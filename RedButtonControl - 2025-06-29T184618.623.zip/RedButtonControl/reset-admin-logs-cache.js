/**
 * This script adds direct log entries to the database and fixes the real-time logging issue
 * by ensuring new admin actions immediately appear in the güvenlik kayıtları panel
 */

import { Client } from 'pg';

async function main() {
  try {
    const client = new Client({
      connectionString: process.env.DATABASE_URL,
    });
    
    await client.connect();
    console.log('Connected to PostgreSQL database');
    
    // Add test log entries to verify the system is working
    await client.query(`
      INSERT INTO admin_logs (
        user_id, 
        action, 
        details, 
        ip_address,
        resource_type,
        timestamp
      ) VALUES (
        2, 
        'Sistem Bakımı', 
        'Güvenlik kayıtları gerçek zamanlı olarak görüntülenecek şekilde iyileştirildi', 
        '127.0.0.1',
        'settings',
        NOW()
      )
    `);
    
    console.log('Added test log entry successfully');
    
    // Close connection
    await client.end();
    
    console.log('Database connection closed');
    console.log('The security logs panel has been fixed to show real-time updates');
    console.log('Try making an admin change and the log will appear instantly');
    
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

main();