// Using the same algorithm as in server/auth.ts
import crypto from 'crypto';
import fs from 'fs/promises';
import path from 'path';

async function hashPassword(password) {
  return new Promise((resolve, reject) => {
    const salt = crypto.randomBytes(16).toString('hex');
    crypto.scrypt(password, salt, 64, (err, derivedKey) => {
      if (err) reject(err);
      resolve(`${derivedKey.toString('hex')}.${salt}`);
    });
  });
}

async function main() {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.join(process.cwd(), 'data');
    await fs.mkdir(dataDir, { recursive: true });
    
    // Hash the password using the exact same algorithm as auth.ts
    const hashedPassword = await hashPassword('Admin123!');
    console.log('Hashed password:', hashedPassword);
    
    // First check if users.json exists and read it
    const usersPath = path.join(dataDir, 'users.json');
    let users = [];
    
    try {
      const usersData = await fs.readFile(usersPath, 'utf8');
      users = JSON.parse(usersData);
      console.log(`Found ${users.length} existing users in users.json`);
    } catch (error) {
      console.log('No existing users.json file, will create new one');
    }
    
    // Find admin user or create one if it doesn't exist
    let adminUser = users.find(user => user.username === 'admin');
    
    if (adminUser) {
      // Update admin password
      console.log('Updating existing admin user with new password');
      adminUser.password = hashedPassword;
      adminUser.role = 'major_admin';
      adminUser.permissions = [
        "manage_users", 
        "manage_events", 
        "manage_media", 
        "manage_team", 
        "manage_donations", 
        "manage_settings", 
        "manage_sliders", 
        "manage_admins",
        "all"
      ];
      adminUser.isAdmin = true;
    } else {
      // Create new admin user
      console.log('Creating new admin user');
      adminUser = {
        id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1,
        username: 'admin',
        password: hashedPassword,
        firstName: 'Admin',
        lastName: 'User',
        email: 'admin@example.com',
        isAdmin: true,
        role: 'major_admin',
        permissions: [
          "manage_users", 
          "manage_events", 
          "manage_media", 
          "manage_team", 
          "manage_donations", 
          "manage_settings", 
          "manage_sliders", 
          "manage_admins",
          "all"
        ],
        createdAt: new Date()
      };
      users.push(adminUser);
    }
    
    // Also look for or create supermanager account
    let superManager = users.find(user => user.username === 'supermanager');
    
    if (superManager) {
      // Update supermanager password
      console.log('Updating existing supermanager user with new password');
      superManager.password = await hashPassword('Admin123!');
      superManager.role = 'major_admin';
      superManager.permissions = [
        "manage_users", 
        "manage_events", 
        "manage_media", 
        "manage_team", 
        "manage_donations", 
        "manage_settings", 
        "manage_sliders", 
        "manage_admins",
        "all"
      ];
      superManager.isAdmin = true;
    } else {
      // Create supermanager user
      console.log('Creating new supermanager user');
      superManager = {
        id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1,
        username: 'supermanager',
        password: await hashPassword('Admin123!'),
        firstName: 'Super',
        lastName: 'Manager',
        email: 'super@example.com',
        isAdmin: true,
        role: 'major_admin',
        permissions: [
          "manage_users", 
          "manage_events", 
          "manage_media", 
          "manage_team", 
          "manage_donations", 
          "manage_settings", 
          "manage_sliders", 
          "manage_admins",
          "all"
        ],
        createdAt: new Date()
      };
      users.push(superManager);
    }
    
    // Write updated users array to users.json
    await fs.writeFile(usersPath, JSON.stringify(users, null, 2));
    
    console.log('Admin and supermanager accounts created/updated successfully!');
    console.log('You can now log in with:');
    console.log('Username: admin or supermanager');
    console.log('Password: Admin123!');
  } catch (error) {
    console.error('Error:', error);
  }
}

main();