import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TeamMember } from "@shared/schema";

interface TeamCardProps {
  member: TeamMember;
  onContactClick: (member: TeamMember) => void;
}

export default function TeamCard({ member, onContactClick }: TeamCardProps) {
  return (
    <Card className="team-card group hover:-translate-y-1 transition-all duration-300">
      <div className="w-full h-64 overflow-hidden">
        <img 
          src={member.imagePath || `https://source.unsplash.com/random/600x800/?rescuer,firefighter`} 
          alt={`${member.firstName} ${member.lastName}`} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-70 transition-opacity duration-300"></div>
      </div>
      <CardContent className="p-6">
        <h3 className="text-xl font-semibold mb-1 group-hover:text-red-600 transition-colors">
          {member.firstName} {member.lastName}
        </h3>
        <p className="text-gray-600 font-medium mb-3">{member.position}</p>
        
        {member.skills && member.skills.length > 0 && (
          <ul className="mb-4 text-sm text-gray-600">
            {member.skills.map((skill, index) => (
              <li key={index} className="mb-1 flex items-center">
                <span className="h-1.5 w-1.5 rounded-full bg-red-600 mr-2"></span>
                {skill}
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
