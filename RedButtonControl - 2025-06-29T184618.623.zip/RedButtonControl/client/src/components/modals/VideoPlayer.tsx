import { useEffect } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getYouTubeEmbedUrl } from "@/lib/utils";

interface VideoPlayerProps {
  isOpen: boolean;
  videoId: string | null;
  onClose: () => void;
}

export default function VideoPlayer({ isOpen, videoId, onClose }: VideoPlayerProps) {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      
      // Add keyboard listener to close on escape key
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') onClose();
      };
      
      window.addEventListener('keydown', handleKeyDown);
      
      return () => {
        document.body.style.overflow = '';
        window.removeEventListener('keydown', handleKeyDown);
      };
    }
  }, [isOpen, onClose]);

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  if (!isOpen || !videoId) return null;

  const embedUrl = getYouTubeEmbedUrl(videoId);

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center"
      onClick={handleBackdropClick}
    >
      <Button 
        variant="ghost" 
        size="icon"
        className="absolute top-4 right-4 text-white hover:text-gray-300 focus:outline-none"
        onClick={onClose}
        aria-label="Close video player"
      >
        <X className="h-6 w-6" />
      </Button>
      
      <div className="w-full max-w-4xl aspect-video">
        <iframe 
          src={embedUrl} 
          frameBorder="0" 
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
          allowFullScreen
          className="w-full h-full"
          title="Youtube video player"
        ></iframe>
      </div>
    </div>
  );
}
