import { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion, useMotionValue, useTransform } from 'framer-motion';
import { Users, Eye } from 'lucide-react';

interface VisitorCounterProps {
  className?: string;
}

const VisitorCounter = ({ className = '' }: VisitorCounterProps) => {
  const [displayCount, setDisplayCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const counterRef = useRef<HTMLDivElement>(null);
  
  // 3D tilt effect için motion değerleri
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const z = useMotionValue(0);
  
  // Cursor pozisyonuna göre kart eğimi - ters çevrildi böylece cursor tarafı batar
  const rotateX = useTransform(y, [-1, 1], [15, -15]);
  const rotateY = useTransform(x, [-1, 1], [-15, 15]);
  
  // Perspektif derinliği için transform
  const transformPerspective = useTransform(
    [rotateX, rotateY, z],
    ([latestRotateX, latestRotateY, latestZ]) =>
      `perspective(1000px) rotateX(${latestRotateX}deg) rotateY(${latestRotateY}deg) translateZ(${latestZ}px)`
  );
  
  const handleMouseMove = (event: React.MouseEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = event.clientX - rect.left;
    const mouseY = event.clientY - rect.top;
    
    // -1 ile 1 arasında normalize et
    const xPct = (mouseX / width - 0.5) * 2;
    const yPct = (mouseY / height - 0.5) * 2;
    
    x.set(xPct);
    y.set(yPct);
    z.set(10); // Hover'da hafif öne çıkma efekti
  };
  
  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
    z.set(0);
  };

  // API'den ziyaretçi sayısını al
  const { data: visitorCount = 0 } = useQuery<number>({
    queryKey: ['/api/visitor-count'],
    queryFn: async () => {
      const response = await fetch('/api/visitor-count');
      if (!response.ok) {
        throw new Error('Ziyaretçi sayısı alınamadı');
      }
      const data = await response.json();
      return data.count || 0;
    },
    refetchInterval: 30000, // 30 saniyede bir güncelle
  });

  // Intersection Observer ile sayaç görünür olduğunda animasyonu başlat
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !isVisible) {
          setIsVisible(true);
        }
      },
      { threshold: 0.5 }
    );

    if (counterRef.current) {
      observer.observe(counterRef.current);
    }

    return () => {
      if (counterRef.current) {
        observer.unobserve(counterRef.current);
      }
    };
  }, [isVisible]);

  // Sayaç animasyonu
  useEffect(() => {
    if (!isVisible || !visitorCount) return;

    const duration = 2000; // 2 saniye
    const startTime = Date.now();
    const startValue = 0;
    const endValue = visitorCount;

    const updateCounter = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Easing function (ease-out)
      const easeOut = 1 - Math.pow(1 - progress, 3);
      
      const currentValue = Math.floor(startValue + (endValue - startValue) * easeOut);
      setDisplayCount(currentValue);

      if (progress < 1) {
        requestAnimationFrame(updateCounter);
      }
    };

    requestAnimationFrame(updateCounter);
  }, [isVisible, visitorCount]);

  // Sayıyı formatla (binler ayırıcısı ile)
  const formatNumber = (num: number) => {
    return num.toLocaleString('tr-TR');
  };

  return (
    <motion.div
      ref={counterRef}
      className={`relative ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 20 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      style={{ perspective: "1000px" }}
    >
      {/* Wrapper to prevent clipping */}
      <div className="relative p-4">
        {/* Ana içerik - Profesyonel ve modern kart */}
        <motion.div 
          className="relative bg-white dark:bg-gray-800 backdrop-blur-sm rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden"
          style={{
            transform: transformPerspective,
            transformStyle: "preserve-3d",
            transformOrigin: "center center",
          }}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
        >
          {/* Extended background to prevent empty areas when tilting */}
          <div className="absolute inset-[-50%] bg-white dark:bg-gray-800 z-[-1]" />
          
          {/* Gradient overlay background */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 via-transparent to-purple-50/50 dark:from-blue-900/20 dark:to-purple-900/20" />
          
          {/* Card content wrapper */}
          <div className="relative p-8">
        
        {/* Animated background pattern */}
        <div className="absolute inset-0 opacity-10">
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-64 h-64 border border-gray-300 dark:border-gray-600 rounded-full"
              style={{
                top: `${-20 + i * 30}%`,
                left: `${-10 + i * 40}%`,
              }}
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.1, 0.2, 0.1],
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                delay: i * 2,
                ease: "easeInOut"
              }}
            />
          ))}
        </div>

        {/* İkon */}
        <div className="relative flex items-center justify-center mb-6">
          <motion.div
            className="relative"
            whileHover={{ scale: 1.05 }}
            animate={{ 
              rotate: isVisible ? [0, 10, 0, -10, 0] : 0,
            }}
            transition={{ 
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Users className="w-10 h-10 text-white" />
            </div>
            {/* Subtle pulse effect */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl"
              animate={{
                scale: [1, 1.15, 1],
                opacity: [0.3, 0, 0.3],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeOut",
              }}
            />
          </motion.div>
        </div>

        {/* Başlık */}
        <motion.h3
          className="text-xl font-semibold text-gray-800 dark:text-gray-200 text-center mb-4"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : -10 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          Toplam Ziyaretçi
        </motion.h3>

        {/* Sayaç */}
        <motion.div
          className="text-center"
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ 
            scale: isVisible ? 1 : 0.9, 
            opacity: isVisible ? 1 : 0,
          }}
          transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
        >
          {/* Numbers with gradient */}
          <div className="relative">
            <motion.div 
              className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-3"
              animate={{
                scale: [1, 1.02, 1],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              {formatNumber(displayCount)}
            </motion.div>
            
            {/* Alt yazı */}
            <motion.div 
              className="flex items-center justify-center gap-2 text-sm text-gray-600 dark:text-gray-400"
              animate={{
                opacity: [0.7, 1, 0.7],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              <Eye className="w-4 h-4" />
              <span>Sayfa görüntülemesi</span>
            </motion.div>
          </div>
        </motion.div>

            {/* Subtle decorative elements */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-gradient-to-br from-blue-400/10 to-purple-400/10 rounded-full blur-3xl" />
            <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-gradient-to-br from-purple-400/10 to-pink-400/10 rounded-full blur-3xl" />
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default VisitorCounter;