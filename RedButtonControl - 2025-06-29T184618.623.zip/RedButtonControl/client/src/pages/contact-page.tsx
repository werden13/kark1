import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import ContactForm from "@/components/forms/ContactForm";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { Helmet } from "react-helmet";

export default function ContactPage() {
  return (
    <>
      <Helmet>
        <title>İletişim | Etkinlik Platformu</title>
        <meta name="description" content="Sorularınız ve işbirliği önerileriniz için bizimle iletişime geçin. Adres, telefon ve e-posta bilgilerimizi bulabilirsiniz." />
      </Helmet>
      
      <Navbar />
      
      <main className="content-container">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <div className="flex justify-center">
              <h1 className="section-title">İletişim</h1>
            </div>
            <p className="section-description">Sorularınız ve işbirliği önerileriniz için bizimle iletişime geçin</p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-md dark:shadow-blue-900/20">
              <h2 className="text-2xl font-semibold mb-6 dark:text-white">Bize Ulaşın</h2>
              <ContactForm />
            </div>
            
            {/* Map and Contact Info */}
            <div>
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md dark:shadow-blue-900/20 mb-8">
                <h2 className="text-xl font-semibold mb-4 dark:text-white">İletişim Bilgileri</h2>
                
                <div className="flex items-start mb-4">
                  <div className="text-secondary mr-4">
                    <MapPin className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-medium dark:text-gray-200">Adres</h3>
                    <p className="text-primary dark:text-gray-300">Atatürk Bulvarı No:123 Kat:5 Merkez/Ankara</p>
                  </div>
                </div>
                
                <div className="flex items-start mb-4">
                  <div className="text-secondary mr-4">
                    <Phone className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-medium dark:text-gray-200">Telefon</h3>
                    <p className="text-primary dark:text-gray-300">+90 312 123 45 67</p>
                  </div>
                </div>
                
                <div className="flex items-start mb-4">
                  <div className="text-secondary mr-4">
                    <Mail className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-medium dark:text-gray-200">E-posta</h3>
                    <p className="text-primary dark:text-gray-300">info@etkinlikplatformu.com</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="text-secondary mr-4">
                    <Clock className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-medium dark:text-gray-200">Çalışma Saatleri</h3>
                    <p className="text-primary dark:text-gray-300">Pazartesi - Cuma: 09:00 - 18:00</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white dark:bg-gray-800 p-2 rounded-lg shadow-md dark:shadow-blue-900/20 h-80">
                {/* Google Maps iframe */}
                <div className="h-full w-full rounded-md overflow-hidden">
                  <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d24380.54325244868!2d32.85258034921874!3d39.92299430000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14d34f190a9cea9f%3A0xd3862ea8248d08a0!2zQW5rYXJhLCBLxLF6xLFsYXksIEF0YXTDvHJrIEJ1bHZhcsSx!5e0!3m2!1str!2str!4v1681922983833!5m2!1str!2str" 
                    width="100%" 
                    height="100%" 
                    style={{ border: 0 }} 
                    allowFullScreen 
                    loading="lazy" 
                    referrerPolicy="no-referrer-when-downgrade"
                    title="Etkinlik Platformu Konumu"
                  ></iframe>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </>
  );
}
