import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { User } from "@shared/schema";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Helmet } from "react-helmet";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Separator } from "@/components/ui/separator";

// Admin permissions definitions
const permissionItems = [
  { id: "manage_users", label: "Kullanıcı Yönetimi" },
  { id: "manage_events", label: "Etkinlik Yönetimi" },
  { id: "manage_media", label: "Medya Yönetimi" },
  { id: "manage_team", label: "Ekip Yönetimi" },
  { id: "manage_donations", label: "Bağış Yönetimi" },
  { id: "manage_settings", label: "Ayarlar" },
  { id: "manage_sliders", label: "Slider Yönetimi" },
  { id: "manage_admins", label: "Admin Yönetimi" },
];

// Form schema for creating/updating admins
const adminFormSchema = z.object({
  username: z.string().min(3, "Kullanıcı adı en az 3 karakter olmalıdır"),
  firstName: z.string().min(2, "Ad en az 2 karakter olmalıdır"),
  lastName: z.string().min(2, "Soyad en az 2 karakter olmalıdır"),
  email: z.string().email("Geçerli bir e-posta adresi giriniz"),
  password: z.string().min(8, "Şifre en az 8 karakter olmalıdır").optional(),
  role: z.enum(["admin", "major_admin"]),
  permissions: z.array(z.string()),
});

type AdminFormValues = z.infer<typeof adminFormSchema>;

export default function ManageAdminsPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [openCreateDialog, setOpenCreateDialog] = useState(false);
  const [openEditDialog, setOpenEditDialog] = useState(false);
  const [selectedAdmin, setSelectedAdmin] = useState<User | null>(null);

  // Fetch admins
  const { data: admins, isLoading } = useQuery<User[]>({
    queryKey: ["/api/admins"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/admins");
      const data = await res.json();
      return data;
    },
  });

  // Create form
  const createForm = useForm<AdminFormValues>({
    resolver: zodResolver(adminFormSchema),
    defaultValues: {
      username: "",
      firstName: "",
      lastName: "",
      email: "",
      password: "",
      role: "admin",
      permissions: ["manage_events", "manage_media", "manage_team"],
    },
  });

  // Edit form
  const editForm = useForm<AdminFormValues>({
    resolver: zodResolver(adminFormSchema.omit({ password: true })),
    defaultValues: {
      username: "",
      firstName: "",
      lastName: "",
      email: "",
      role: "admin",
      permissions: [],
    },
  });

  // Create admin mutation
  const createAdminMutation = useMutation({
    mutationFn: async (values: AdminFormValues) => {
      // Make sure permissions is an array
      const updatedData = {
        ...values,
        permissions: Array.isArray(values.permissions) ? values.permissions : []
      };
      
      console.log("Creating admin with data:", JSON.stringify(updatedData));
      
      const res = await apiRequest("POST", "/api/admins", updatedData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admins"] });
      setOpenCreateDialog(false);
      createForm.reset();
      toast({
        title: "Başarılı!",
        description: "Admin kullanıcı başarıyla oluşturuldu.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata!",
        description: error.message || "Admin oluşturulurken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });

  // Update admin mutation
  const updateAdminMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: AdminFormValues }) => {
      // Make sure permissions is an array
      const updatedData = {
        ...data,
        permissions: Array.isArray(data.permissions) ? data.permissions : []
      };
      
      console.log("Updating admin with data:", JSON.stringify(updatedData));
      
      const res = await apiRequest("PUT", `/api/admins/${id}`, updatedData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admins"] });
      setOpenEditDialog(false);
      setSelectedAdmin(null);
      toast({
        title: "Başarılı!",
        description: "Admin kullanıcı başarıyla güncellendi.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata!",
        description: error.message || "Admin güncellenirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });

  // Delete admin mutation
  const deleteAdminMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admins/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admins"] });
      toast({
        title: "Başarılı!",
        description: "Admin kullanıcı başarıyla silindi.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata!",
        description: error.message || "Admin silinirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });

  // Handle opening edit dialog and setting form values
  const handleEditAdmin = (admin: User) => {
    setSelectedAdmin(admin);
    editForm.reset({
      username: admin.username,
      firstName: admin.firstName,
      lastName: admin.lastName,
      email: admin.email,
      role: admin.role,
      permissions: admin.permissions || [],
    });
    setOpenEditDialog(true);
  };

  // Create admin submit handler
  const onCreateSubmit = (values: AdminFormValues) => {
    createAdminMutation.mutate(values);
  };

  // Edit admin submit handler
  const onEditSubmit = (values: AdminFormValues) => {
    if (selectedAdmin) {
      updateAdminMutation.mutate({ id: selectedAdmin.id, data: values });
    }
  };

  // Convert role to Turkish
  const getRoleName = (role: string) => {
    switch (role) {
      case "major_admin":
        return "Tam Yetkili Admin";
      case "admin":
        return "Normal Admin";
      default:
        return role;
    }
  };

  return (
    <>
      <Helmet>
        <title>Admin Kullanıcı Yönetimi | Admin Panel</title>
      </Helmet>

      <AdminLayout title="Admin Kullanıcı Yönetimi">
        <div className="flex justify-between items-center mb-6">
          <p className="text-muted-foreground">
            Bu sayfada sistem yöneticilerini yönetebilirsiniz.
          </p>
          <Dialog open={openCreateDialog} onOpenChange={setOpenCreateDialog}>
            <DialogTrigger asChild>
              <Button>Yeni Admin Ekle</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[525px]">
              <DialogHeader>
                <DialogTitle>Yeni Admin Kullanıcı Oluştur</DialogTitle>
                <DialogDescription>
                  Yeni bir admin kullanıcı oluşturmak için bilgileri doldurun.
                </DialogDescription>
              </DialogHeader>
              <Form {...createForm}>
                <form
                  onSubmit={createForm.handleSubmit(onCreateSubmit)}
                  className="space-y-4"
                >
                  <FormField
                    control={createForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Kullanıcı Adı</FormLabel>
                        <FormControl>
                          <Input placeholder="kullaniciadi" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={createForm.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Ad</FormLabel>
                          <FormControl>
                            <Input placeholder="Ad" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createForm.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Soyad</FormLabel>
                          <FormControl>
                            <Input placeholder="Soyad" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={createForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>E-posta</FormLabel>
                        <FormControl>
                          <Input
                            type="email"
                            placeholder="ornek@mail.com"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={createForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Şifre</FormLabel>
                        <FormControl>
                          <Input
                            type="password"
                            placeholder="Şifre"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={createForm.control}
                    name="role"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Rol</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Bir rol seçin" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="admin">Normal Admin</SelectItem>
                            <SelectItem value="major_admin">
                              Tam Yetkili Admin
                            </SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div>
                    <FormLabel className="block mb-2">İzinler</FormLabel>
                    {permissionItems.map((item) => (
                      <FormField
                        key={item.id}
                        control={createForm.control}
                        name="permissions"
                        render={({ field }) => (
                          <FormItem
                            key={item.id}
                            className="flex flex-row items-start space-x-3 space-y-0 mt-2"
                          >
                            <FormControl>
                              <Checkbox
                                checked={field.value?.includes(item.id)}
                                onCheckedChange={(checked) => {
                                  const current = field.value || [];
                                  if (checked) {
                                    field.onChange([...current, item.id]);
                                  } else {
                                    field.onChange(
                                      current.filter((value) => value !== item.id)
                                    );
                                  }
                                }}
                              />
                            </FormControl>
                            <FormLabel className="font-normal cursor-pointer">
                              {item.label}
                            </FormLabel>
                          </FormItem>
                        )}
                      />
                    ))}
                  </div>
                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setOpenCreateDialog(false)}
                    >
                      İptal
                    </Button>
                    <Button
                      type="submit"
                      disabled={createAdminMutation.isPending}
                    >
                      {createAdminMutation.isPending
                        ? "Kaydediliyor..."
                        : "Kaydet"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Admin Kullanıcılar</CardTitle>
            <CardDescription>
              Sistemdeki tüm admin kullanıcıların listesi
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Kullanıcı Adı</TableHead>
                  <TableHead>Ad Soyad</TableHead>
                  <TableHead>E-posta</TableHead>
                  <TableHead>Rol</TableHead>
                  <TableHead>İşlemler</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-4">
                      Yükleniyor...
                    </TableCell>
                  </TableRow>
                ) : admins?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-4">
                      Henüz admin kullanıcı bulunmuyor.
                    </TableCell>
                  </TableRow>
                ) : (
                  admins?.map((admin) => (
                    <TableRow key={admin.id}>
                      <TableCell>{admin.username}</TableCell>
                      <TableCell>
                        {admin.firstName} {admin.lastName}
                      </TableCell>
                      <TableCell>{admin.email}</TableCell>
                      <TableCell>{getRoleName(admin.role)}</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEditAdmin(admin)}
                          >
                            Düzenle
                          </Button>
                          {user?.id !== admin.id && (
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => {
                                if (
                                  window.confirm(
                                    "Bu admin kullanıcıyı silmek istediğinize emin misiniz? Bu işlem geri alınamaz."
                                  )
                                ) {
                                  deleteAdminMutation.mutate(admin.id);
                                }
                              }}
                            >
                              Sil
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Edit Admin Dialog */}
        <Dialog open={openEditDialog} onOpenChange={setOpenEditDialog}>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>Admin Kullanıcıyı Düzenle</DialogTitle>
              <DialogDescription>
                Admin kullanıcının bilgilerini güncelleyebilirsiniz.
              </DialogDescription>
            </DialogHeader>
            <Form {...editForm}>
              <form
                onSubmit={editForm.handleSubmit(onEditSubmit)}
                className="space-y-4"
              >
                <FormField
                  control={editForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Kullanıcı Adı</FormLabel>
                      <FormControl>
                        <Input placeholder="kullaniciadi" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editForm.control}
                    name="firstName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Ad</FormLabel>
                        <FormControl>
                          <Input placeholder="Ad" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={editForm.control}
                    name="lastName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Soyad</FormLabel>
                        <FormControl>
                          <Input placeholder="Soyad" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={editForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>E-posta</FormLabel>
                      <FormControl>
                        <Input
                          type="email"
                          placeholder="ornek@mail.com"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="role"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Rol</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Bir rol seçin" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="admin">Normal Admin</SelectItem>
                          <SelectItem value="major_admin">
                            Tam Yetkili Admin
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div>
                  <FormLabel className="block mb-2">İzinler</FormLabel>
                  {permissionItems.map((item) => (
                    <FormField
                      key={item.id}
                      control={editForm.control}
                      name="permissions"
                      render={({ field }) => (
                        <FormItem
                          key={item.id}
                          className="flex flex-row items-start space-x-3 space-y-0 mt-2"
                        >
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes(item.id)}
                              onCheckedChange={(checked) => {
                                const current = field.value || [];
                                if (checked) {
                                  field.onChange([...current, item.id]);
                                } else {
                                  field.onChange(
                                    current.filter((value) => value !== item.id)
                                  );
                                }
                              }}
                            />
                          </FormControl>
                          <FormLabel className="font-normal cursor-pointer">
                            {item.label}
                          </FormLabel>
                        </FormItem>
                      )}
                    />
                  ))}
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setOpenEditDialog(false)}
                  >
                    İptal
                  </Button>
                  <Button
                    type="submit"
                    disabled={updateAdminMutation.isPending}
                  >
                    {updateAdminMutation.isPending
                      ? "Güncelleniyor..."
                      : "Güncelle"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </AdminLayout>
    </>
  );
}