import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { 
  Loader2, 
  PlusCircle, 
  Edit, 
  Trash2, 
  Search, 
  UserPlus, 
  Briefcase, 
  Mail, 
  List 
} from "lucide-react";
import { TeamMember, InsertTeamMember, insertTeamMemberSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Helmet } from "react-helmet";
import { Badge } from "@/components/ui/badge";

export default function AdminTeam() {
  const { toast } = useToast();
  
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [tempSkill, setTempSkill] = useState("");
  
  const { data: teamMembers, isLoading } = useQuery<TeamMember[]>({
    queryKey: ["/api/team"],
  });
  
  // Modified schema for form use with skills array
  const teamMemberSchema = insertTeamMemberSchema.extend({
    // Skills will be handled manually since we need to add/remove
    skills: z.array(z.string()).optional(),
  });
  
  type TeamMemberFormValues = z.infer<typeof teamMemberSchema>;
  
  // Create form
  const createForm = useForm<TeamMemberFormValues>({
    resolver: zodResolver(teamMemberSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      position: "",
      imagePath: "",
      email: "",
      skills: [],
    },
  });
  
  // Edit form
  const editForm = useForm<TeamMemberFormValues>({
    resolver: zodResolver(teamMemberSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      position: "",
      imagePath: "",
      email: "",
      skills: [],
    },
  });
  
  // Create team member mutation
  const createTeamMemberMutation = useMutation({
    mutationFn: async (member: InsertTeamMember) => {
      const res = await apiRequest("POST", "/api/team", member);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Ekip üyesi eklendi",
        description: "Ekip üyesi başarıyla eklendi.",
      });
      setIsCreateDialogOpen(false);
      createForm.reset({
        firstName: "",
        lastName: "",
        position: "",
        imagePath: "",
        email: "",
        skills: [],
      });
      queryClient.invalidateQueries({ queryKey: ["/api/team"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Ekip üyesi eklenirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  // Update team member mutation
  const updateTeamMemberMutation = useMutation({
    mutationFn: async ({ id, member }: { id: number; member: InsertTeamMember }) => {
      const res = await apiRequest("PUT", `/api/team/${id}`, member);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Ekip üyesi güncellendi",
        description: "Ekip üyesi bilgileri başarıyla güncellendi.",
      });
      setIsEditDialogOpen(false);
      setSelectedMember(null);
      queryClient.invalidateQueries({ queryKey: ["/api/team"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Ekip üyesi güncellenirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  // Delete team member mutation
  const deleteTeamMemberMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/team/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Ekip üyesi silindi",
        description: "Ekip üyesi başarıyla silindi.",
      });
      setIsDeleteDialogOpen(false);
      setSelectedMember(null);
      queryClient.invalidateQueries({ queryKey: ["/api/team"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Ekip üyesi silinirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  function handleCreateMember() {
    setIsCreateDialogOpen(true);
    createForm.reset({
      firstName: "",
      lastName: "",
      position: "",
      imagePath: "",
      email: "",
      skills: [],
    });
  }
  
  function handleEditMember(member: TeamMember) {
    setSelectedMember(member);
    
    editForm.reset({
      firstName: member.firstName,
      lastName: member.lastName,
      position: member.position,
      imagePath: member.imagePath || "",
      email: member.email || "",
      skills: member.skills || [],
    });
    
    setIsEditDialogOpen(true);
  }
  
  function handleDeleteMember(member: TeamMember) {
    setSelectedMember(member);
    setIsDeleteDialogOpen(true);
  }
  
  function onCreateSubmit(data: TeamMemberFormValues) {
    createTeamMemberMutation.mutate(data);
  }
  
  function onEditSubmit(data: TeamMemberFormValues) {
    if (selectedMember) {
      updateTeamMemberMutation.mutate({ id: selectedMember.id, member: data });
    }
  }
  
  function confirmDelete() {
    if (selectedMember) {
      deleteTeamMemberMutation.mutate(selectedMember.id);
    }
  }
  
  // Skills management for create form
  function addSkillToCreate() {
    if (tempSkill.trim()) {
      const currentSkills = createForm.getValues("skills") || [];
      createForm.setValue("skills", [...currentSkills, tempSkill.trim()]);
      setTempSkill("");
    }
  }
  
  function removeSkillFromCreate(index: number) {
    const currentSkills = createForm.getValues("skills") || [];
    createForm.setValue("skills", currentSkills.filter((_, i) => i !== index));
  }
  
  // Skills management for edit form
  function addSkillToEdit() {
    if (tempSkill.trim()) {
      const currentSkills = editForm.getValues("skills") || [];
      editForm.setValue("skills", [...currentSkills, tempSkill.trim()]);
      setTempSkill("");
    }
  }
  
  function removeSkillFromEdit(index: number) {
    const currentSkills = editForm.getValues("skills") || [];
    editForm.setValue("skills", currentSkills.filter((_, i) => i !== index));
  }
  
  // Filter team members
  const filteredMembers = teamMembers?.filter(member => {
    return searchQuery === "" || 
      `${member.firstName} ${member.lastName}`.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (member.email && member.email.toLowerCase().includes(searchQuery.toLowerCase()));
  });
  
  return (
    <>
      <Helmet>
        <title>Yönetim Kurulu | Admin</title>
      </Helmet>
      
      <AdminLayout title="Yönetim Kurulu">
        <div className="mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex w-full max-w-sm items-center space-x-2">
            <Input
              placeholder="Üye ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full"
              prefix={<Search className="h-4 w-4 text-gray-400" />}
            />
          </div>
          <Button onClick={handleCreateMember}>
            <UserPlus className="h-4 w-4 mr-2" />
            Ekip Üyesi Ekle
          </Button>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Yönetim Kurulu Üyeleri</CardTitle>
            <CardDescription>
              Yönetim kurulu üyelerini yönetin
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-secondary" />
              </div>
            ) : filteredMembers && filteredMembers.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredMembers.map((member) => (
                  <div key={member.id} className="bg-white rounded-lg overflow-hidden shadow-md">
                    <div className="relative w-full h-64">
                      <img 
                        src={member.imagePath || `https://source.unsplash.com/random/600x800/?portrait`} 
                        alt={`${member.firstName} ${member.lastName}`} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="p-5">
                      <h3 className="text-xl font-semibold">
                        {member.firstName} {member.lastName}
                      </h3>
                      <div className="flex items-center mt-1 mb-3 text-gray-600">
                        <Briefcase className="h-4 w-4 mr-1" />
                        <span>{member.position}</span>
                      </div>
                      
                      {member.email && (
                        <div className="flex items-center mt-1 mb-3 text-gray-600">
                          <Mail className="h-4 w-4 mr-1" />
                          <a href={`mailto:${member.email}`} className="text-blue-600 hover:underline">
                            {member.email}
                          </a>
                        </div>
                      )}
                      
                      {member.skills && member.skills.length > 0 && (
                        <div className="mt-3">
                          <div className="flex items-center mb-2 text-gray-600">
                            <List className="h-4 w-4 mr-1" />
                            <span>Uzmanlık Alanları</span>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {member.skills.map((skill, index) => (
                              <Badge key={index} variant="secondary">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <div className="flex justify-between mt-4 pt-4 border-t">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditMember(member)}
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Düzenle
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-red-500"
                          onClick={() => handleDeleteMember(member)}
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Sil
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500">Ekip üyesi bulunamadı</p>
                <Button 
                  variant="outline" 
                  className="mt-4" 
                  onClick={handleCreateMember}
                >
                  <UserPlus className="h-4 w-4 mr-2" />
                  Ekip Üyesi Ekle
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Create Team Member Dialog */}
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Yeni Ekip Üyesi Ekle</DialogTitle>
              <DialogDescription>
                Yeni bir yönetim kurulu üyesi eklemek için aşağıdaki formu doldurun.
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={createForm.handleSubmit(onCreateSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="firstName" className="text-sm font-medium">Ad</label>
                  <Input
                    id="firstName"
                    placeholder="Adı"
                    {...createForm.register("firstName")}
                  />
                  {createForm.formState.errors.firstName && (
                    <p className="text-sm text-red-500">{createForm.formState.errors.firstName.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="lastName" className="text-sm font-medium">Soyad</label>
                  <Input
                    id="lastName"
                    placeholder="Soyadı"
                    {...createForm.register("lastName")}
                  />
                  {createForm.formState.errors.lastName && (
                    <p className="text-sm text-red-500">{createForm.formState.errors.lastName.message}</p>
                  )}
                </div>
              </div>
              
              <div className="space-y-2">
                <label htmlFor="position" className="text-sm font-medium">Pozisyon</label>
                <Input
                  id="position"
                  placeholder="Görev / Pozisyon"
                  {...createForm.register("position")}
                />
                {createForm.formState.errors.position && (
                  <p className="text-sm text-red-500">{createForm.formState.errors.position.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium">E-posta (opsiyonel)</label>
                <Input
                  id="email"
                  type="email"
                  placeholder="ornek@mail.com"
                  {...createForm.register("email")}
                />
                {createForm.formState.errors.email && (
                  <p className="text-sm text-red-500">{createForm.formState.errors.email.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <label htmlFor="imagePath" className="text-sm font-medium">Fotoğraf URL (opsiyonel)</label>
                <Input
                  id="imagePath"
                  placeholder="https://example.com/photo.jpg"
                  {...createForm.register("imagePath")}
                />
                {createForm.formState.errors.imagePath && (
                  <p className="text-sm text-red-500">{createForm.formState.errors.imagePath.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Uzmanlık Alanları</label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Uzmanlık alanı ekle"
                    value={tempSkill}
                    onChange={(e) => setTempSkill(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        addSkillToCreate();
                      }
                    }}
                  />
                  <Button type="button" onClick={addSkillToCreate}>Ekle</Button>
                </div>
                
                <div className="flex flex-wrap gap-2 mt-2">
                  {createForm.watch("skills")?.map((skill, index) => (
                    <Badge key={index} variant="secondary" className="gap-1 px-3 py-1">
                      {skill}
                      <button 
                        type="button"
                        className="ml-1 text-gray-500 hover:text-gray-700"
                        onClick={() => removeSkillFromCreate(index)}
                      >
                        &times;
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsCreateDialogOpen(false)}
                >
                  İptal
                </Button>
                <Button 
                  type="submit" 
                  disabled={createTeamMemberMutation.isPending}
                >
                  {createTeamMemberMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Ekleniyor...
                    </>
                  ) : (
                    "Ekip Üyesi Ekle"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        
        {/* Edit Team Member Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Ekip Üyesi Düzenle</DialogTitle>
              <DialogDescription>
                Ekip üyesi bilgilerini güncelleyin.
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="edit-firstName" className="text-sm font-medium">Ad</label>
                  <Input
                    id="edit-firstName"
                    placeholder="Adı"
                    {...editForm.register("firstName")}
                  />
                  {editForm.formState.errors.firstName && (
                    <p className="text-sm text-red-500">{editForm.formState.errors.firstName.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="edit-lastName" className="text-sm font-medium">Soyad</label>
                  <Input
                    id="edit-lastName"
                    placeholder="Soyadı"
                    {...editForm.register("lastName")}
                  />
                  {editForm.formState.errors.lastName && (
                    <p className="text-sm text-red-500">{editForm.formState.errors.lastName.message}</p>
                  )}
                </div>
              </div>
              
              <div className="space-y-2">
                <label htmlFor="edit-position" className="text-sm font-medium">Pozisyon</label>
                <Input
                  id="edit-position"
                  placeholder="Görev / Pozisyon"
                  {...editForm.register("position")}
                />
                {editForm.formState.errors.position && (
                  <p className="text-sm text-red-500">{editForm.formState.errors.position.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <label htmlFor="edit-email" className="text-sm font-medium">E-posta (opsiyonel)</label>
                <Input
                  id="edit-email"
                  type="email"
                  placeholder="ornek@mail.com"
                  {...editForm.register("email")}
                />
                {editForm.formState.errors.email && (
                  <p className="text-sm text-red-500">{editForm.formState.errors.email.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <label htmlFor="edit-imagePath" className="text-sm font-medium">Fotoğraf URL (opsiyonel)</label>
                <Input
                  id="edit-imagePath"
                  placeholder="https://example.com/photo.jpg"
                  {...editForm.register("imagePath")}
                />
                {editForm.formState.errors.imagePath && (
                  <p className="text-sm text-red-500">{editForm.formState.errors.imagePath.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Uzmanlık Alanları</label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Uzmanlık alanı ekle"
                    value={tempSkill}
                    onChange={(e) => setTempSkill(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        addSkillToEdit();
                      }
                    }}
                  />
                  <Button type="button" onClick={addSkillToEdit}>Ekle</Button>
                </div>
                
                <div className="flex flex-wrap gap-2 mt-2">
                  {editForm.watch("skills")?.map((skill, index) => (
                    <Badge key={index} variant="secondary" className="gap-1 px-3 py-1">
                      {skill}
                      <button 
                        type="button"
                        className="ml-1 text-gray-500 hover:text-gray-700"
                        onClick={() => removeSkillFromEdit(index)}
                      >
                        &times;
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  İptal
                </Button>
                <Button 
                  type="submit" 
                  disabled={updateTeamMemberMutation.isPending}
                >
                  {updateTeamMemberMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Güncelleniyor...
                    </>
                  ) : (
                    "Güncelle"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        
        {/* Delete Confirmation Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Ekip Üyesi Sil</DialogTitle>
              <DialogDescription>
                Bu ekip üyesini silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.
              </DialogDescription>
            </DialogHeader>
            
            {selectedMember && (
              <div className="py-4 flex items-center gap-4">
                <div className="w-16 h-16 rounded-full overflow-hidden">
                  <img 
                    src={selectedMember.imagePath || `https://source.unsplash.com/random/200x200/?portrait`} 
                    alt={`${selectedMember.firstName} ${selectedMember.lastName}`} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <p className="font-medium">{selectedMember.firstName} {selectedMember.lastName}</p>
                  <p className="text-sm text-gray-500">{selectedMember.position}</p>
                </div>
              </div>
            )}
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsDeleteDialogOpen(false)}
              >
                İptal
              </Button>
              <Button 
                type="button" 
                variant="destructive" 
                onClick={confirmDelete}
                disabled={deleteTeamMemberMutation.isPending}
              >
                {deleteTeamMemberMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Siliniyor...
                  </>
                ) : (
                  "Evet, Sil"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </AdminLayout>
    </>
  );
}
