import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Save, Pencil } from "lucide-react";
import { Setting } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { closeAllDialogs } from "@/lib/dialog-utils";
import { Helmet } from "react-helmet";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

export default function AdminSettings() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("general");
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentEditKey, setCurrentEditKey] = useState<string | null>(null);
  
  const { data: settings, isLoading } = useQuery<Setting[]>({
    queryKey: ["/api/settings"],
  });
  
  // Group settings by category
  const settingsByCategory = {
    general: settings?.filter(s => s.key.startsWith("general.")) || [],
    contact: settings?.filter(s => s.key.startsWith("contact.")) || [],
    social: settings?.filter(s => s.key.startsWith("social.")) || [],
    home: settings?.filter(s => s.key.startsWith("home.")) || [],
  };
  
  // Initialize form data from settings
  useEffect(() => {
    const initialData: Record<string, string> = {};
    
    // İlk olarak varsayılan ayarları tanımla
    Object.keys(settingPlaceholders).forEach(key => {
      initialData[key] = settingPlaceholders[key];
    });
    
    // Varsa mevcut ayarları ekle (veritabanından gelen)
    if (settings) {
      settings.forEach(setting => {
        initialData[setting.key] = setting.value;
      });
    }
    
    setFormData(initialData);
  }, [settings]);
  
  // Update settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async (data: Record<string, string>) => {
      const res = await apiRequest("PUT", "/api/settings", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Ayarlar güncellendi",
        description: "Site ayarları başarıyla güncellendi.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      setIsSubmitting(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Ayarlar güncellenirken bir hata oluştu.",
        variant: "destructive",
      });
      setIsSubmitting(false);
    },
  });
  
  const handleInputChange = (key: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [key]: value
    }));
  };
  
  // Tekli ayar düzenleme işlemleri
  const handleEditStart = (key: string) => {
    setCurrentEditKey(key);
    setIsEditing(true);
  };
  
  const handleEditCancel = () => {
    setCurrentEditKey(null);
    setIsEditing(false);
    // Close all open dialogs
    closeAllDialogs();
  };
  
  const handleEditSave = async (key: string) => {
    // Mevcut ayarın güncellenmiş değerini al
    const newValue = formData[key];
    
    try {
      // Close the dialog first
      handleEditCancel();
      
      // Sadece bir ayarı güncelle
      const data = { [key]: newValue };
      await apiRequest("PUT", "/api/settings", data);
      
      toast({
        title: "Ayar güncellendi",
        description: `"${settingLabels[key] || key}" ayarı başarıyla güncellendi.`,
      });
      
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      setIsEditing(false);
      setCurrentEditKey(null);
    } catch (error: any) {
      toast({
        title: "Hata",
        description: error.message || "Ayar güncellenirken bir hata oluştu.",
        variant: "destructive",
      });
    }
  };
  
  const handleSubmit = (category: string) => {
    // Filter settings by the selected category
    const categoryKeys = Object.keys(formData).filter(key => key.startsWith(`${category}.`));
    
    // Create subset of data for the selected category
    const categoryData: Record<string, string> = {};
    categoryKeys.forEach(key => {
      categoryData[key] = formData[key];
    });
    
    setIsSubmitting(true);
    updateSettingsMutation.mutate(categoryData);
  };
  
  // Setting translation helpers
  const settingLabels: Record<string, string> = {
    // General
    "general.site_title": "Site Başlığı",
    "general.site_description": "Site Açıklaması",
    "general.logo_url": "Logo URL",
    "general.favicon_url": "Favicon URL",
    "general.footer_text": "Alt Bilgi Metni",
    
    // Contact
    "contact.address": "Adres",
    "contact.phone": "Telefon",
    "contact.email": "E-posta",
    "contact.working_hours": "Çalışma Saatleri",
    "contact.map_embed_url": "Google Maps Embed URL",
    
    // Social Media
    "social.facebook": "Facebook URL",
    "social.twitter": "Twitter URL",
    "social.instagram": "Instagram URL",
    "social.youtube": "YouTube URL",
    "social.linkedin": "LinkedIn URL",
    
    // Home Page
    "home.hero_title": "Ana Sayfa Başlık",
    "home.hero_subtitle": "Ana Sayfa Alt Başlık",
    "home.hero_button_text": "Ana Sayfa Butonu",
    "home.hero_button_link": "Ana Sayfa Buton Linki",
    "home.hero_image_url": "Ana Sayfa Resim URL",
    
    // Slider 2
    "home.hero_slide2_enabled": "Slider 2 Aktif",
    "home.hero_slide2_title": "Slider 2 Başlık",
    "home.hero_slide2_subtitle": "Slider 2 Alt Başlık",
    "home.hero_slide2_button_text": "Slider 2 Butonu",
    "home.hero_slide2_button_link": "Slider 2 Buton Linki",
    "home.hero_slide2_image_url": "Slider 2 Resim URL",
    
    // Slider 3
    "home.hero_slide3_enabled": "Slider 3 Aktif",
    "home.hero_slide3_title": "Slider 3 Başlık",
    "home.hero_slide3_subtitle": "Slider 3 Alt Başlık",
    "home.hero_slide3_button_text": "Slider 3 Butonu",
    "home.hero_slide3_button_link": "Slider 3 Buton Linki",
    "home.hero_slide3_image_url": "Slider 3 Resim URL",
    
    // Slider 4 (İsteğe bağlı)
    "home.hero_slide4_enabled": "Slider 4 Aktif",
    "home.hero_slide4_title": "Slider 4 Başlık",
    "home.hero_slide4_subtitle": "Slider 4 Alt Başlık",
    "home.hero_slide4_button_text": "Slider 4 Butonu",
    "home.hero_slide4_button_link": "Slider 4 Buton Linki",
    "home.hero_slide4_image_url": "Slider 4 Resim URL",
    
    // Diğer Ayarlar
    "home.about_text": "Hakkımızda Metni",
    "home.featured_event_id": "Öne Çıkan Etkinlik ID",
    "home.promo_video_url": "Tanıtım Video URL",
    

  };
  
  const settingDescriptions: Record<string, string> = {
    // General
    "general.site_title": "Tarayıcı sekmesinde ve SEO meta etiketlerinde görünecek site başlığı",
    "general.site_description": "Arama motorlarında ve sosyal medya paylaşımlarında görünecek site açıklaması",
    "general.logo_url": "Site logosunun tam URL'si",
    "general.favicon_url": "Tarayıcı sekmesinde görünecek favicon görselinin URL'si",
    "general.footer_text": "Sayfanın alt kısmında gösterilecek telif hakkı veya bilgi metni",
    
    // Contact
    "contact.address": "İletişim sayfasında gösterilecek fiziksel adres",
    "contact.phone": "İletişim için telefon numarası",
    "contact.email": "İletişim için e-posta adresi",
    "contact.working_hours": "Çalışma saatleri (örn: Pazartesi - Cuma: 09:00 - 18:00)",
    "contact.map_embed_url": "Google Maps iframe URL'si",
    
    // Social Media
    "social.facebook": "Facebook sayfanızın tam URL'si",
    "social.twitter": "Twitter/X hesabınızın tam URL'si",
    "social.instagram": "Instagram hesabınızın tam URL'si",
    "social.youtube": "YouTube kanalınızın tam URL'si",
    "social.linkedin": "LinkedIn sayfanızın tam URL'si",
    
    // Home Page - Ana Slider
    "home.hero_title": "Ana sayfa slider başlığı",
    "home.hero_subtitle": "Ana sayfa slider alt başlığı",
    "home.hero_button_text": "Ana sayfa slider buton metni",
    "home.hero_button_link": "Ana sayfa slider buton linki (/donations gibi)",
    "home.hero_image_url": "Ana sayfa slider görsel URL'si",
    
    // Slider 2
    "home.hero_slide2_enabled": "İkinci sliderin aktif olup olmadığı (true veya false)",
    "home.hero_slide2_title": "İkinci slider başlığı",
    "home.hero_slide2_subtitle": "İkinci slider alt başlığı",
    "home.hero_slide2_button_text": "İkinci slider buton metni",
    "home.hero_slide2_button_link": "İkinci slider buton linki (/events?category=training gibi)",
    "home.hero_slide2_image_url": "İkinci slider görsel URL'si",
    
    // Slider 3
    "home.hero_slide3_enabled": "Üçüncü sliderin aktif olup olmadığı (true veya false)",
    "home.hero_slide3_title": "Üçüncü slider başlığı",
    "home.hero_slide3_subtitle": "Üçüncü slider alt başlığı",
    "home.hero_slide3_button_text": "Üçüncü slider buton metni",
    "home.hero_slide3_button_link": "Üçüncü slider buton linki (/events?category=awareness gibi)",
    "home.hero_slide3_image_url": "Üçüncü slider görsel URL'si",
    
    // Slider 4
    "home.hero_slide4_enabled": "Dördüncü sliderin aktif olup olmadığı (true veya false)",
    "home.hero_slide4_title": "Dördüncü slider başlığı",
    "home.hero_slide4_subtitle": "Dördüncü slider alt başlığı",
    "home.hero_slide4_button_text": "Dördüncü slider buton metni",
    "home.hero_slide4_button_link": "Dördüncü slider buton linki",
    "home.hero_slide4_image_url": "Dördüncü slider görsel URL'si",
    
    // Diğer Ana Sayfa Ayarları
    "home.about_text": "Ana sayfada gösterilecek kısa tanıtım metni",
    "home.featured_event_id": "Ana sayfada öne çıkarılacak etkinliğin ID'si",
    "home.promo_video_url": "Ana sayfada gösterilecek tanıtım videosunun YouTube URL'si",
    

  };
  
  const settingPlaceholders: Record<string, string> = {
    // General
    "general.site_title": "Etkinlik Platformu",
    "general.site_description": "Sanat, kültür ve eğitim alanında düzenlenen çeşitli etkinliklerle toplumsal gelişime katkı sağlıyoruz.",
    "general.logo_url": "https://example.com/logo.png",
    "general.favicon_url": "https://example.com/favicon.ico",
    "general.footer_text": "© 2023 Etkinlik Platformu. Tüm hakları saklıdır.",
    
    // Contact
    "contact.address": "Atatürk Bulvarı No:123 Kat:5 Merkez/Ankara",
    "contact.phone": "+90 312 123 45 67",
    "contact.email": "info@etkinlikplatformu.com",
    "contact.working_hours": "Pazartesi - Cuma: 09:00 - 18:00",
    "contact.map_embed_url": "https://www.google.com/maps/embed?pb=...",
    
    // Social Media
    "social.facebook": "https://facebook.com/etkinlikplatformu",
    "social.twitter": "https://twitter.com/etkinlikplatformu",
    "social.instagram": "https://instagram.com/etkinlikplatformu",
    "social.youtube": "https://youtube.com/etkinlikplatformu",
    "social.linkedin": "https://linkedin.com/company/etkinlikplatformu",
    
    // Home Page - Ana Slider
    "home.hero_title": "KARK Arama Kurtarma Derneği",
    "home.hero_subtitle": "Doğal afetlerde ve acil durumlarda yanınızdayız",
    "home.hero_button_text": "Destek Ol",
    "home.hero_button_link": "/donations",
    "home.hero_image_url": "https://images.unsplash.com/photo-1584744982271-69ccbec775aa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
    
    // Slider 2
    "home.hero_slide2_enabled": "true",
    "home.hero_slide2_title": "Arama Kurtarma Eğitimleri",
    "home.hero_slide2_subtitle": "Profesyonel ekibimiz tarafından verilen eğitimlerle afetlere hazırlıklı olun.",
    "home.hero_slide2_button_text": "Eğitimleri İncele",
    "home.hero_slide2_button_link": "/events?category=training",
    "home.hero_slide2_image_url": "https://images.unsplash.com/photo-1558403194-611308249627?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
    
    // Slider 3
    "home.hero_slide3_enabled": "true",
    "home.hero_slide3_title": "Afet Bilinci Seminerleri",
    "home.hero_slide3_subtitle": "Afet öncesi, sırası ve sonrasında yapılması gerekenler hakkında toplumu bilinçlendiriyoruz.",
    "home.hero_slide3_button_text": "Seminerleri Gör",
    "home.hero_slide3_button_link": "/events?category=awareness",
    "home.hero_slide3_image_url": "https://images.unsplash.com/photo-1542652184-04d26a7598de?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
    
    // Slider 4
    "home.hero_slide4_enabled": "false",
    "home.hero_slide4_title": "Ek Slider Başlığı",
    "home.hero_slide4_subtitle": "Buraya ek slider açıklaması eklenebilir.",
    "home.hero_slide4_button_text": "Detaylar",
    "home.hero_slide4_button_link": "/",
    "home.hero_slide4_image_url": "https://images.unsplash.com/photo-1587502536576-1293019e0f92?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
    
    // Diğer Ana Sayfa Ayarları
    "home.about_text": "KARK Arama Kurtarma Derneği, doğal afetlerde ve acil durumlarda profesyonel ekibi ile arama kurtarma çalışmaları yapmak ve toplumu bilinçlendirmek amacıyla kurulmuştur.",
    "home.featured_event_id": "3",
    "home.promo_video_url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    

  };
  
  // Helper to determine if setting should use textarea (for longer content)
  const useTextarea = (key: string): boolean => {
    return [
      "general.site_description",
      "general.footer_text",
      "contact.address",
      "contact.working_hours",
      "home.about_text",
    ].includes(key);
  };
  
  const renderSettingField = (setting: Setting | {key: string, value: string}) => {
    const key = setting.key;
    const value = formData[key] || setting.value || "";
    const label = settingLabels[key] || key;
    const description = settingDescriptions[key] || "";
    const placeholder = settingPlaceholders[key] || "";
    
    return (
      <div key={key} className="space-y-2 mb-6">
        <div className="flex justify-between items-center mb-1">
          <label htmlFor={key} className="font-medium">{label}</label>
          <Dialog>
            <DialogTrigger asChild>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => handleEditStart(key)}
                className="h-8 px-2"
              >
                <Pencil className="h-4 w-4 mr-1" />
                Düzenle
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>{label}</DialogTitle>
                <DialogDescription>
                  {description}
                </DialogDescription>
              </DialogHeader>
              <div className="py-4">
                {useTextarea(key) ? (
                  <Textarea
                    id={`edit-${key}`}
                    value={value}
                    onChange={(e) => handleInputChange(key, e.target.value)}
                    placeholder={placeholder}
                    rows={5}
                    className="w-full"
                  />
                ) : (
                  <Input
                    id={`edit-${key}`}
                    value={value}
                    onChange={(e) => handleInputChange(key, e.target.value)}
                    placeholder={placeholder}
                    className="w-full"
                  />
                )}
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={handleEditCancel}>
                  İptal
                </Button>
                <Button onClick={() => handleEditSave(key)}>
                  Kaydet
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        
        {useTextarea(key) ? (
          <div className="relative">
            <Textarea
              id={key}
              value={value}
              onChange={(e) => handleInputChange(key, e.target.value)}
              placeholder={placeholder}
              rows={3}
              readOnly
              className="bg-gray-50"
            />
            <div className="absolute inset-0 bg-gray-100 bg-opacity-50 flex items-center justify-center opacity-0 hover:opacity-0 cursor-default"></div>
          </div>
        ) : (
          <div className="relative">
            <Input
              id={key}
              value={value}
              onChange={(e) => handleInputChange(key, e.target.value)}
              placeholder={placeholder}
              readOnly
              className="bg-gray-50"
            />
            <div className="absolute inset-0 bg-gray-100 bg-opacity-50 flex items-center justify-center opacity-0 hover:opacity-0 cursor-default"></div>
          </div>
        )}
        
        {description && (
          <p className="text-xs text-gray-500">{description}</p>
        )}
      </div>
    );
  };
  
  // Function to create default settings if they don't exist
  const createDefaultSettings = () => {
    const defaultSettings: Record<string, string[]> = {
      general: [
        "general.site_title",
        "general.site_description",
        "general.logo_url",
        "general.favicon_url",
        "general.footer_text",
      ],
      contact: [
        "contact.address",
        "contact.phone",
        "contact.email",
        "contact.working_hours",
        "contact.map_embed_url",
      ],
      social: [
        "social.facebook",
        "social.twitter",
        "social.instagram",
        "social.youtube",
        "social.linkedin",
      ],
      home: [
        // Ana Slider
        "home.hero_title",
        "home.hero_subtitle",
        "home.hero_button_text",
        "home.hero_button_link",
        "home.hero_image_url",
        
        // Slider 2
        "home.hero_slide2_enabled",
        "home.hero_slide2_title",
        "home.hero_slide2_subtitle",
        "home.hero_slide2_button_text",
        "home.hero_slide2_button_link",
        "home.hero_slide2_image_url",
        
        // Slider 3
        "home.hero_slide3_enabled",
        "home.hero_slide3_title",
        "home.hero_slide3_subtitle",
        "home.hero_slide3_button_text",
        "home.hero_slide3_button_link",
        "home.hero_slide3_image_url",
        
        // Slider 4
        "home.hero_slide4_enabled",
        "home.hero_slide4_title",
        "home.hero_slide4_subtitle",
        "home.hero_slide4_button_text",
        "home.hero_slide4_button_link",
        "home.hero_slide4_image_url",
        
        // Diğer Ayarlar
        "home.about_text",
        "home.featured_event_id",
        "home.promo_video_url",
        

      ],
    };
    
    // Generate placeholders for missing settings
    return Object.entries(defaultSettings).map(([category, keys]) => {
      return keys.map(key => {
        // Check if setting already exists
        const existingSetting = settings?.find(s => s.key === key);
        if (existingSetting) return existingSetting;
        
        // Create placeholder setting
        return {
          key,
          value: "",
        };
      });
    }).flat();
  };
  
  // Generate all settings including defaults
  const allSettings = createDefaultSettings();
  
  // Eğer veritabanından gelen ayarlar varsa, bunları ekle
  if (settings?.length) {
    settings.forEach(setting => {
      const existingIndex = allSettings.findIndex(s => s.key === setting.key);
      if (existingIndex !== -1) {
        allSettings[existingIndex] = setting;
      } else {
        allSettings.push(setting);
      }
    });
  }
  
  return (
    <>
      <Helmet>
        <title>Site Ayarları | Admin</title>
      </Helmet>
      
      <AdminLayout title="Site Ayarları">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-8">
            <TabsTrigger value="general">Genel</TabsTrigger>
            <TabsTrigger value="contact">İletişim</TabsTrigger>
            <TabsTrigger value="social">Sosyal Medya</TabsTrigger>
            <TabsTrigger value="home">Ana Sayfa</TabsTrigger>
          </TabsList>
          
          <TabsContent value="general">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div>
                  <CardTitle>Genel Ayarlar</CardTitle>
                  <CardDescription>
                    Sitenin genel ayarlarını yönetin
                  </CardDescription>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Pencil className="h-4 w-4 mr-2" /> Tümünü Düzenle
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Genel Ayarları Düzenle</DialogTitle>
                      <DialogDescription>
                        Tüm genel ayarları tek bir formda düzenleyin
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      {allSettings.filter(s => s.key.startsWith("general.")).map(setting => {
                        const key = setting.key;
                        const value = formData[key] || setting.value || "";
                        const label = settingLabels[key] || key;
                        const description = settingDescriptions[key] || "";
                        const placeholder = settingPlaceholders[key] || "";
                        
                        return (
                          <div key={key} className="space-y-2">
                            <label htmlFor={`dialog-${key}`} className="font-medium">{label}</label>
                            {useTextarea(key) ? (
                              <Textarea
                                id={`dialog-${key}`}
                                value={value}
                                onChange={(e) => handleInputChange(key, e.target.value)}
                                placeholder={placeholder}
                                rows={4}
                              />
                            ) : (
                              <Input
                                id={`dialog-${key}`}
                                value={value}
                                onChange={(e) => handleInputChange(key, e.target.value)}
                                placeholder={placeholder}
                              />
                            )}
                            {description && (
                              <p className="text-xs text-gray-500">{description}</p>
                            )}
                          </div>
                        );
                      })}
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => closeAllDialogs()}>
                        İptal
                      </Button>
                      <Button onClick={() => {
                        handleSubmit("general");
                        closeAllDialogs();
                      }}>
                        Değişiklikleri Kaydet
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-secondary" />
                  </div>
                ) : (
                  allSettings.filter(s => s.key.startsWith("general.")).map(renderSettingField)
                )}
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button 
                  onClick={() => handleSubmit("general")}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Kaydediliyor...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Kaydet
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="contact">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div>
                  <CardTitle>İletişim Ayarları</CardTitle>
                  <CardDescription>
                    İletişim bilgilerini ve harita ayarlarını yönetin
                  </CardDescription>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Pencil className="h-4 w-4 mr-2" /> Tümünü Düzenle
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>İletişim Ayarlarını Düzenle</DialogTitle>
                      <DialogDescription>
                        Tüm iletişim ayarlarını tek bir formda düzenleyin
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      {allSettings.filter(s => s.key.startsWith("contact.")).map(setting => {
                        const key = setting.key;
                        const value = formData[key] || setting.value || "";
                        const label = settingLabels[key] || key;
                        const description = settingDescriptions[key] || "";
                        const placeholder = settingPlaceholders[key] || "";
                        
                        return (
                          <div key={key} className="space-y-2">
                            <label htmlFor={`dialog-${key}`} className="font-medium">{label}</label>
                            {useTextarea(key) ? (
                              <Textarea
                                id={`dialog-${key}`}
                                value={value}
                                onChange={(e) => handleInputChange(key, e.target.value)}
                                placeholder={placeholder}
                                rows={4}
                              />
                            ) : (
                              <Input
                                id={`dialog-${key}`}
                                value={value}
                                onChange={(e) => handleInputChange(key, e.target.value)}
                                placeholder={placeholder}
                              />
                            )}
                            {description && (
                              <p className="text-xs text-gray-500">{description}</p>
                            )}
                          </div>
                        );
                      })}
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => closeAllDialogs()}>
                        İptal
                      </Button>
                      <Button onClick={() => {
                        handleSubmit("contact");
                        closeAllDialogs();
                      }}>
                        Değişiklikleri Kaydet
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-secondary" />
                  </div>
                ) : (
                  allSettings.filter(s => s.key.startsWith("contact.")).map(renderSettingField)
                )}
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button 
                  onClick={() => handleSubmit("contact")}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Kaydediliyor...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Kaydet
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="social">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div>
                  <CardTitle>Sosyal Medya Ayarları</CardTitle>
                  <CardDescription>
                    Sosyal medya hesaplarının bağlantılarını yönetin
                  </CardDescription>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Pencil className="h-4 w-4 mr-2" /> Tümünü Düzenle
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Sosyal Medya Ayarlarını Düzenle</DialogTitle>
                      <DialogDescription>
                        Tüm sosyal medya bağlantılarını tek bir formda düzenleyin
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      {allSettings.filter(s => s.key.startsWith("social.")).map(setting => {
                        const key = setting.key;
                        const value = formData[key] || setting.value || "";
                        const label = settingLabels[key] || key;
                        const description = settingDescriptions[key] || "";
                        const placeholder = settingPlaceholders[key] || "";
                        
                        return (
                          <div key={key} className="space-y-2">
                            <label htmlFor={`dialog-${key}`} className="font-medium">{label}</label>
                            {useTextarea(key) ? (
                              <Textarea
                                id={`dialog-${key}`}
                                value={value}
                                onChange={(e) => handleInputChange(key, e.target.value)}
                                placeholder={placeholder}
                                rows={4}
                              />
                            ) : (
                              <Input
                                id={`dialog-${key}`}
                                value={value}
                                onChange={(e) => handleInputChange(key, e.target.value)}
                                placeholder={placeholder}
                              />
                            )}
                            {description && (
                              <p className="text-xs text-gray-500">{description}</p>
                            )}
                          </div>
                        );
                      })}
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => closeAllDialogs()}>
                        İptal
                      </Button>
                      <Button onClick={() => {
                        handleSubmit("social");
                        closeAllDialogs();
                      }}>
                        Değişiklikleri Kaydet
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-secondary" />
                  </div>
                ) : (
                  allSettings.filter(s => s.key.startsWith("social.")).map(renderSettingField)
                )}
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button 
                  onClick={() => handleSubmit("social")}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Kaydediliyor...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Kaydet
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="home">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div>
                  <CardTitle>Ana Sayfa Ayarları</CardTitle>
                  <CardDescription>
                    Ana sayfa içeriklerini ve düzenini yönetin
                  </CardDescription>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Pencil className="h-4 w-4 mr-2" /> Tümünü Düzenle
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Ana Sayfa Ayarlarını Düzenle</DialogTitle>
                      <DialogDescription>
                        Tüm ana sayfa ayarlarını tek bir formda düzenleyin
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      {allSettings.filter(s => s.key.startsWith("home.")).map(setting => {
                        const key = setting.key;
                        const value = formData[key] || setting.value || "";
                        const label = settingLabels[key] || key;
                        const description = settingDescriptions[key] || "";
                        const placeholder = settingPlaceholders[key] || "";
                        
                        return (
                          <div key={key} className="space-y-2">
                            <label htmlFor={`dialog-${key}`} className="font-medium">{label}</label>
                            {useTextarea(key) ? (
                              <Textarea
                                id={`dialog-${key}`}
                                value={value}
                                onChange={(e) => handleInputChange(key, e.target.value)}
                                placeholder={placeholder}
                                rows={4}
                              />
                            ) : (
                              <Input
                                id={`dialog-${key}`}
                                value={value}
                                onChange={(e) => handleInputChange(key, e.target.value)}
                                placeholder={placeholder}
                              />
                            )}
                            {description && (
                              <p className="text-xs text-gray-500">{description}</p>
                            )}
                          </div>
                        );
                      })}
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => closeAllDialogs()}>
                        İptal
                      </Button>
                      <Button onClick={() => {
                        handleSubmit("home");
                        closeAllDialogs();
                      }}>
                        Değişiklikleri Kaydet
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-secondary" />
                  </div>
                ) : (
                  allSettings.filter(s => s.key.startsWith("home.")).map(renderSettingField)
                )}
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button 
                  onClick={() => handleSubmit("home")}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Kaydediliyor...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Kaydet
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </AdminLayout>
    </>
  );
}
