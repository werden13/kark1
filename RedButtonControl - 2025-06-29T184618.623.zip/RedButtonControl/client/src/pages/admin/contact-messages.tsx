import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AdminLayout from "@/components/admin/AdminLayout";
import { Helmet } from "react-helmet";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatDate, formatRelativeTime } from "@/lib/utils";
import { ContactMessage } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Eye, Search, Mail, RefreshCcw, Check } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function ContactMessagesPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedMessage, setSelectedMessage] = useState<ContactMessage | null>(null);

  // Fetch all contact messages
  const { data: messages, isLoading } = useQuery<ContactMessage[]>({
    queryKey: ["/api/contact"],
  });

  // Mark message as read mutation
  const markAsReadMutation = useMutation({
    mutationFn: async (messageId: number) => {
      const response = await apiRequest("PUT", `/api/contact/${messageId}/read`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contact"] });
      toast({
        title: "Mesaj okundu olarak işaretlendi",
        variant: "default",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Mesaj işaretlenirken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  // Handle mark as read
  const handleMarkAsRead = (messageId: number) => {
    markAsReadMutation.mutate(messageId);
  };

  // Filter messages based on search query
  const filteredMessages = messages
    ? messages.filter(
        (message) =>
          message.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          message.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
          message.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
          message.message.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  // Sort messages by creation date (newest first)
  const sortedMessages = [...(filteredMessages || [])].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  // Count unread messages
  const unreadCount = messages?.filter((m) => !m.isRead).length || 0;

  return (
    <>
      <Helmet>
        <title>İletişim Mesajları | Admin Panel</title>
      </Helmet>

      <AdminLayout title="İletişim Mesajları">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <div>
              <CardTitle className="text-2xl font-bold">İletişim Mesajları</CardTitle>
              <CardDescription>
                Ziyaretçilerden gelen iletişim formu mesajları
              </CardDescription>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="flex gap-1 items-center">
                <Mail className="h-3.5 w-3.5" />
                <span>
                  {unreadCount} okunmamış {unreadCount === 1 ? "mesaj" : "mesaj"}
                </span>
              </Badge>
              <Button
                variant="outline"
                size="sm"
                onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/contact"] })}
              >
                <RefreshCcw className="h-4 w-4 mr-2" />
                Yenile
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Mesajlarda ara..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
              </div>
            ) : sortedMessages.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <Mail className="h-12 w-12 text-muted-foreground mb-2" />
                <h3 className="text-lg font-medium">Henüz mesaj yok</h3>
                <p className="text-sm text-muted-foreground">
                  İletişim formundan gönderilen mesajlar burada görünecek
                </p>
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[100px]">Durum</TableHead>
                      <TableHead>Gönderen</TableHead>
                      <TableHead>Konu</TableHead>
                      <TableHead className="hidden md:table-cell">E-posta</TableHead>
                      <TableHead className="hidden md:table-cell">Tarih</TableHead>
                      <TableHead className="text-right">İşlemler</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sortedMessages.map((message) => (
                      <TableRow key={message.id}>
                        <TableCell>
                          {message.isRead ? (
                            <Badge variant="outline" className="text-green-600 bg-green-50">
                              Okundu
                            </Badge>
                          ) : (
                            <Badge variant="secondary">Yeni</Badge>
                          )}
                        </TableCell>
                        <TableCell className="font-medium">{message.name}</TableCell>
                        <TableCell>{message.subject}</TableCell>
                        <TableCell className="hidden md:table-cell">
                          {message.email}
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          {formatRelativeTime(message.createdAt)}
                        </TableCell>
                        <TableCell className="text-right">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  console.log("Setting selected message:", message);
                                  setSelectedMessage(message);
                                }}
                              >
                                <Eye className="h-4 w-4 mr-2" />
                                Görüntüle
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="sm:max-w-md">
                              <DialogHeader>
                                <DialogTitle>Mesaj Detayı</DialogTitle>
                                <DialogDescription>
                                  {formatDate(
                                    message.createdAt || new Date().toISOString()
                                  )}
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4 py-4">
                                <div className="grid grid-cols-4 gap-4">
                                  <Label className="text-right">Gönderen:</Label>
                                  <div className="col-span-3 font-medium">
                                    {message.name}
                                  </div>
                                </div>
                                <div className="grid grid-cols-4 gap-4">
                                  <Label className="text-right">E-posta:</Label>
                                  <div className="col-span-3">
                                    <a
                                      href={`mailto:${message.email}`}
                                      className="text-blue-600 hover:underline"
                                    >
                                      {message.email}
                                    </a>
                                  </div>
                                </div>
                                <div className="grid grid-cols-4 gap-4">
                                  <Label className="text-right">Konu:</Label>
                                  <div className="col-span-3">
                                    {message.subject}
                                  </div>
                                </div>
                                <div className="grid grid-cols-4 gap-4">
                                  <Label className="text-right align-top">Mesaj:</Label>
                                  <div className="col-span-3 whitespace-pre-wrap">
                                    {message.message}
                                  </div>
                                </div>
                              </div>
                              <DialogFooter className="flex items-center justify-between sm:justify-between">
                                <div>
                                  {!message.isRead && (
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => {
                                        handleMarkAsRead(message.id);
                                      }}
                                    >
                                      <Check className="h-4 w-4 mr-2" />
                                      Okundu İşaretle
                                    </Button>
                                  )}
                                </div>
                                <div>
                                  <DialogClose asChild>
                                    <Button type="button" variant="secondary">
                                      Kapat
                                    </Button>
                                  </DialogClose>
                                  <Button
                                    type="button"
                                    className="ml-2"
                                    onClick={() => {
                                      window.open(
                                        `mailto:${message.email}?subject=RE: ${message.subject}`,
                                        "_blank"
                                      );
                                    }}
                                  >
                                    Yanıtla
                                  </Button>
                                </div>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </AdminLayout>
    </>
  );
}