import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import HeroSlider, { SlideType } from "@/components/home/HeroSlider";
import EventCard from "@/components/home/EventCard";
import VideoThumbnail from "@/components/home/VideoThumbnail";
import VideoPlayer from "@/components/modals/VideoPlayer";
import VisitorCounter from "@/components/home/VisitorCounter";
import ActivitiesSection from "@/components/home/ActivitiesSection";
import { Button } from "@/components/ui/button";
import { Event, MediaItem, HeroSlider as HeroSliderType } from "@shared/schema";
import { formatDate } from "@/lib/utils";
import { Loader2 } from "lucide-react";

export default function HomePage() {
  const [activeVideoId, setActiveVideoId] = useState<string | null>(null);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);

  // Sayfa yüklendiğinde ziyaretçi sayısını artır
  useEffect(() => {
    const incrementVisitorCount = async () => {
      try {
        await fetch('/api/visitor-count/increment', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
        });
      } catch (error) {
        console.error('Ziyaretçi sayısı artırma hatası:', error);
      }
    };

    incrementVisitorCount();
  }, []);

  const { data: events, isLoading: isLoadingEvents } = useQuery<Event[]>({
    queryKey: ["/api/events"],
  });

  const { data: videos, isLoading: isLoadingVideos } = useQuery<MediaItem[]>({
    queryKey: ["/api/media?type=video"],
  });
  
  // Site ayarlarını al
  const { data: settings } = useQuery<{ key: string, value: string }[]>({
    queryKey: ["/api/settings"],
  });
  
  // Slider verilerini API'den al
  const { data: heroSliders = [], isLoading: isLoadingSliders } = useQuery<HeroSliderType[]>({
    queryKey: ["/api/hero-sliders"],
    queryFn: async () => {
      const response = await fetch("/api/hero-sliders?active=true");
      if (!response.ok) {
        throw new Error("Slider verilerini alma hatası");
      }
      return response.json();
    }
  });
  
  // Tanıtım videosu ID'sini ayarlardan al
  const getPromoVideoId = (): string => {
    if (!settings) return "dQw4w9WgXcQ"; // Fallback video ID
    
    const promoVideoSetting = settings.find(s => s.key === "home.promo_video_url");
    if (!promoVideoSetting || !promoVideoSetting.value) return "dQw4w9WgXcQ";
    
    // YouTube URL'sinden ID'yi çıkar
    const videoUrl = promoVideoSetting.value;
    const regex = /(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
    const match = videoUrl.match(regex);
    
    return match ? match[1] : "dQw4w9WgXcQ";
  };

  const handlePlayVideo = (videoId: string) => {
    setActiveVideoId(videoId);
    setIsVideoModalOpen(true);
  };

  const handleCloseVideo = () => {
    setIsVideoModalOpen(false);
    setActiveVideoId(null);
  };

  // Ayarlardan başlık ve açıklama bilgilerini al
  const getSettingValue = (key: string, defaultValue: string = ""): string => {
    if (!settings) return defaultValue;
    const setting = settings.find(s => s.key === key);
    return setting ? setting.value : defaultValue;
  };

  // Slide verilerini API'den gelen verilerle oluştur
  const slides: SlideType[] = [];
  
  // Veritabanından gelen slider verileri
  if (heroSliders && heroSliders.length > 0) {
    // Slider'ları order değerine göre sırala
    const sortedSliders = [...heroSliders].sort((a, b) => a.order - b.order);
    
    // Her slider için slide oluştur
    sortedSliders.forEach(slider => {
      slides.push({
        id: slider.id,
        title: slider.title,
        description: slider.description || '',
        buttonText: slider.buttonText || 'Detaylar',
        buttonLink: slider.buttonLink || '/',
        imageUrl: slider.imageUrl
      });
    });
  } else {
    // Eğer API'den veri gelmezse, ayarlardan varsayılan slider oluştur
    slides.push({
      id: 1,
      title: getSettingValue("home.hero_title", "KARK Arama Kurtarma Derneği"),
      description: getSettingValue("home.hero_subtitle", "Doğal afetlerde ve acil durumlarda yanınızdayız"),
      buttonText: getSettingValue("home.hero_button_text", "Destek Ol"),
      buttonLink: getSettingValue("home.hero_button_link", "/donations"),
      imageUrl: getSettingValue("home.hero_image_url", "https://images.unsplash.com/photo-1584744982271-69ccbec775aa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080")
    });
  }

  return (
    <>
      <Navbar />

      <main>
        {/* Hero Section */}
        <section id="home" className="pt-24 md:pt-32">
          {isLoadingSliders ? (
            <div className="h-[400px] md:h-[500px] lg:h-[600px] bg-gray-900 flex items-center justify-center">
              <Loader2 className="h-16 w-16 animate-spin text-secondary" />
            </div>
          ) : (
            <HeroSlider slides={slides} />
          )}
        </section>

        {/* Visitor Counter Section */}
        <section className="py-12 bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
          <div className="container mx-auto px-4">
            <div className="max-w-md mx-auto">
              <VisitorCounter />
            </div>
          </div>
        </section>

        {/* Upcoming Events Section */}
        <section id="events" className="py-16 bg-gray-50 dark:bg-gray-900">
          <div className="container mx-auto px-4">
            <div className="mb-12 text-center">
              <div className="flex justify-center">
                <h2 className="section-title dark:text-white">Yaklaşan Etkinlikler</h2>
              </div>
              <p className="section-description dark:text-gray-300">
                Katılabileceğiniz en güncel etkinliklerimiz ve faaliyetlerimiz
              </p>
            </div>
            
            {/* Event Filters */}
            <div className="mb-8 flex flex-wrap justify-center gap-4">
              <Link href="/events">
                <Button variant="default" className="bg-dark text-white hover:bg-gray-800">
                  Tüm Etkinlikler
                </Button>
              </Link>
              <Link href="/events?category=rescue">
                <Button variant="outline" className="bg-white dark:bg-gray-800 text-dark dark:text-gray-200 border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-700">
                  Arama Kurtarma
                </Button>
              </Link>
              <Link href="/events?category=training">
                <Button variant="outline" className="bg-white dark:bg-gray-800 text-dark dark:text-gray-200 border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-700">
                  Eğitim
                </Button>
              </Link>
              <Link href="/events?category=donation">
                <Button variant="outline" className="bg-white dark:bg-gray-800 text-dark dark:text-gray-200 border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-700">
                  Bağış
                </Button>
              </Link>
              <Link href="/events?category=awareness">
                <Button variant="outline" className="bg-white dark:bg-gray-800 text-dark dark:text-gray-200 border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-700">
                  Farkındalık
                </Button>
              </Link>
            </div>
            
            {isLoadingEvents ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-12 w-12 animate-spin text-secondary" />
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {events && events.slice(0, 3).map((event) => (
                  <EventCard key={event.id} event={event} />
                ))}
                
                {(!events || events.length === 0) && (
                  <div className="col-span-3 text-center py-8">
                    <p className="text-gray-500">Henüz etkinlik bulunmuyor</p>
                  </div>
                )}
              </div>
            )}
            
            <div className="mt-12 text-center">
              <Link href="/events">
                <Button size="lg">Tüm Etkinlikleri Gör</Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Recent Activities Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="mb-12 text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Son Faaliyetler</h2>
              <p className="text-primary text-lg max-w-2xl mx-auto">
                {getSettingValue("home.recent_activities_subtitle", "Gerçekleştirdiğimiz etkinliklerin öne çıkanları")}
              </p>
            </div>
            
            <ActivitiesSection />
          </div>
        </section>

        {/* Promotional Video Section */}
        <section className="py-16 bg-gray-900 text-white">
          <div className="container mx-auto px-4">
            <div className="mb-8 text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">{getSettingValue("home.video_section_title", "Bizi Tanıyın")}</h2>
              <p className="text-primary text-lg max-w-2xl mx-auto">
                {getSettingValue("home.about_section_text", "Amacımız, değerlerimiz ve faaliyetlerimiz hakkında kısa tanıtım videomuz")}
              </p>
            </div>
            
            <div 
              className="max-w-4xl mx-auto relative aspect-video rounded-lg overflow-hidden shadow-xl cursor-pointer"
              onClick={() => handlePlayVideo(getPromoVideoId())}
            >
              <div className="bg-black absolute inset-0 flex items-center justify-center">
                <img 
                  src={`https://img.youtube.com/vi/${getPromoVideoId()}/maxresdefault.jpg`}
                  alt="Tanıtım Videosu" 
                  className="w-full h-full object-cover opacity-60" 
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="bg-secondary bg-opacity-80 w-16 h-16 md:w-20 md:h-20 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="white" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                      <polygon points="5 3 19 12 5 21 5 3"></polygon>
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Videos Gallery Section */}
        <section id="videos" className="py-16">
          <div className="container mx-auto px-4">
            <div className="mb-12 text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">{getSettingValue("videos.section_title", "Video Galerisi")}</h2>
              <p className="text-primary text-lg max-w-2xl mx-auto">
                {getSettingValue("videos.section_subtitle", "Etkinliklerimizden öne çıkan video içerikler")}
              </p>
            </div>
            
            {isLoadingVideos ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-12 w-12 animate-spin text-secondary" />
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {videos && videos.slice(0, 3).map((video) => (
                  <VideoThumbnail 
                    key={video.id}
                    videoUrl={video.filePath}
                    title={video.title}
                    description={video.description || ''}
                    onPlay={handlePlayVideo}
                  />
                ))}
                
                {(!videos || videos.length === 0) && (
                  <div className="col-span-3 text-center py-8">
                    <p className="text-gray-500">Henüz video bulunmuyor</p>
                  </div>
                )}
              </div>
            )}
            
            <div className="mt-12 text-center">
              <Link href="/videos">
                <Button size="lg">Tüm Videoları Gör</Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
      
      <VideoPlayer 
        isOpen={isVideoModalOpen}
        videoId={activeVideoId}
        onClose={handleCloseVideo}
      />
    </>
  );
}
