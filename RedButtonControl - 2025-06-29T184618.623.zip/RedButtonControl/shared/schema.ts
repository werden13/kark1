import { mysqlTable, varchar, int, boolean, timestamp, mysqlEnum, decimal, date, text, json } from "drizzle-orm/mysql-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enum values as constants (MySQL approach)
export const eventCategoryValues = ['rescue', 'training', 'donation', 'awareness'] as const;
export const mediaTypeValues = ['photo', 'video'] as const;
export const userRoleValues = ['major_admin', 'admin', 'user', 'banned'] as const;
export const archiveItemTypeValues = ['operation', 'training', 'event', 'report', 'news'] as const;

// Export enum compatibility for existing code
export const eventCategoryEnum = eventCategoryValues;
export const mediaTypeEnum = mediaTypeValues;
export const userRoleEnum = userRoleValues;
export const archiveItemTypeEnum = archiveItemTypeValues;

// Users
export const users = mysqlTable("users", {
  id: int("id").primaryKey().autoincrement(),
  username: varchar("username", { length: 255 }).notNull().unique(),
  password: text("password").notNull(),
  firstName: varchar("first_name", { length: 255 }).notNull(),
  lastName: varchar("last_name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  isAdmin: boolean("is_admin").default(false).notNull(),
  role: mysqlEnum("role", userRoleValues).default("user").notNull(),
  permissions: json("permissions").$type<string[]>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Events
export const events = mysqlTable("events", {
  id: int("id").primaryKey().autoincrement(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  date: timestamp("date").notNull(),
  location: varchar("location", { length: 255 }).notNull(),
  category: mysqlEnum("category", eventCategoryValues).notNull(),
  imagePath: text("image_path"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  createdBy: int("created_by").references(() => users.id),
});

// Media (Photos & Videos)
export const mediaItems = mysqlTable("media_items", {
  id: int("id").primaryKey().autoincrement(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  mediaType: mysqlEnum("media_type", mediaTypeValues).notNull(),
  filePath: text("file_path").notNull(),
  thumbnailPath: text("thumbnail_path"),
  eventId: int("event_id").references(() => events.id),
  albumId: int("album_id").references(() => albums.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  createdBy: int("created_by").references(() => users.id),
});

// Albums
export const albums = mysqlTable("albums", {
  id: int("id").primaryKey().autoincrement(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  coverImageId: int("cover_image_id"),
  eventId: int("event_id").references(() => events.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  createdBy: int("created_by").references(() => users.id),
});

// Team Members
export const teamMembers = mysqlTable("team_members", {
  id: int("id").primaryKey().autoincrement(),
  firstName: varchar("first_name", { length: 255 }).notNull(),
  lastName: varchar("last_name", { length: 255 }).notNull(),
  position: varchar("position", { length: 255 }).notNull(),
  imagePath: text("image_path"),
  email: varchar("email", { length: 255 }),
  skills: json("skills").$type<string[]>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  createdBy: int("created_by").references(() => users.id),
});

// Contact Messages
export const contactMessages = mysqlTable("contact_messages", {
  id: int("id").primaryKey().autoincrement(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Settings
export const settings = mysqlTable("settings", {
  id: int("id").primaryKey().autoincrement(),
  key: varchar("key", { length: 255 }).notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  updatedBy: int("updated_by").references(() => users.id),
});

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  isAdmin: true,
});

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
  createdAt: true,
});

export const insertMediaItemSchema = createInsertSchema(mediaItems).omit({
  id: true,
  createdAt: true,
});

export const insertAlbumSchema = createInsertSchema(albums).omit({
  id: true,
  createdAt: true,
});

export const insertTeamMemberSchema = createInsertSchema(teamMembers).omit({
  id: true,
  createdAt: true,
});

export const insertContactMessageSchema = createInsertSchema(contactMessages).omit({
  id: true,
  isRead: true,
  createdAt: true,
});

export const insertSettingSchema = createInsertSchema(settings).omit({
  id: true,
  updatedAt: true,
});

// Login Schema
export const loginSchema = z.object({
  username: z.string().min(3, "Kullanıcı adı en az 3 karakter olmalıdır"),
  password: z.string().min(8, "Şifre en az 8 karakter olmalıdır"),
});

// Bağış Yöntemleri
export const donationMethods = mysqlTable("donation_methods", {
  id: int("id").primaryKey().autoincrement(),
  bankName: varchar("bank_name", { length: 255 }).notNull(),
  accountName: varchar("account_name", { length: 255 }).notNull(),
  iban: varchar("iban", { length: 50 }).notNull(),
  branchCode: varchar("branch_code", { length: 20 }),
  accountNumber: varchar("account_number", { length: 50 }),
  currency: varchar("currency", { length: 10 }).default("TRY"),
  description: text("description"),
  logoUrl: text("logo_url"), // Banka logosu için URL
  createdAt: timestamp("created_at").defaultNow().notNull(),
  createdBy: int("created_by").references(() => users.id),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  updatedBy: int("updated_by").references(() => users.id),
});

// Bağış Kampanyaları
export const donationCampaigns = mysqlTable("donation_campaigns", {
  id: int("id").primaryKey().autoincrement(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  targetAmount: decimal("target_amount", { precision: 12, scale: 2 }),
  currentAmount: decimal("current_amount", { precision: 12, scale: 2 }).default("0"),
  endDate: date("end_date"),
  imageUrl: text("image_url"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  createdBy: int("created_by").references(() => users.id),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  updatedBy: int("updated_by").references(() => users.id),
});

// Archive Items - Detaylı arşiv sistemi
export const archiveItems = mysqlTable("archive_items", {
  id: int("id").primaryKey().autoincrement(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  content: text("content"), // Detaylı içerik
  itemType: mysqlEnum("item_type", archiveItemTypeValues).notNull(),
  date: timestamp("date").notNull(), // Arşiv öğesinin tarihi
  location: varchar("location", { length: 255 }), // Konum bilgisi
  participants: text("participants"), // Katılımcılar
  outcome: text("outcome"), // Sonuç/başarı durumu
  imageUrl: text("image_url"),
  videoUrl: text("video_url"),
  documentUrl: text("document_url"), // PDF rapor vs.
  tags: json("tags").$type<string[]>(), // Etiketler
  isPublished: boolean("is_published").default(false).notNull(),
  isFeatured: boolean("is_featured").default(false).notNull(),
  viewCount: int("view_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  createdBy: int("created_by").references(() => users.id),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  updatedBy: int("updated_by").references(() => users.id),
});

// Archive Media - Arşiv öğelerine bağlı medya
export const archiveMedia = mysqlTable("archive_media", {
  id: int("id").primaryKey().autoincrement(),
  archiveItemId: int("archive_item_id").references(() => archiveItems.id).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  mediaType: mysqlEnum("media_type", mediaTypeValues).notNull(),
  filePath: text("file_path").notNull(),
  thumbnailPath: text("thumbnail_path"),
  order: int("display_order").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  createdBy: int("created_by").references(() => users.id),
});

// Insert Schemas for Donations
export const insertDonationMethodSchema = createInsertSchema(donationMethods).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  logoUrl: z.string().optional().nullable(),
});

export const insertDonationCampaignSchema = createInsertSchema(donationCampaigns).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Hero Slider
export const heroSliders = mysqlTable("hero_sliders", {
  id: int("id").primaryKey().autoincrement(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  buttonText: varchar("button_text", { length: 100 }),
  buttonLink: varchar("button_link", { length: 255 }),
  imageUrl: text("image_url").notNull(),
  order: int("display_order").default(0).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  createdBy: int("created_by").references(() => users.id),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  updatedBy: int("updated_by").references(() => users.id),
});

export const insertHeroSliderSchema = createInsertSchema(heroSliders).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Type Exports
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;
export type MediaItem = typeof mediaItems.$inferSelect;
export type InsertMediaItem = z.infer<typeof insertMediaItemSchema>;
export type Album = typeof albums.$inferSelect;
export type InsertAlbum = z.infer<typeof insertAlbumSchema>;
export type TeamMember = typeof teamMembers.$inferSelect;
export type InsertTeamMember = z.infer<typeof insertTeamMemberSchema>;
export type ContactMessage = typeof contactMessages.$inferSelect;
export type InsertContactMessage = z.infer<typeof insertContactMessageSchema>;
export type Setting = typeof settings.$inferSelect;
export type InsertSetting = z.infer<typeof insertSettingSchema>;
export type DonationMethod = typeof donationMethods.$inferSelect;
export type InsertDonationMethod = z.infer<typeof insertDonationMethodSchema>;
export type DonationCampaign = typeof donationCampaigns.$inferSelect;
export type InsertDonationCampaign = z.infer<typeof insertDonationCampaignSchema>;
export type HeroSlider = typeof heroSliders.$inferSelect;
export type InsertHeroSlider = z.infer<typeof insertHeroSliderSchema>;
export type LoginData = z.infer<typeof loginSchema>;

// Archive schemas
export const insertArchiveItemSchema = createInsertSchema(archiveItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  viewCount: true,
}).extend({
  date: z.union([z.date(), z.string().transform((str) => new Date(str))]),
});

export const insertArchiveMediaSchema = createInsertSchema(archiveMedia).omit({
  id: true,
  createdAt: true,
});

export type ArchiveItem = typeof archiveItems.$inferSelect;
export type InsertArchiveItem = z.infer<typeof insertArchiveItemSchema>;
export type ArchiveMedia = typeof archiveMedia.$inferSelect;
export type InsertArchiveMedia = z.infer<typeof insertArchiveMediaSchema>;

// Admin logs for tracking and security
export const adminLogs = mysqlTable("admin_logs", {
  id: int("id").primaryKey().autoincrement(),
  userId: int("user_id").references(() => users.id).notNull(),
  action: varchar("action", { length: 255 }).notNull(),
  details: text("details"),
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  resourceType: varchar("resource_type", { length: 100 }),
  resourceId: varchar("resource_id", { length: 100 }),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertAdminLogSchema = createInsertSchema(adminLogs).omit({
  id: true,
  timestamp: true,
});

export type InsertAdminLog = z.infer<typeof insertAdminLogSchema>;
export type AdminLog = typeof adminLogs.$inferSelect;

// Activities table for homepage activities
export const activities = mysqlTable("activities", {
  id: int("id").primaryKey().autoincrement(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  imageUrl: text("image_url"),
  date: varchar("date", { length: 100 }),
  link: varchar("link", { length: 255 }),
  displayOrder: int("display_order").default(0).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  createdBy: int("created_by").references(() => users.id),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  updatedBy: int("updated_by").references(() => users.id),
});

export type Activity = typeof activities.$inferInsert;
export type SelectActivity = typeof activities.$inferSelect;

// Sessions table for connect-pg-simple
export const sessions = mysqlTable("sessions", {
  sid: text("sid").primaryKey(),
  sess: text("sess").notNull(),
  expire: timestamp("expire").notNull(),
});
