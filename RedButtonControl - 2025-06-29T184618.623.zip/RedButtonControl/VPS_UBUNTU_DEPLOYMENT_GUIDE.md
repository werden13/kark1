# KARK Website VPS Deployment Guide
## Ubuntu 22.04 LTS (Jammy) Step-by-Step Instructions

### Prerequisites
- VPS with Ubuntu 22.04 LTS (Jammy)
- Root or sudo access
- Domain name (optional, but recommended)

---

## Step 1: Connect to Your VPS
```bash
ssh root@your-vps-ip-address
# or
ssh username@your-vps-ip-address
```

---

## Step 2: Update System and Install Basic Tools
```bash
# Update package list
sudo apt update

# Upgrade existing packages
sudo apt upgrade -y

# Install essential tools
sudo apt install -y curl wget git build-essential
```

---

## Step 3: Install Node.js 20.x
```bash
# Download and install NodeSource repository
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -

# Install Node.js
sudo apt install -y nodejs

# Verify installation
node --version  # Should show v20.x.x
npm --version   # Should show 10.x.x
```

---

## Step 4: Install PM2 (Process Manager)
```bash
# Install PM2 globally
sudo npm install -g pm2

# Set PM2 to start on boot
pm2 startup systemd
# Follow the command it gives you
```

---

## Step 5: Set Up Project Directory
```bash
# Create directory for your application
sudo mkdir -p /var/www/kark
sudo chown -R $USER:$USER /var/www/kark

# Navigate to the directory
cd /var/www/kark
```

---

## Step 6: Upload Your KARK Website Files
```bash
# Option A: Using Git (if you have a repository)
git clone your-repository-url .

# Option B: Using SCP from your local machine
# From your local machine, run:
scp -r /path/to/kark/* username@your-vps-ip:/var/www/kark/

# Option C: Using rsync (better for large files)
# From your local machine, run:
rsync -avz --progress /path/to/kark/ username@your-vps-ip:/var/www/kark/
```

---

## Step 7: Install Dependencies
```bash
# Navigate to project directory
cd /var/www/kark

# Install all dependencies
npm install

# If you get any errors, try:
npm install --legacy-peer-deps
```

---

## Step 8: Configure Environment Variables
```bash
# Create .env file
nano .env

# Add the following content:
DB_TYPE=json
NODE_ENV=production
PORT=5000
SESSION_SECRET=your-very-long-random-secret-key-change-this

# For MySQL (if using):
# DB_TYPE=mysql
# MYSQL_HOST=localhost
# MYSQL_USER=your_mysql_user
# MYSQL_PASSWORD=your_mysql_password
# MYSQL_DATABASE=kark_db

# Save and exit (Ctrl+X, Y, Enter)
```

---

## Step 9: Build the Application
```bash
# Build the frontend
npm run build

# This will create optimized production files
```

---

## Step 10: Create PM2 Configuration
```bash
# Create ecosystem file
nano ecosystem.config.js

# Add the following content:
module.exports = {
  apps: [{
    name: 'kark-website',
    script: './node_modules/.bin/tsx',
    args: 'server/index.ts',
    cwd: '/var/www/kark',
    instances: 1,
    exec_mode: 'fork',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    error_file: './logs/pm2-error.log',
    out_file: './logs/pm2-out.log',
    log_file: './logs/pm2-combined.log',
    time: true
  }]
};

# Save and exit
```

---

## Step 11: Create Logs Directory
```bash
mkdir -p /var/www/kark/logs
```

---

## Step 12: Start Application with PM2
```bash
# Start the application
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save

# Check status
pm2 status

# View logs
pm2 logs kark-website
```

---

## Step 13: Install and Configure Nginx
```bash
# Install Nginx
sudo apt install -y nginx

# Create Nginx configuration
sudo nano /etc/nginx/sites-available/kark

# Add the following content:
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    # If no domain, use: server_name _;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Increase file upload size for media
    client_max_body_size 50M;
}

# Save and exit
```

---

## Step 14: Enable Nginx Site
```bash
# Create symbolic link
sudo ln -s /etc/nginx/sites-available/kark /etc/nginx/sites-enabled/

# Test Nginx configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

---

## Step 15: Configure Firewall
```bash
# Install UFW if not already installed
sudo apt install -y ufw

# Allow SSH (important!)
sudo ufw allow 22/tcp

# Allow HTTP and HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Enable firewall
sudo ufw --force enable

# Check status
sudo ufw status
```

---

## Step 16: Set Up SSL Certificate (Optional but Recommended)
```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx

# Get SSL certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Follow the prompts, enter your email

# Test auto-renewal
sudo certbot renew --dry-run
```

---

## Step 17: Set Up MySQL Database (If Using MySQL)
```bash
# Install MySQL
sudo apt install -y mysql-server

# Secure MySQL installation
sudo mysql_secure_installation

# Create database and user
sudo mysql

# In MySQL prompt:
CREATE DATABASE kark_db;
CREATE USER 'kark_user'@'localhost' IDENTIFIED BY 'strong_password';
GRANT ALL PRIVILEGES ON kark_db.* TO 'kark_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# Import database if you have SQL file
mysql -u kark_user -p kark_db < /path/to/kark_complete_database.sql
```

---

## Step 18: Verify Everything is Working
```bash
# Check PM2 status
pm2 status

# Check application logs
pm2 logs kark-website --lines 50

# Test the website
curl http://localhost:5000/api/health

# Check Nginx logs if needed
sudo tail -f /var/log/nginx/error.log
```

---

## Step 19: Set Up Automatic Backups (Optional)
```bash
# Create backup script
nano /home/$USER/backup-kark.sh

# Add content:
#!/bin/bash
BACKUP_DIR="/home/$USER/backups"
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR

# Backup data files
tar -czf $BACKUP_DIR/kark-data-$DATE.tar.gz /var/www/kark/data/

# Keep only last 7 days of backups
find $BACKUP_DIR -name "kark-data-*.tar.gz" -mtime +7 -delete

# Make executable
chmod +x /home/$USER/backup-kark.sh

# Add to crontab (daily at 2 AM)
crontab -e
# Add line:
0 2 * * * /home/$USER/backup-kark.sh
```

---

## Step 20: Monitor and Maintain
```bash
# Useful commands:

# View PM2 logs
pm2 logs kark-website

# Restart application
pm2 restart kark-website

# Monitor resources
pm2 monit

# Update application
cd /var/www/kark
git pull  # or upload new files
npm install
npm run build
pm2 restart kark-website

# Check disk space
df -h

# Check memory usage
free -m
```

---

## Troubleshooting

### If website doesn't load:
1. Check PM2 status: `pm2 status`
2. Check logs: `pm2 logs kark-website`
3. Check Nginx: `sudo systemctl status nginx`
4. Check firewall: `sudo ufw status`

### If database connection fails:
1. Verify .env settings
2. Check MySQL is running: `sudo systemctl status mysql`
3. Test connection: `mysql -u kark_user -p`

### If uploads fail:
1. Check permissions: `ls -la /var/www/kark/data/`
2. Set correct permissions: `chmod -R 755 /var/www/kark/data/`

---

## Security Recommendations

1. **Change default passwords**
   - Update admin passwords in the application
   - Use strong MySQL passwords

2. **Keep system updated**
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

3. **Enable fail2ban**
   ```bash
   sudo apt install -y fail2ban
   sudo systemctl enable fail2ban
   ```

4. **Disable root SSH (if using root)**
   ```bash
   sudo nano /etc/ssh/sshd_config
   # Set: PermitRootLogin no
   sudo systemctl restart sshd
   ```

---

## Access Your Website

Once everything is set up:
- **With domain**: http://your-domain.com
- **Without domain**: http://your-vps-ip:80
- **Admin panel**: http://your-domain.com/admin
  - Username: supermanager
  - Password: admin123 (change this immediately!)

---

## Quick Start Commands Summary
```bash
# Complete setup in order:
sudo apt update && sudo apt upgrade -y
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs nginx mysql-server
sudo npm install -g pm2
cd /var/www/kark
npm install
npm run build
pm2 start ecosystem.config.js
pm2 save
sudo systemctl restart nginx
```

That's it! Your KARK website should now be running on your Ubuntu VPS.